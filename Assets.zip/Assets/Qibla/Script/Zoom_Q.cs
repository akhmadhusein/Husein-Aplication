﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Zoom_Q : MonoBehaviour
{
    public Slider slider;
    public Camera cam;
    float far = 50;

    // Start is called before the first frame update
    void Start()
    {
        cam.fieldOfView = far;
    }

    // Update is called once per frame
    void Update()
    {
        cam.fieldOfView = slider.value;
    }
}
