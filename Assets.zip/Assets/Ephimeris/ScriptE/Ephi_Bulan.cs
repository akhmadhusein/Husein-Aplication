﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class Ephi_Bulan : MonoBehaviour
{

    // Memanggil fungsi Hisab
    private Algo_ESP2000 eSP2000;

    //Memanggil Class Algo JeanMeeus
    private Algo_JeanMeeus jMeeus;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Variable Koordinat
    double lt;
    double bt;

    //Variable gameObject
    public Text t_tanggal,t_latitude,t_longitude;

    public Text t_App_Longitude, t_App_latitude, t_App_RAscension, t_App_Declination,
        t_Semi_Diameter, t_H_Parallax, t_Azimuth, t_Altitude, t_Jrk_BB, t_F_Illumination;

    //Variable String Data Bulan
    private string s_tanggal, s_latitude, s_longitude;

    private string s_App_Longitude, s_App_latitude, s_App_RAscension, s_App_Declination,
        s_Semi_Diameter, s_H_Parallax, s_Azimuth, s_Altitude, s_Jrk_BB, s_F_Illumination;


    // Start is called before the first frame update
    void Start()
    {

        // memanggil Class  ESP2000
        eSP2000 = gameObject.AddComponent<Algo_ESP2000>();

        // memanggil Class  Algo JeanMeeus
        jMeeus = gameObject.AddComponent<Algo_JeanMeeus>();


        // mendapatkan nilai koordinat tempat
        lt = StateNameController.stc_latitude;
        bt = StateNameController.stc_longitude;

        // set Text koordinat

        s_latitude = "Lintang Tempat : " + kederajat(lt);
        t_latitude.text = s_latitude;

        s_longitude = "Bujur Tempat : " + kederajat(bt);
        t_longitude.text = s_longitude;


    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {

        // mendapatkan nilai waktu
        DateTime sekarang = DateTime.Now;
        s_tanggal = sekarang.ToString("dddd, dd MMMM yyyy") + " | " + sekarang.ToString("hh:mm");
        // set Text waktu
        t_tanggal.text = s_tanggal;

        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        double jam = DateTime.Now.Hour;
        double mnt = DateTime.Now.Minute;
        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        double tz = currentOffset.Hours;

        //------------MENGISI NILAI EPHIMERIS BULAN------------------------------------//

        //app longitude
        double app_longitude = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[1];
        s_App_Longitude = kederajat(app_longitude);
        t_App_Longitude.text = s_App_Longitude;

        //app latitude
        double app_latitude = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[2];
        s_App_latitude = kederajat(app_latitude);
        t_App_latitude.text = s_App_latitude;

        //app R Ascension
        double app_RAscension = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[3];
        s_App_RAscension = kederajat(app_RAscension);
        t_App_RAscension.text = s_App_RAscension;

        //app Declination
        double app_declination = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[4];
        s_App_Declination = kederajat(app_declination);
        t_App_Declination.text = s_App_Declination;

        //semi diameter
        double semi_Diameter = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[5];
        s_Semi_Diameter = kederajat(semi_Diameter);
        t_Semi_Diameter.text = s_Semi_Diameter;

        //H Parallax
        double h_Parallax = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[6];
        s_H_Parallax = kederajat(h_Parallax);
        t_H_Parallax.text = s_H_Parallax;

        //azimuth
        double azimuth = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[7];
        s_Azimuth = kederajat(azimuth);
        t_Azimuth.text = s_Azimuth;

        //altitude
        double altitude = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[8];
        s_Altitude = kederajat(altitude);
        t_Altitude.text = s_Altitude;

        //jarak bb
        double jarak_bb = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[9];
        s_Jrk_BB = jarak_bb.ToString("0.#####");
        t_Jrk_BB.text = s_Jrk_BB;

        //F Illumination
        double F_illumn = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[8];
        s_F_Illumination = F_illumn.ToString("0.#####");
        t_F_Illumination.text = s_F_Illumination;
    }

    //Fungsi merubah nilai desimal ke derajat
    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;
        string min_plus = " ";

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
            min_plus = "-";
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return min_plus + (int)Math.Abs(derajat) + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }

}
