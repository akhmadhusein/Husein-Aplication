﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Txt_azQ : MonoBehaviour
{

    private Qiblat qiblat;

    public Text nilai_az;

    //variable azimuth qiblat
    float az_q;

    // Variable Koordinat
    double lt;
    double bt;

    // Start is called before the first frame update
    void Start()
    {
        //get value Koordinat
        lt = -7;
        bt = 110;

        //get azimuth qiblat from function Qiblat
        qiblat = gameObject.AddComponent<Qiblat>();
        double az_Q_d = qiblat.Az_qiblat(lt, bt);
        az_q = (float)az_Q_d;

        nilai_az.text = kederajat(az_Q_d);

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //Fungsi merubah nilai desimal ke derajat
    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return (int)derajat + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }
}
