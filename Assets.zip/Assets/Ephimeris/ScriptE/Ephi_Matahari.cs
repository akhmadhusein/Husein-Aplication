﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class Ephi_Matahari : MonoBehaviour
{
    //Memanggil Class Algo JeanMeeus
    private Algo_JeanMeeus jMeeus;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Variable Koordinat
    double lt;
    double bt;

    //Variable game object Text
    public Text t_tanggal, t_latitude, t_longitude;

    public Text t_ep_longitude, t_ep_latitude, t_app_RAscension, t_app_Declination,
        t_tg_Distance, t_SemiDiamater, t_tObliquity, t_equationOT, t_az, t_alt;

    //Variable String data Matahari
    private string s_tanggal, s_latitude, s_longitude;

    private string s_ep_longitude, s_ep_latitude, s_app_RAscension, s_app_Declination,
        s_tg_Distance, s_SemiDiamater, s_tObliquity, s_equationOT, s_az, s_alt;


    // Start is called before the first frame update
    void Start()
    {

        // memanggil Class  Algo JeanMeeus
        jMeeus = gameObject.AddComponent<Algo_JeanMeeus>();

        // mendapatkan nilai koordinat tempat
        lt = StateNameController.stc_latitude;
        bt = StateNameController.stc_longitude;

        // set Text koordinat

        s_latitude = "Lintang Tempat : " + kederajat(lt);
        t_latitude.text = s_latitude;

        s_longitude = "Bujur Tempat : " + kederajat(bt);
        t_longitude.text = s_longitude;


    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {

        // mendapatkan nilai waktu
        DateTime sekarang = DateTime.Now;
        s_tanggal = sekarang.ToString("dddd, dd MMMM yyyy") + " | " + sekarang.ToString("hh:mm");
        // set Text waktu
        t_tanggal.text = s_tanggal;

        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        double jam = DateTime.Now.Hour;
        double mnt = DateTime.Now.Minute;
        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        double tz = currentOffset.Hours;


        //-----------MENGISI DATA EPHIMERIS MATAHARI--------------//

        //ecliptic longitude
        double ep_long = jMeeus.Data_Algo_JeanMeeus(tahun,bulan,tgl,jam,mnt,tz)[9];
        s_ep_longitude = kederajat(ep_long);
        t_ep_longitude.text = s_ep_longitude;

        //ecliptic latitude
        double ep_latitude = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[10];
        s_ep_latitude = kederajat(ep_latitude);
        t_ep_latitude.text = s_ep_latitude;

        //app Right Ascension
        double app_RA = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[11];
        s_app_RAscension = kederajat(app_RA);
        t_app_RAscension.text = s_app_RAscension;

        //app Declination
        double app_dec = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[12];
        s_app_Declination = kederajat(app_dec);
        t_app_Declination.text = s_app_Declination;

        //True Geosentric Distance
        double true_GD = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[13];
        s_tg_Distance = true_GD.ToString("0.#####");
        t_tg_Distance.text = s_tg_Distance;

        //Semi Diameter
        double sDiameter = (jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[14])/60;
        s_SemiDiamater = kederajat(sDiameter);
        t_SemiDiamater.text = s_SemiDiamater;

        //True Obliquity
        double tObliquity = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[15];
        s_tObliquity = kederajat(tObliquity);
        t_tObliquity.text = s_tObliquity;

        //equation of time
        double equationOT = (jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[16])/60;
        s_equationOT = kederajat(equationOT);
        t_equationOT.text = s_equationOT;

        //azimut matahari
        double azmt = jMeeus.Az_AltMatahari(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[1];
        s_az = kederajat(azmt);
        t_az.text = s_az;

        //altitude matahari
        double alt = jMeeus.Az_AltMatahari(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[2];
        s_alt = kederajat(alt);
        t_alt.text = s_alt;

    }

    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;
        string min_plus = " ";

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
            min_plus = "-";
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return min_plus + (int)Math.Abs(derajat) + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }

    private string kewaktu(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return  (int)Math.Abs(menit) + "m  " + Math.Abs(detik) + "s";
    }

   
}
