﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class txt_dataBln : MonoBehaviour
{
    // Memanggil fungsi Hisab
    private Algo_ESP2000 eSP2000;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Variable Koordinat
    double lt;
    double bt;

    // Variable game object text
    public Text t_tanggal;
    public Text t_latitude;
    public Text t_longitude;

    public Text tp_azimuth;
    public Text tp_altitude;

    // Variable string txt
    string s_tanggal;
    string s_latitude;
    string s_longitude;

    string sp_azimuth;
    string sp_altitude;


    // Start is called before the first frame update
    void Start()
    {
        // memanggil Class  ESP2000
        eSP2000 = gameObject.AddComponent<Algo_ESP2000>();

        // mendapatkan nilai koordinat tempat
        lt = StateNameController.stc_latitude;
        bt = StateNameController.stc_longitude;

        // set Text koordinat

        s_latitude = "Lintang Tempat : " + kederajat(lt);
        t_latitude.text = s_latitude;

        s_longitude = "Bujur Tempat : " + kederajat(bt);
        t_longitude.text = s_longitude;


    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {
     
    // mendapatkan nilai waktu
        DateTime sekarang = DateTime.Now;
        s_tanggal = sekarang.ToString("dddd, dd MMMM yyyy") + " | " + sekarang.ToString("hh:mm");
        // set Text waktu
        t_tanggal.text = s_tanggal;

        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        double jam = DateTime.Now.Hour;
        double mnt = DateTime.Now.Minute;
        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        double tz = currentOffset.Hours;

        // menghitung nilai azimut
        double azimuth = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[7];
        sp_azimuth = kederajat(azimuth);
        //set Text azimuth
        tp_azimuth.text = sp_azimuth;

        // menghitung nilai altitude
        double altitude = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[8];
        sp_altitude = kederajat(altitude);
        //set Text altitude
        tp_altitude.text = sp_altitude;


        

        

    }


    //Fungsi merubah nilai desimal ke derajat
    private string kederajat (double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return (int)derajat + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }


}
