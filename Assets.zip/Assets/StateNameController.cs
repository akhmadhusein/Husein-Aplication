﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateNameController : MonoBehaviour
{
    public static double stc_latitude = -7;
    public static double stc_longitude = 110;
    public static double stc_altitude = 0;

    public static double stc_kalibrasiGL = 0;
    public static double stc_kalibrasiAK = 0;
}
