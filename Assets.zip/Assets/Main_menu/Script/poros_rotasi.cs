﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class poros_rotasi : MonoBehaviour
{

    // Memanggil fungsi Hisab
    private Algo_ESP2000 eSP2000;

    // The spherical coordinates Variable
    float radius;
    float azimuth;
    float altitude;
    float jarak;

    // Variable Koordinat
    double lt;
    double bt;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Start is called before the first frame update
    [Obsolete]
    void Start()
    {
        //get value Koordinat
        lt = StateNameController.stc_latitude;
        bt = StateNameController.stc_longitude;


        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        int jam = DateTime.Now.Hour;
        int mnt = DateTime.Now.Minute;

        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        int tz = currentOffset.Hours;

        // get altitude and azimuth dari fungsi ESP2000
        eSP2000 = gameObject.AddComponent<Algo_ESP2000>();

        double azimuth_d = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[7];
        azimuth = (float)azimuth_d+90;

        double altitude_d = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[8];
        altitude = (float)altitude_d;

        //rotasi objek berdasarkan nilai azimuth dan altitude bulan
        transform.rotation = Quaternion.Euler(0, azimuth, altitude);
    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {
       
    }
}
