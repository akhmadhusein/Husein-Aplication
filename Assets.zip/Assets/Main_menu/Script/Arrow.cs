﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Arrow : MonoBehaviour
{
    public Vector3 NorthDirection;
    public Transform Player;
    public Quaternion MissionDirection;

    //public RectTransform NorthLayer;
    public RectTransform MissionLayer;

    public Transform Missionplace;
    public Transform HidePram;

    // Update is called once per frame
    void Update()
    {
        ChangeNorthDirection();
        ChangeMissionDirection();

        // hide arrow when near target
        float az = Mathf.Abs(Player.eulerAngles.y-HidePram.eulerAngles.y);
        float alt = Mathf.Abs((360-Player.eulerAngles.x) - HidePram.eulerAngles.z);
      
        float HideDistance = 5f;

        if ((az>HideDistance)&&(alt>HideDistance))
        {
            MissionLayer.gameObject.SetActive(true);
        }
        else
        {
            MissionLayer.gameObject.SetActive(false);
        }
    }


    public void ChangeNorthDirection()
    {
        //NorthDirection.z = Player.eulerAngles.y;
        //NorthLayer.localEulerAngles = NorthDirection;
        
    }

    public void ChangeMissionDirection()
    {
        Vector3 dir = transform.position - Missionplace.position;
        NorthDirection.z = Player.eulerAngles.y;

        MissionDirection = Quaternion.LookRotation(dir);

        MissionDirection.z = -MissionDirection.y;
        MissionDirection.x = 0;
        MissionDirection.y = 0;

        //MissionLayer.rotation = MissionDirection * Quaternion.Euler(NorthDirection);

        MissionLayer.rotation = MissionDirection * Quaternion.Euler(0, 0, Player.eulerAngles.y);


    }
}
