﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scenes_M : MonoBehaviour
{

    public void Klik_Qiblat()
    {
        SceneManager.LoadScene(2);
    }

    public void Klik_GawangL()
    {
        SceneManager.LoadScene(1);
    }

    public void Klik_Ephim()
    {
        SceneManager.LoadScene(3);
    }

    public void Klik_fase()
    {
        SceneManager.LoadScene(4);
    }

    public void Klik_inText()
    {
        SceneManager.LoadScene(5);
    }

    public void Klik_gps()
    {
        SceneManager.LoadScene(6);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
