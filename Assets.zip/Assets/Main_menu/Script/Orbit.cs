﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Orbit : MonoBehaviour
{
    // Memanggil fungsi Hisab
    private Algo_ESP2000 eSP2000;
    
    // Variable Transfrom target
    public Transform target_cam;
    
    // The spherical coordinates Variable
    float radius;
    float azimuth;
    float altitude;
    float jarak;

    // Variable Koordinat
    double lt;
    double bt;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Vector3 transfrom object
    Vector3 posHilal = new Vector3();

    // when frist time open app
    [Obsolete]
    private void Start()
    {
        // sumbu Z
        radius = getSphericalCoordinates(this.transform.position);

        //get value Koordinat
        lt = -7;
        bt = 110;


    }

    // Update is called once per frame
    [Obsolete]
    void Update()
    {

        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        int jam = DateTime.Now.Hour;
        int mnt = DateTime.Now.Minute;

        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        int tz = currentOffset.Hours;

        // get altitude and azimuth dari fungsi ESP2000
        eSP2000 = gameObject.AddComponent<Algo_ESP2000>();

        double azimuth_d = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[7];
        azimuth = ((float)azimuth_d) * ((float)Mathf.PI / 180); // radian

        double altitude_d = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[8];
        altitude = ((float)altitude_d) * ((float)Mathf.PI / 180); // radian

        double jarak_d = eSP2000.Data_ELPmoon(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[9];
        jarak = ((float)jarak_d/10) * ((float)Mathf.PI / 180); // radian


        //--------------------Move Object Hilal-------------------------------
        // make transfrom position game object
        posHilal = ToCartesian();
        gameObject.transform.position = posHilal;

        //make rotate angle object to main camera
        Quaternion desiredrotation = Quaternion.LookRotation(target_cam.position - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, desiredrotation, 10 * Time.deltaTime);

    }


/// <summary>
/// 
/// </summary>
/// <param name="cartesian"></param>
/// <returns></returns>
/// 
    // how  convert cartasian coordinate to spherical coordinate
    float getSphericalCoordinates (Vector3 cartesian)
    {
        float r = Mathf.Sqrt(
           Mathf.Pow(cartesian.x, 2) +
           Mathf.Pow(cartesian.y, 2) +
           Mathf.Pow(cartesian.z, 2)
       );

        float phi = Mathf.Atan2(cartesian.z / cartesian.x, cartesian.x);
        float theta = Mathf.Acos(cartesian.y / r);

        if (cartesian.x < 0)
            phi += Mathf.PI;

        return r;
    }

    // how  convert spherical coordinate to cartasian coordinate
    public static void SphericalToCartesian(float radius, float polar, float elevation, out Vector3 outCart)
    {
        float a = radius * Mathf.Cos(elevation);
        outCart.x = a * Mathf.Cos(polar);
        outCart.y = radius * Mathf.Sin(elevation);
        outCart.z = a * Mathf.Sin(polar);
    }
    
    // ---input nilai jarak, azimuth dan altitude Bulan menjadi nilai kartesian (x,y,z)
    public Vector3 ToCartesian()
    {
        Vector3 res = new Vector3();
        SphericalToCartesian(jarak, 90, 0, out res);
        return res;
    }

}
