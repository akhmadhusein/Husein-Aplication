﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Android;

public class Input_Gps : MonoBehaviour
{

    public RectTransform lyt_data;
    public RectTransform img_load;
    public Text t_loading;
    public Button btb_next;

    public Text n_lati, n_long, n_alt;

    double latitude_gps = 0;
    double longitude_gps = 0;
    double altitude_gps = 0;

    bool get_coordinate = false;
    
   
    
    // Start is called before the first frame update
    void Start()
    {
        //izin penggunaan location service Android
        if (!Permission.HasUserAuthorizedPermission(Permission.FineLocation))
        {
            Permission.RequestUserPermission(Permission.FineLocation);
        }
        
        
        img_load.gameObject.SetActive(true);
        t_loading.gameObject.SetActive(true);
        lyt_data.gameObject.SetActive(false);
        btb_next.gameObject.SetActive(false);
        
        
        StartCoroutine(StartLocationService());


    }

    private IEnumerator StartLocationService()
    {
        if (!Input.location.isEnabledByUser)
        {
            Debug.Log("User has not enabled GPS");
            yield break;
        }

        Input.location.Start();
        int maxWait = 20;
        while (Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
        {
            yield return new WaitForSeconds(1);
            maxWait--;
        }

        if (maxWait < 1)
        {
            Debug.Log("Time Out");
            yield break;
        }

        if (Input.location.status == LocationServiceStatus.Failed)
        {
            Debug.Log("Unable to determin device location");
            yield break;
        }

        latitude_gps = Input.location.lastData.latitude;
        longitude_gps = Input.location.lastData.longitude;
        altitude_gps = Input.location.lastData.altitude;

        //menampilkan hasil di textview
        n_lati.text = ":  " + kederajat(latitude_gps);
        n_long.text = ":  " + kederajat(longitude_gps);
        n_alt.text = ":  " + Math.Round(altitude_gps) + "  mdpl";

        //menyimpan nilai koordinat ke variable public static
        StateNameController.stc_latitude = latitude_gps;
        StateNameController.stc_longitude = longitude_gps;
        StateNameController.stc_altitude = altitude_gps;

        get_coordinate = true;

        yield break; 
    }

    // Update is called once per frame
    void Update()
    {
        if (get_coordinate==false)
        {
            img_load.gameObject.SetActive(true);
            t_loading.gameObject.SetActive(true);
            lyt_data.gameObject.SetActive(false);
            btb_next.gameObject.SetActive(false);
        }
        else
        {
            img_load.gameObject.SetActive(false);
            t_loading.gameObject.SetActive(false);
            lyt_data.gameObject.SetActive(true);
            btb_next.gameObject.SetActive(true);
        }
    }


    //merubah bilangan desimal ke derajat
    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;
        string min_plus = " ";

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
            min_plus = "-";
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return min_plus + (int)Math.Abs(derajat) + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }
}
