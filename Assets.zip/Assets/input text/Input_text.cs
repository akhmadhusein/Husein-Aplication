﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Input_text : MonoBehaviour
{
    public InputField input_lat, input_long, input_alt;


    double latitude, longitude, altitude;

    private void Start()
    {
        
    }

    //ketika tombol next diclick
    public void Klik_next()
    {

        //mendapatkan nilai koordimat dari inputfield
        latitude = double.Parse(input_lat.text);
        longitude = double.Parse(input_long.text);
        altitude = double.Parse(input_alt.text);

        //menyimpan nilai koordinat ke variable public static
        StateNameController.stc_latitude = latitude;
        StateNameController.stc_longitude = longitude;
        StateNameController.stc_altitude = altitude;

        Debug.Log("BERHASIL");

        SceneManager.LoadScene(1);

    }


}
