﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Poros_rMat : MonoBehaviour
{
    // Memanggil fungsi Hisab
    private Algo_JeanMeeus JeanMeeus;

    // The spherical coordinates Variable
    float radius;
    float azimuth;
    float altitude;
    float jarak;

    // Variable Koordinat
    double lt;
    double bt;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Start is called before the first frame update
    [Obsolete]
    void Start()
    {
        //get value Koordinat
        lt = -7;
        bt = 110;


        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        double jam = DateTime.Now.Hour;
        double mnt = DateTime.Now.Minute;

        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        double tz = currentOffset.Hours;

        // get altitude and azimuth dari fungsi ESP2000
        JeanMeeus = gameObject.AddComponent<Algo_JeanMeeus>();

        double azimuth_d = JeanMeeus.Az_AltMatahari(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[1];
        azimuth = (float)azimuth_d + 90;

        double altitude_d = JeanMeeus.Az_AltMatahari(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[2];
        altitude = (float)altitude_d;

        //rotasi objek berdasarkan nilai azimuth dan altitude bulan
        transform.rotation = Quaternion.Euler(0, azimuth, altitude);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
