﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Zoom_Cam : MonoBehaviour
{
    public Slider slider;
    public Camera cam;
    float far = 450f;
    
    // Start is called before the first frame update
    void Start()
    {
        cam.farClipPlane = far;
    }

    // Update is called once per frame
    void Update()
    {
        cam.farClipPlane = slider.value;
    }
}
