﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class data_faseBln : MonoBehaviour
{

    //Memanggil Class Algo JeanMeeus
    private Algo_JeanMeeus jMeeus;

    // Variable Waktu
    [Obsolete]
    TimeZone localzone;

    // Variable Koordinat
    double lt;
    double bt;

	//Variable gambar fase bulan
	public GameObject gm_FaseBulan;

	public Sprite new_Moon, waxing_Crescent1, waxing_Crescent2,
		first_Quarter, waxing_Gibbous1, waxing_Gibbous2, full_Moon,
		waning_Gibbous1, waning_Gibbous2, last_Quarter, waning_Creacent1, waningCreacent2;


	//Variable game object Text
	public Text t_tanggal, t_haripasar,t_fasebulan;

    public Text t_az, t_alt, t_elong, t_ilumination;

    //Variable String data Matahari
    private string s_tanggal,s_fasebulan;

    private string s_az, s_alt, s_elong, s_ilumination;

	// Start is called before the first frame update
	[Obsolete]
	void Start()
	{

		// memanggil Class  Algo JeanMeeus
		jMeeus = gameObject.AddComponent<Algo_JeanMeeus>();

		// mendapatkan nilai koordinat tempat
		lt = StateNameController.stc_latitude;
		bt = StateNameController.stc_longitude;

		// mendapatkan nilai waktu
		DateTime sekarang = DateTime.Now;
		s_tanggal = sekarang.ToString("dd MMMM yyyy");
		

		// get Date Now
		int tahun = DateTime.Now.Year;
		int bulan = DateTime.Now.Month;
		int tgl = DateTime.Now.Day;
		Debug.Log("input tanggal : " + tgl + bulan + tahun);

		// get Time Now
		double jam = DateTime.Now.Hour;
		double mnt = DateTime.Now.Minute;
		//get TimeZone 
		localzone = TimeZone.CurrentTimeZone;
		DateTime currentDate = DateTime.Now;
		TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
		double tz = currentOffset.Hours;

		//------------MENGISI TANGGAL BULAN TAHUN HARI PASARAN----------------------------//
		//konversi tahun masehi ke hijriah
		string st_tanggalH = konversiTahun(tgl, bulan, tahun)[1];
		string st_bulanH = konversiTahun(tgl, bulan, tahun)[3];
		string st_tahunH = konversiTahun(tgl, bulan, tahun)[4];
		string st_kalHijriah = st_tanggalH + " " + st_bulanH + " " + st_tahunH + " H";

		// set Text tanggal
		t_tanggal.text = s_tanggal + " M" + " / " + st_kalHijriah;

		//mencari hari pasaran
		string st_hari = konversiTahun(tgl, bulan, tahun)[5];
		string st_pasaran = konversiTahun(tgl, bulan, tahun)[6];

		//set Text hari pasaran
		t_haripasar.text = st_hari + " " + st_pasaran;




		//-----------MENGISI DATA FASE BULAN----------------------------//


        //illumination
        double illum = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[8];
        s_ilumination = " " + illum.ToString("0.##") + " %";
        t_ilumination.text = s_ilumination;

        //azimut matahari
        double azmt = jMeeus.Az_AltBulan(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[1];
        s_az = kederajat(azmt);
        t_az.text = s_az;

        //altitude matahari
        double alt = jMeeus.Az_AltBulan(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[2];
        s_alt = kederajat(alt);
        t_alt.text = s_alt;

        //elongasi
        double elo = jMeeus.elongasi_BlnMth(lt, bt, tahun, bulan, tgl, jam, mnt, tz)[1];
        s_elong = kederajat(elo);
        t_elong.text = s_elong;

		//bujur bulan dan matahri 
		double bujur_bln = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[1];
		double bujur_mat = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, jam, mnt, tz)[9];
		double selisih_bjr = (bujur_bln - bujur_mat) % 360;



        //---------------------PEMBAGIAN FASE BULAN----------------------------------------------------//
       
		
		
		if (selisih_bjr >= 0 && selisih_bjr < 30)
        {
			s_fasebulan = "New Moon";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = new_Moon;

        }else if (selisih_bjr >= 30 && selisih_bjr < 60)
        {
			s_fasebulan = "Waxing Crescent";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waxing_Crescent1;

		}else if (selisih_bjr >= 60 && selisih_bjr < 90)
        {
			s_fasebulan = "Waxing Crescent";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waxing_Crescent2;

		}else if (selisih_bjr >= 90 && selisih_bjr < 120)
        {
			s_fasebulan = "First Quarter";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = first_Quarter;

		}else if (selisih_bjr >= 120 && selisih_bjr < 150)
        {
			s_fasebulan = "Waxing Gibbous";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waxing_Gibbous1;

		}else if (selisih_bjr >= 150 && selisih_bjr < 180)
        {
			s_fasebulan = "Waxing Gibbous";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waxing_Gibbous2;

		}else if (selisih_bjr >= 180 && selisih_bjr < 210)
        {
			s_fasebulan = "Full Moon";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = full_Moon;

		}else if (selisih_bjr >= 210 && selisih_bjr < 240)
        {
			s_fasebulan = "Waning Gibbous";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waning_Gibbous1;

		}else if (selisih_bjr >= 240 && selisih_bjr < 270)
        {
			s_fasebulan = "Waning Gibbous";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waning_Gibbous2;

		}else if (selisih_bjr >= 270 && selisih_bjr < 300)
        {
			s_fasebulan = "Last Quarter";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = last_Quarter;

		}else if (selisih_bjr >= 300 && selisih_bjr < 330)
        {
			s_fasebulan = "Waning Creacent";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waning_Creacent1;

		}else if (selisih_bjr > 330)
        {
			s_fasebulan = "Waning Creacent";
			t_fasebulan.text = s_fasebulan;
			gm_FaseBulan.GetComponent<Image>().sprite = waningCreacent2;
		}
	}

	// Update is called once per frame
	void Update()
    {

    }


    //menghitung hari dan pasaran
    public string[] konversiTahun (int tanggal, int bulan, int tahun)
    {
		//----------------------KONVERSI TAHUN MASEHI KE HIJRIAH-------------------//
		
		//D (G16)
		int D = tanggal;


		//M (G17)
		int M = 0;
		if (bulan < 3)
		{
			M = bulan + 12;
		}
		else { M = bulan; }

		//X (G18)
		int X = 0;
		if (bulan < 3)
		{
			X = tahun - 1;
		}
		else { X = tahun; }

		//alpha (G19)
		int alpha = (X / 100);

		//beta (G20)
		int beta = 2 - alpha + (alpha / 4);

		//b (G21)
		int b = (int)Math.Floor(365.25 * X) + (int)Math.Floor(30.6001 * (M + 1)) + D + 1722519 + beta;

		//c (G22)
		int c = (int)Math.Floor((b - 122.1) / 365.25);

		//d (G23)
		int d = (int)Math.Floor(365.25 * c);

		//e (G24)
		int e = (int)Math.Floor((b - d) / 30.6001);

		//Kalender (G25)
		//(keterangan) 1 = GREGORIAN, 2 = JULIAN, 3 = SALAH
		int Kalender = 1;
		if (tahun <= 1582)
		{
			if (bulan > 10 && tanggal >= 15)
			{
				Kalender = 1;
			}
			else if (bulan < 10 && tanggal <= 4)
			{
				Kalender = 2;
			}
			else { Kalender = 3; }
		}
		else { Kalender = 1; }

		//D (G26)
		if (Kalender == 1)
		{
			D = b - d - (int)(30.6001 * e);
		}
		else { D = tanggal; }

		//M (G27)
		if (Kalender == 1)
		{
			if (e < 14)
			{
				M = e - 1;
			}
			else { M = e - 13; }
		}
		else { M = bulan; }

		//X (G28)
		if (Kalender == 1)
		{
			if (M < 3)
			{
				X = c - 4715;
			}
			else { X = c - 4716; }
		}
		else { M = tahun; }

		//W (G29)
		int W = 0;
		if ((X % 4) == 0)
		{
			W = 1;
		}
		else { W = 2; }

		//N (G30)
		int N = (int)(275 * M / 9) - W * (int)((M + 9) / 12) + D - 30;
		Debug.Log("N : " + N);

		//A (G31)
		int A = X - 623;

		//B (G32)
		int B = (int)(A / 4);

		//C (G33)
		int C = A % 4;

		//C1 (G34)
		double C1 = (365.2501 * C);
		Debug.Log("C1 : " + C1);

		//C2 (G35)
		int C2 = (int)(C1);
		Debug.Log("C2 : " + C2);

		//C2i (I35)
		int C2i;
		if ((C1 - C2) > 0.5)
		{
			C2i = C2 + 1;
		}
		else { C2i = C2; }
		Debug.Log("C2i : " + C2i);

		//D' (G36)
		int D2 = 1461 * B + 170 + C2i;
		Debug.Log("D' : " + D2);

		//Q (G37)
		int Q = (int)(D2 / 10631);

		//R (G38)
		int R = D2 % 10631;
		Debug.Log("R : " + R);

		//J (G39)
		int J = (int)(R / 354);

		//K (G40)
		int K = R % 354;
		Debug.Log("K : " + K);

		//O (G41)
		int O = (int)((11 * J + 14) / 30);
		Debug.Log("O : " + O);

		//H (G42)
		int H = 30 * Q + J + 1;

		//JJ (G43)
		int JJ = K - O + N - 1;
		Debug.Log("JJ : " + JJ);

		//Hi (I42)
		int Hi = 0;
		if (JJ > 354)
		{
			Hi = H + 1;
   	 }
		else { Hi = H; }

		//CL (G44)
		int CL = H % 30;

		//DL (G45)
		int DL = (11 * CL + 3) % 30;

		//JJi (i43)
		int JJi = 0;
		if (JJ > 354)
		{
			if (DL < 19)
			{
				JJi = JJ - 354;
			}
			else { JJi = JJ - 355; }
		}
		else { JJi = JJ; }

		//Hk (K42)
		int Hk = 0;
		if (JJi == 0)
		{
			Hk = Hi - 1;
		}
		else { Hk = Hi; }
		Debug.Log("Hk : " + Hk);

		// JJk (K43)
		int JJk = 0;
		if (JJi == 0)
		{
			JJk = 355;
		}
		else { JJk = JJi; }
		Debug.Log("JJk : " + JJk);

		//S (G46)
		int S = (int)((JJk - 1) / 29.5);
		Debug.Log("s : " + S);

		//m (G47)
		int m = S + 1;

		//d (G48)
		int d_ = (int)(JJk - 29.5 * S);
		Debug.Log("d : " + d_);

		//mi (I47)
		int mi = 0;
		if (JJk == 355)
		{
			mi = 12;
		}
		else { mi = m; }

		//di (I48)
		int di = 0;
		if (JJk == 355)
		{
			di = 30;
		}
		else { di = d_; }

		int tgl = di;
		int bln = mi;
		int thn = Hk;

		//---------------MENGHITUNG HARI DAN PASARAN------------------//

		//M / Y
		int M_bln;
		int Y_thn;
        if (bulan < 3)
        {
			M_bln = bulan +12;
			Y_thn = tahun - 1;
        }
        else { 
			M_bln = bulan;
			Y_thn = tahun;
		}

		//A
		int A_hp = Y_thn / 100;

		//B
		int B_hp;
		if (tahun == 1582)
		{
			B_hp = 0;
		}
		else if(tahun == 1582 && bulan == 10)
        {
			B_hp = 0;
        }else if(tahun == 1582 && bulan == 10 && tanggal < 5)
        {
			B_hp = 0;
        }
        else { B_hp = 2 - A_hp + (int)(A_hp / 4); }

		//Julian Day
		double JulianDay;
		JulianDay = 1720994.5 + (int)(365.25 * Y_thn)
				 + (int)(30.6001 * (M_bln + 1)) + tanggal + B_hp;

		//Nomor Hari
		int n_Hari = (int)((JulianDay + 1.5) % 7)+1;
		Debug.Log("n_Hari : " + n_Hari);

		//Nomor Pasaran
		int n_Pasaran = (int)((JulianDay + 1.5) % 5)+1;
		Debug.Log("n_Pasaran : " + n_Pasaran);

		//--------------------NAMA BULAN HARI PASARAN-------------------------------//

		//BULAN
		string nm_bulan="error";
		switch (bln)
        {
			case 1:
				nm_bulan = "Muharram";
				break;
			case 2:
				nm_bulan = "Safar";
				break;
			case 3:
				nm_bulan = "Rabi'ul Awal";
				break;
			case 4:
				nm_bulan = "Rabi'ul Akhir";
				break;
			case 5:
				nm_bulan = "Jumadil Awal";
				break;
			case 6:
				nm_bulan = "Jumadil Akhir";
				break;
			case 7:
				nm_bulan = "Rajab";
				break;
			case 8:
				nm_bulan = "Sya'ban";
				break;
			case 9:
				nm_bulan = "Ramadhan";
				break;
			case 10:
				nm_bulan = "Syawal";
				break;
			case 11:
				nm_bulan = "Dzulqaidah";
				break;
			case 12:
				nm_bulan = "Dzulhijah";
				break;
        }

		//HARI
		string nm_Hari="error";
		switch (n_Hari)
		{
			case 1:
				nm_Hari = "Ahad";
				break;
			case 2:
				nm_Hari = "Senin";
				break;
			case 3:
				nm_Hari = "Selasa";
				break;
			case 4:
				nm_Hari = "Rabu";
				break;
			case 5:
				nm_Hari = "Kamis";
				break;
			case 6:
				nm_Hari = "Jumat";
				break;
			case 7:
				nm_Hari = "Sabtu";
				break;
			
		}

		//PASARAN
		string nm_Pasaran="error";
		switch (n_Pasaran)
		{
			case 1:
				nm_Pasaran = "Kliwon";
				break;
			case 2:
				nm_Pasaran = "Legi";
				break;
			case 3:
				nm_Pasaran = "Pahing";
				break;
			case 4:
				nm_Pasaran = "Pon";
				break;
			case 5:
				nm_Pasaran = "Wage";
				break;
			
		}


		return new string[]
		{
			"error", tgl.ToString(),bln.ToString(), nm_bulan,
			thn.ToString(), nm_Hari,nm_Pasaran
		};
	}


    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;
        string min_plus = " ";

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
            min_plus = "-";
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return min_plus + (int)Math.Abs(derajat) + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }
}
