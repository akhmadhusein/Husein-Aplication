﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Algo_ESP2000 : MonoBehaviour
{
    //memanggil class Algo_Jean Meeus
    private Algo_JeanMeeus algo_Jean;

    // fungsi MOD
    static double MOD(double a1, double a2)
	{
		double hasiln1 = a1 / a2;
		double hasilint = System.Math.Floor(hasiln1);
		double hasiln2 = hasiln1 - hasilint;
		double hasil = hasiln2 * a2;
		return hasil;
	}

    // Perhitungan Utama
    public double[] Data_ELPmoon(double LT, double BT, int thn, int bln, int tgl, double jam, double mnt, double tz)
    {

        //variable DATE
        int tanggal = tgl;
        int bulan = bln;
        int tahun = thn;
        double timezone = tz;

        // variable Time
        double jam1 = jam;
        double menit1 = mnt;
        double detik1 = 0;
        double pukul_keJD = (jam1 * 3600 + (menit1 * 60) + detik1) / 86400;

        // Variable koordinat
        double lintangT = LT;
        double lintang_r = System.Math.PI / 180 * (LT);

        double bujur = BT;

        // waktu lokal ke UT
        int UT = (int)(jam1 - timezone);

        // hitung nilai julian
        if (bulan <= 2) { bulan += 12; tahun -= 1; }
        int A = 0;
        int B = 0;

        // koreksi kalender gregorian
        if (tahun > 1582)
        {
            A = (tahun / 100);
            B = 2 + (A / 4) - A;
        }
        double JD = 1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24);
        double JD_UT = (1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24));

        // menghitung DeltaT
        double waktu = (jam1 + menit1 / 60 + 0 / 3600) - timezone;
        double delta_T = 0;

        if (tahun < -500)
        {
            delta_T = (-20 + 32 * System.Math.Pow((tahun / 100 - 18.2), 2)) / 3600 / 24;
        }
        else if (tahun >= -500 && tahun < 500)
        {
            delta_T = (10583.6 - 1014.41 * (tahun / 100) + 33.78311 * System.Math.Pow((tahun / 100), 2) - 5) / 3600 / 24;
        }
        else if (tahun >= 500 && tahun < 1600)
        {
            delta_T = (1574.2 - 556.01 * (tahun / 100 - 10) + 71.23472 * System.Math.Pow((tahun / 100 - 10), 2) + 0.319781 * System.Math.Pow((tahun / 100 - 10), 3) - 0.8503463 * System.Math.Pow((tahun / 100 - 10), 4) - 0.00505998 * System.Math.Pow((tahun / 100 - 10), 5) + 0.0083572073 * System.Math.Pow((tahun / 100 - 10), 6)) / 3600 / 24;
        }
        else if (tahun >= 1600 && tahun < 1700)
        {
            delta_T = (120 - 0.9808 * (tahun - 1600) - 0.01532 * System.Math.Pow((tahun - 1600), 2) + System.Math.Pow((tahun - 1600), 3) / 7129) / 3600 / 24;
        }
        else if (tahun >= 1700 && tahun < 1800)
        {
            delta_T = (8.83 + 0.1603 * (tahun - 1700) - 0.0059285 * System.Math.Pow((tahun - 1700), 2) + 0.00013336 * System.Math.Pow((tahun - 1700), 3) - System.Math.Pow((tahun - 1700), 4) / 1174000) / 3600 / 24;
        }
        else if (tahun >= 1800 && tahun < 1860)
        {
            delta_T = (13.72 - 0.332447 * (tahun - 1800) + 0.0068612 * System.Math.Pow((tahun - 1800), 2) + 0.0041116 * System.Math.Pow((tahun - 1800), 3) - 0.00037436 * System.Math.Pow((tahun - 1800), 4) + 0.0000121272 * System.Math.Pow((tahun - 1800), 5) - 0.0000001699 * System.Math.Pow((tahun - 1800), 6) + 0.000000000875 * System.Math.Pow((tahun - 1800), 7)) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1860 && tahun < 1900)
        {
            delta_T = (7.62 + 0.5737 * (tahun - 1860) - 0.251754 * System.Math.Pow((tahun - 1860), 2) + 0.01680668 * System.Math.Pow((tahun - 1860), 3) - 0.0004473624 * System.Math.Pow((tahun - 1860), 4) + System.Math.Pow((tahun - 1850), 5) / 233174) / 3600 / 24;
        }
        else if (tahun >= 1900 && tahun < 1920)
        {
            delta_T = (-2.79 + 1.494119 * (tahun - 1900) - 0.0598939 * System.Math.Pow((tahun - 1900), 2) + 0.0061966 * System.Math.Pow((tahun - 1900), 3) - 0.000197 * System.Math.Pow((tahun - 1900), 4)) / 3600 / 24;
        }
        else if (tahun >= 1920 && tahun < 1941)
        {
            delta_T = (21.2 + 0.84493 * (tahun - 1920) - 0.0761 * System.Math.Pow((tahun - 1920), 2) + 0.0020936 * System.Math.Pow((tahun - 1920), 3)) / 3600 / 24;
        }
        else if (tahun >= 1941 && tahun < 1961)
        {
            delta_T = (29.07 + 0.407 * (tahun - 1950) - System.Math.Pow((tahun - 1950), 2) / 233 + System.Math.Pow((tahun - 1950), 3) / 2547) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1961 && tahun < 1986)
        {
            delta_T = (45.45 + 1.067 * (tahun - 1975) - System.Math.Pow((tahun - 1975), 2) / 260 - System.Math.Pow((tahun - 1975), 3) / 718) / 3600 / 24;
        }
        else if (tahun >= 1986 && tahun < 2005)
        {
            delta_T = (63.86 + 0.3345 * (tahun - 2000) - 0.060374 * System.Math.Pow((tahun - 2000), 2) + 0.0017275 * System.Math.Pow((tahun - 2000), 3) + 0.000651814 * System.Math.Pow((tahun - 2000), 4) + 0.00002373599 * System.Math.Pow((tahun - 2000), 5)) / 3600 / 24;
        }
        else if (tahun >= 2005 && tahun < 2050)
        {
            delta_T = (62.92 + 0.32217 * ((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000) + 0.005589 * System.Math.Pow(((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000), 2)) / 3600 / 24;
        }
        else if (tahun >= 2050 && tahun < 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2) - 0.5628 * (2150 - tahun)) / 3600 / 24;
        }
        else if (tahun >= 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2)) / 3600 / 24;
        }
        else
        {
            delta_T = 0.0000;
        };

        //JDE waktu TD(Dynamical time)
        double jde = JD_UT + delta_T;

        double T_UT = (JD_UT - 2451545) / 36525;
        double T_TD = (jde - 2451545) / 36525;
        double tau = T_TD / 10;

        // Greenwich sideral time
        double gst0 = 6.6973745583 + 2400.0513369072 * T_TD + 0.0000258622 * T_TD * T_TD;

        //fungsi MOD(?) kalou di Excel/LibreCalc
        if (gst0 < 0)
        {
            while (gst0 < 0)
            {
                gst0 += 24;
            }
        }
        else if (gst0 > 24)
        {
            while (gst0 > 24)
            {
                gst0 -= 24;
            }
        }

        double gstUT = gst0 + 1.0027379035 * UT;
        double gstLokal = ((gst0 + ((jam1 + (menit1 / 60) + (detik1 / 3600) - timezone)) * 1.00273790935)) % 24;
        if (gstUT >= 24) gstUT -= 24;
        gstLokal /= 15;

        //lokal sideral time
        double LST = 0;
        if (bujur > 0) LST = gstLokal + (bujur / 15);
        else LST = gstLokal - (bujur / 15);

        if (LST >= 24) LST -= 24;
        double gstpukul = (280.46061837 + 360.98564736629 * (JD_UT - 2451545) + 0.000387933 * T_UT * T_UT - T_UT * T_UT * T_UT / 38710000) % 360;
        if (gstpukul < 0) gstLokal += 360;
        gstpukul /= 15;



        //--- Menghitung DELTA PSI dan NUTASI ----------------
        double tete = T_TD;

        double debesar = MOD((297.85036 + 445267.11148 * tete - 0.0019142 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 189474), 360);
        double embesar = MOD((357.52772 + 35999.05034 * tete - 0.0001603 * System.Math.Pow(tete, 2) - System.Math.Pow(tete, 3) / 300000), 360);
        double emaksen = MOD((134.96298 + 477198.867398 * tete + 0.0086972 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 56250), 360);
        double efbesar = MOD((93.27191 + 483202.017538 * tete - 0.0036825 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 327270), 360);
        double omega2 = MOD((125.04452 - 1934.136261 * tete + 0.0020708 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 450000), 360);
        double u = tete / 100;
        double epsilonZero = 23.43929111 - (4680.93 * u - 1.55 * System.Math.Pow(u, 2) + 1999.25 * System.Math.Pow(u, 3) - 51.38 * System.Math.Pow(u, 4) - 249.67 * System.Math.Pow(u, 5) - 39.05 * System.Math.Pow(u, 6) + 7.12 * System.Math.Pow(u, 7) + 27.87 * System.Math.Pow(u, 8) + 5.79 * System.Math.Pow(u, 9) + 2.45 * System.Math.Pow(u, 10)) / 3600;


        //koreksi ASI
        double korn1 = (-171996 + -174.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn2 = (-13187 + -1.6 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn3 = (-2274 + -0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn4 = (2062 + 0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn5 = (1426 + -3.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn6 = (712 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn7 = (517 + 1.2 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn8 = (-386 + -0.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn9 = (217 + -0.5 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn10 = (129 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn11 = (63 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn12 = (-58 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn13 = (17 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn14 = (-16 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn15 = (-301 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn16 = (-158 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn17 = (123 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn18 = (63 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn19 = (-59 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn20 = (-51 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn21 = (48 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn22 = (46 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn23 = (-38 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn24 = (-31 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn25 = (29 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn26 = (29 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn27 = (26 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn28 = (-22 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn29 = (21 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn30 = (16 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn31 = (-15 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn32 = (-13 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn33 = (-12 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn34 = (11 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn35 = (-10 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn36 = (-8 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn37 = (7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn38 = (-7 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn39 = (-7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn40 = (-7 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn41 = (6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn42 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn43 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn44 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn45 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn46 = (5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn47 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn48 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn49 = (-5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn50 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn51 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn52 = (4 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn53 = (-4 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn54 = (-4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn55 = (-4 + 0 * tete) * System.Math.Sin(1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn56 = (3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn57 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn58 = (-3 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn59 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn60 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn61 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn62 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 3 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn63 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));

        double jumlahkorn = korn1 + korn2 + korn3 + korn4 + korn5 + korn6 + korn7 + korn8 + korn9 + korn10 + korn11 + korn12 + korn13 + korn14 + korn15 + korn16 + korn17 + korn18 + korn19 + korn20
                + korn21 + korn22 + korn23 + korn24 + korn25 + korn26 + korn27 + korn28 + korn29 + korn30
                + korn31 + korn32 + korn33 + korn34 + korn35 + korn36 + korn37 + korn38 + korn39 + korn40
                + korn41 + korn42 + korn43 + korn44 + korn45 + korn46 + korn47 + korn48 + korn49 + korn50
                + korn51 + korn52 + korn53 + korn54 + korn55 + korn56 + korn57 + korn58 + korn59 + korn60 + korn61 + korn62 + korn63;

        //lanjuTan koreksi ASI
        double segpeg = jumlahkorn / 10000 / 3600;
        double deltaPsi = segpeg;

        //koreksi delta epsilon
        double kord1 = (92025 + 8.9 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord2 = (5736 + -3.1 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord3 = (977 + -0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord4 = (-895 + 0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord5 = (54 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord6 = (224 + -0.6 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord7 = (129 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord8 = (-95 + 0.3 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord9 = (-7 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord10 = (200 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord11 = (-70 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord12 = (-53 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord13 = (-33 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord14 = (26 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord15 = (32 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord16 = (27 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord17 = (-24 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord18 = (16 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord19 = (13 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord20 = (-12 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord21 = (-10 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord22 = (-8 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord23 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord24 = (9 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord25 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord26 = (6 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord27 = (5 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord28 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord29 = (-3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord30 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord31 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord32 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord33 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord34 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord35 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord36 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord37 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord38 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double jumlahkord = kord1 + kord2 + kord3 + kord4 + kord5 + kord6 + kord7 + kord8 + kord9 + kord10
                + kord11 + kord12 + kord13 + kord14 + kord15 + kord16 + kord17 + kord18 + kord19 + kord20
                + kord21 + kord22 + kord23 + kord24 + kord25 + kord26 + kord27 + kord28 + kord29 + kord30
                + kord31 + kord32 + kord33 + kord34 + kord35 + kord36 + kord37 + kord38;

        //lanjuTan koreksi delta epsilon
        double segep = jumlahkord / 10000 / 3600;
        double epsilon = epsilonZero + segep;
        double epsilon_r = System.Math.PI / 180 * (epsilon);

        double gstnampak = gstpukul + deltaPsi * System.Math.Cos(epsilon_r) / 15;
        double lstnampak = (gstnampak + bujur / 15) % 24;
        if (lstnampak < 0) lstnampak += 24;


        // Bujur rata2 Bulan
        double L1 = (218.3164591 + 481267.88134236 * T_TD - 0.0013268 * T_TD * T_TD + T_TD * T_TD * T_TD / 538841 - T_TD * T_TD * T_TD * T_TD / 65194000) % 360;


        // Koreksi Bujur Bulan
        double koreksibujurB = lambdaBulan(T_TD, L1);

        double bujurB_nampak = (lambdaBulan(T_TD, L1) + deltaPsi) % 360;
        if (bujurB_nampak < 0) bujurB_nampak += 360;
        double bujurB_nampak_r = System.Math.PI / 180 * (bujurB_nampak);
        //Koreksi lintang bulan
        double lintangB = linTangBulan(T_TD);
        double lintangB_r = System.Math.PI / 180 * (lintangB);
        //Koreksi jarak bumi-bulan
        double jarakBB = jarakBulan(T_TD);

        //alpha Bulan
        double alphaBulan = (180/System.Math.PI * (System.Math.Atan2(System.Math.Sin(bujurB_nampak_r) * System.Math.Cos(epsilon_r) - System.Math.Tan(lintangB_r) * System.Math.Sin(epsilon_r), System.Math.Cos(bujurB_nampak_r)))) % 360;
        double alphaBulan_r = System.Math.PI / 180 * (alphaBulan);
        if (alphaBulan < 0) alphaBulan = (alphaBulan + 360) % 360;
        double alphaBulanPukul = alphaBulan / 15;

        // sudut paralaks bulan
        double sudutParalaksB = 180/System.Math.PI * (System.Math.Asin(6378.14 / jarakBB));
        double sudutJariB = 358473400 / (jarakBB * 3600);

        //delta Bulan
        double deltaBulan = 180/System.Math.PI * (System.Math.Asin(System.Math.Sin(lintangB_r) * System.Math.Cos(epsilon_r) + System.Math.Cos(lintangB_r) * System.Math.Sin(epsilon_r) * System.Math.Sin(bujurB_nampak_r)));
        double deltaBulan_r = System.Math.PI / 180 * (deltaBulan);

        // sudut waktu
        double hourAngleBulan = lstnampak * 15 - alphaBulan;
        double haBulan_r = System.Math.PI / 180 * (hourAngleBulan);

        // azimuth Bulan
        double azimuthBulanS = 180/System.Math.PI * (System.Math.Atan2(System.Math.Sin(haBulan_r), System.Math.Cos(haBulan_r) * System.Math.Sin(lintang_r) - System.Math.Tan(deltaBulan_r) * System.Math.Cos(lintang_r)));
        double azimuthBulan = (azimuthBulanS + 180) % 360;

        // altitude Bulan
        double altitudeB = 180/System.Math.PI * (System.Math.Asin(System.Math.Sin(lintang_r) * System.Math.Sin(deltaBulan_r) + System.Math.Cos(lintang_r) * System.Math.Cos(deltaBulan_r) * System.Math.Cos(haBulan_r)));




        //MENGHITUNG ILUMINASI BULAN--------------------------------------------------------------------------------------------------#

        algo_Jean = gameObject.AddComponent<Algo_JeanMeeus>();

        //alpha Matahari
        var alphaMatahari = algo_Jean.Data_Algo_JeanMeeus(tahun, bulan, tanggal, jam1, menit1, tz)[11];
        double alphaMatahari_r = System.Math.PI / 180 * (alphaMatahari);

        //beta Matahari
        var deltaMatahari = algo_Jean.Data_Algo_JeanMeeus(tahun, bulan, tanggal, jam1, menit1, tz)[12];
        double deltaMatahari_r = System.Math.PI / 180 * (deltaMatahari);

        //jarak Matahari ke Bumi
        double jarak_MkeB= (algo_Jean.Data_Algo_JeanMeeus(tahun, bulan, tanggal, jam1, menit1, tz)[13])* 149598000;


        //Sudut fai
        double sdt_fai = System.Math.Acos(System.Math.Sin(deltaBulan_r) * System.Math.Sin(deltaMatahari_r) + System.Math.Cos(deltaBulan_r) * System.Math.Cos(deltaMatahari_r) * System.Math.Cos(alphaBulan_r - alphaMatahari_r));
        double sdt_fase = System.Math.Atan2(jarakBB - jarak_MkeB * System.Math.Cos(sdt_fai), jarak_MkeB * System.Math.Sin(sdt_fai));

        //Iluminasi Bulan (k)
        double ilu_bulan = 100 * (1 + System.Math.Cos(sdt_fase)) / 2;






        // Variable Hasil data Bulan ELP2000 dan nomer urut arrays
        double bApp_Longitude = bujurB_nampak; //1
        double bApp_Latitude = lintangB; //2
        double bRight_Ascensio = alphaBulan; //3
        double bApp_Declination = deltaBulan; //4
        double bSemi_Diameter = sudutJariB; //5
        double bH_Parallax = sudutParalaksB; //6
        double bAzimuth = azimuthBulan; //7
        double bAltitude = altitudeB; //8
		double bdistance = jarakBB; //9
        double bIlumination = ilu_bulan; //10

        //mengembalikan nilai dengan arayys
        return new double[]
        {
        0,bApp_Longitude,bApp_Latitude,bRight_Ascensio,bApp_Declination
        ,bSemi_Diameter,bH_Parallax,bAzimuth,bAltitude,bdistance,bIlumination
        };

    }


//---------------- DATA KOREKSI -------------------------------------


    // fungsi koreksi linTang Bulan
    public double linTangBulan(double T)
    {

        double B = 0;
        B += 5.12812186 * System.Math.Sin(System.Math.PI / 180 * (93.2720993 + 483202.0175 * T + -34.029 * 0.0001 * T + -0.284 * 0.000001 * T * T + 0.116 * 0.00000001 * T * T * T * T));
        B += 0.28060196 * System.Math.Sin(System.Math.PI / 180 * (228.2355107 + 960400.8852 * T + 55.941 * 0.0001 * T + 14.064 * 0.000001 * T * T + -6.681 * 0.00000001 * T * T * T * T));
        B += 0.27769266 * System.Math.Sin(System.Math.PI / 180 * (41.6913121 + -6003.149896 * T + 123.999 * 0.0001 * T + 14.631 * 0.000001 * T * T + -6.913 * 0.00000001 * T * T * T * T));
        B += 0.17323679 * System.Math.Sin(System.Math.PI / 180 * (142.4283091 + 407332.2055 * T + 1.429 * 0.0001 * T + 3.948 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += 0.05541215 * System.Math.Sin(System.Math.PI / 180 * (194.0090963 + 896537.3729 * T + -156.6 * 0.0001 * T + -10.967 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += 0.04627058 * System.Math.Sin(System.Math.PI / 180 * (7.4648977 + -69866.66213 * T + -88.542 * 0.0001 * T + -10.4 * 0.000001 * T * T + 4.913 * 0.00000001 * T * T * T * T));
        B += 0.03257241 * System.Math.Sin(System.Math.PI / 180 * (328.9725077 + 1373736.241 * T + -66.63 * 0.0001 * T + 3.38 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += 0.01719776 * System.Math.Sin(System.Math.PI / 180 * (3.1989221 + 1437599.753 * T + 145.911 * 0.0001 * T + 28.411 * 0.000001 * T * T + -13.479 * 0.00000001 * T * T * T * T));
        B += 0.00926589 * System.Math.Sin(System.Math.PI / 180 * (277.3917205 + 884531.0731 * T + 91.399 * 0.0001 * T + 18.295 * 0.000001 * T * T + -8.682 * 0.00000001 * T * T * T * T));
        B += 0.00882213 * System.Math.Sin(System.Math.PI / 180 * (176.6547234 + 471195.7177 * T + 213.97 * 0.0001 * T + 28.979 * 0.000001 * T * T + -13.71 * 0.00000001 * T * T * T * T));
        B += 0.00821572 * System.Math.Sin(System.Math.PI / 180 * (144.8991999 + 371333.1552 * T + 2.964 * 0.0001 * T + 3.907 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += 0.00432396 * System.Math.Sin(System.Math.PI / 180 * (232.5014863 + -547065.5298 * T + -178.512 * 0.0001 * T + -24.748 * 0.000001 * T * T + 11.71 * 0.00000001 * T * T * T * T));
        B += 0.00420043 * System.Math.Sin(System.Math.PI / 180 * (103.9359191 + 1850935.108 * T + 23.341 * 0.0001 * T + 17.728 * 0.000001 * T * T + -8.45 * 0.00000001 * T * T * T * T));
        B += -0.00335948 * System.Math.Sin(System.Math.PI / 180 * (139.9574183 + 443331.2558 * T + -0.107 * 0.0001 * T + 3.988 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += 0.00246337 * System.Math.Sin(System.Math.PI / 180 * (196.4799872 + 860538.3226 * T + -155.064 * 0.0001 * T + -11.008 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += 0.00221071 * System.Math.Sin(System.Math.PI / 180 * (331.4433985 + 1337737.19 * T + -65.094 * 0.0001 * T + 3.339 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += 0.00206515 * System.Math.Sin(System.Math.PI / 180 * (9.9357885 + -105865.7124 * T + -87.006 * 0.0001 * T + -10.441 * 0.000001 * T * T + 4.913 * 0.00000001 * T * T * T * T));
        B += -0.00186984 * System.Math.Sin(System.Math.PI / 180 * (129.2935985 + -924401.8349 * T + -57.477 * 0.0001 * T + -14.023 * 0.000001 * T * T + 6.681 * 0.00000001 * T * T * T * T));
        B += 0.00182766 * System.Math.Sin(System.Math.PI / 180 * (243.1653061 + 820667.5609 * T + -121.142 * 0.0001 * T + -6.736 * 0.000001 * T * T + 3.144 * 0.00000001 * T * T * T * T));
        B += -0.00179446 * System.Math.Sin(System.Math.PI / 180 * (90.8012085 + 519201.0678 * T + -35.565 * 0.0001 * T + -0.243 * 0.000001 * T * T + 0.116 * 0.00000001 * T * T * T * T));
        B += -0.00174902 * System.Math.Sin(System.Math.PI / 180 * (279.816298 + 1449606.053 * T + -102.088 * 0.0001 * T + -0.851 * 0.000001 * T * T + 0.348 * 0.00000001 * T * T * T * T));
        B += -0.00156454 * System.Math.Sin(System.Math.PI / 180 * (315.8377971 + 42002.20019 * T + -125.535 * 0.0001 * T + -14.59 * 0.000001 * T * T + 6.913 * 0.00000001 * T * T * T * T));
        B += -0.00149122 * System.Math.Sin(System.Math.PI / 180 * (31.1223035 + 928469.129 * T + -50.329 * 0.0001 * T + 1.548 * 0.000001 * T * T + -0.769 * 0.00000001 * T * T * T * T));
        B += -0.00147535 * System.Math.Sin(System.Math.PI / 180 * (225.7646199 + 996399.9354 * T + 54.405 * 0.0001 * T + 14.105 * 0.000001 * T * T + -6.681 * 0.00000001 * T * T * T * T));
        B += -0.00140998 * System.Math.Sin(System.Math.PI / 180 * (39.2204212 + 29995.9004 * T + 122.464 * 0.0001 * T + 14.672 * 0.000001 * T * T + -6.913 * 0.00000001 * T * T * T * T));
        B += -0.00134434 * System.Math.Sin(System.Math.PI / 180 * (264.2570099 + -447202.9672 * T + 32.493 * 0.0001 * T + 0.324 * 0.000001 * T * T + -0.116 * 0.00000001 * T * T * T * T));
        B += -0.00133493 * System.Math.Sin(System.Math.PI / 180 * (204.5781049 + -37934.90601 * T + 17.729 * 0.0001 * T + 2.116 * 0.000001 * T * T + -1 * 0.00000001 * T * T * T * T));
        B += 0.00110668 * System.Math.Sin(System.Math.PI / 180 * (138.1623335 + 1914798.62 * T + 235.882 * 0.0001 * T + 42.759 * 0.000001 * T * T + -20.276 * 0.00000001 * T * T * T * T));
        B += 0.00102068 * System.Math.Sin(System.Math.PI / 180 * (18.1287175 + 1297866.429 * T + -31.172 * 0.0001 * T + 7.611 * 0.000001 * T * T + -3.654 * 0.00000001 * T * T * T * T));
        B += 0.00083291 * System.Math.Sin(System.Math.PI / 180 * (69.7095047 + 1787071.596 * T + -189.201 * 0.0001 * T + -7.303 * 0.000001 * T * T + 3.375 * 0.00000001 * T * T * T * T));
        B += 0.0007774 * System.Math.Sin(System.Math.PI / 180 * (215.1471134 + -972407.185 * T + 192.058 * 0.0001 * T + 15.198 * 0.000001 * T * T + -7.145 * 0.00000001 * T * T * T * T));
        B += 0.00067052 * System.Math.Sin(System.Math.PI / 180 * (294.7460934 + 1309872.728 * T + -279.171 * 0.0001 * T + -21.651 * 0.000001 * T * T + 10.173 * 0.00000001 * T * T * T * T));
        B += 0.00060731 * System.Math.Sin(System.Math.PI / 180 * (315.8841104 + -559071.8295 * T + 69.487 * 0.0001 * T + 4.515 * 0.000001 * T * T + -2.116 * 0.00000001 * T * T * T * T));
        B += 0.00059616 * System.Math.Sin(System.Math.PI / 180 * (52.3551318 + 1361729.941 * T + 181.369 * 0.0001 * T + 32.643 * 0.000001 * T * T + -15.479 * 0.00000001 * T * T * T * T));
        B += 0.00049055 * System.Math.Sin(System.Math.PI / 180 * (279.8626113 + 848532.0228 * T + 92.935 * 0.0001 * T + 18.254 * 0.000001 * T * T + -8.682 * 0.00000001 * T * T * T * T));
        B += -0.00045123 * System.Math.Sin(System.Math.PI / 180 * (59.045685 + 419338.5053 * T + -246.57 * 0.0001 * T + -25.315 * 0.000001 * T * T + 11.941 * 0.00000001 * T * T * T * T));
        B += 0.00043925 * System.Math.Sin(System.Math.PI / 180 * (311.6181348 + 948394.5854 * T + 303.94 * 0.0001 * T + 43.326 * 0.000001 * T * T + -20.507 * 0.00000001 * T * T * T * T));
        B += 0.00042215 * System.Math.Sin(System.Math.PI / 180 * (238.8993305 + 2328133.976 * T + 113.311 * 0.0001 * T + 32.075 * 0.000001 * T * T + -15.248 * 0.00000001 * T * T * T * T));
        B += 0.00042101 * System.Math.Sin(System.Math.PI / 180 * (97.5380749 + -1024264.397 * T + -268.482 * 0.0001 * T + -39.095 * 0.000001 * T * T + 18.507 * 0.00000001 * T * T * T * T));
        B += -0.00036606 * System.Math.Sin(System.Math.PI / 180 * (191.5382055 + 932536.4232 * T + -158.136 * 0.0001 * T + -10.926 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += -0.00035119 * System.Math.Sin(System.Math.PI / 180 * (326.5016169 + 1409735.291 * T + -68.166 * 0.0001 * T + 3.421 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += 0.00033108 * System.Math.Sin(System.Math.PI / 180 * (204.6729161 + 2264270.464 * T + -99.23 * 0.0001 * T + 7.044 * 0.000001 * T * T + -3.422 * 0.00000001 * T * T * T * T));
        B += 0.00031517 * System.Math.Sin(System.Math.PI / 180 * (106.4068099 + 1814936.058 * T + 24.876 * 0.0001 * T + 17.687 * 0.000001 * T * T + -8.45 * 0.00000001 * T * T * T * T));
        B += 0.00030161 * System.Math.Sin(System.Math.PI / 180 * (147.3700907 + 335334.1049 * T + 4.5 * 0.0001 * T + 3.866 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += -0.00028316 * System.Math.Sin(System.Math.PI / 180 * (54.7797093 + 1926804.92 * T + -12.117 * 0.0001 * T + 13.497 * 0.000001 * T * T + -6.45 * 0.00000001 * T * T * T * T));
        B += -0.00022853 * System.Math.Sin(System.Math.PI / 180 * (274.9208296 + 920530.1234 * T + 89.863 * 0.0001 * T + 18.336 * 0.000001 * T * T + -8.682 * 0.00000001 * T * T * T * T));
        B += 0.00022339 * System.Math.Sin(System.Math.PI / 180 * (202.1072141 + -1935.85572 * T + 16.193 * 0.0001 * T + 2.156 * 0.000001 * T * T + -1 * 0.00000001 * T * T * T * T));
        B += 0.00022294 * System.Math.Sin(System.Math.PI / 180 * (28.6514127 + 964468.1793 * T + -51.865 * 0.0001 * T + 1.589 * 0.000001 * T * T + -0.769 * 0.00000001 * T * T * T * T));
        B += -0.00022033 * System.Math.Sin(System.Math.PI / 180 * (354.3301871 + -1401600.702 * T + -147.447 * 0.0001 * T + -28.371 * 0.000001 * T * T + 13.479 * 0.00000001 * T * T * T * T));
        B += -0.00021973 * System.Math.Sin(System.Math.PI / 180 * (4.9940069 + -33867.61183 * T + -90.077 * 0.0001 * T + -10.359 * 0.000001 * T * T + 4.913 * 0.00000001 * T * T * T * T));
        B += -0.00018539 * System.Math.Sin(System.Math.PI / 180 * (166.0857149 + 1405667.997 * T + 39.641 * 0.0001 * T + 15.896 * 0.000001 * T * T + -7.566 * 0.00000001 * T * T * T * T));
        B += 0.00018062 * System.Math.Sin(System.Math.PI / 180 * (234.9723771 + -583064.58 * T + -176.976 * 0.0001 * T + -24.788 * 0.000001 * T * T + 11.71 * 0.00000001 * T * T * T * T));
        B += -0.00017745 * System.Math.Sin(System.Math.PI / 180 * (0.7280313 + 1473598.803 * T + 144.376 * 0.0001 * T + 28.452 * 0.000001 * T * T + -13.479 * 0.00000001 * T * T * T * T));
        B += 0.00017603 * System.Math.Sin(System.Math.PI / 180 * (108.2018947 + 343468.6933 * T + -211.113 * 0.0001 * T + -21.084 * 0.000001 * T * T + 9.941 * 0.00000001 * T * T * T * T));
        B += 0.00016549 * System.Math.Sin(System.Math.PI / 180 * (245.6361969 + 784668.5106 * T + -119.606 * 0.0001 * T + -6.777 * 0.000001 * T * T + 3.144 * 0.00000001 * T * T * T * T));
        B += -0.00016359 * System.Math.Sin(System.Math.PI / 180 * (339.5415163 + 439263.9616 * T + 107.699 * 0.0001 * T + 16.463 * 0.000001 * T * T + -7.797 * 0.00000001 * T * T * T * T));
        B += 0.00013149 * System.Math.Sin(System.Math.PI / 180 * (153.0921289 + 1775065.296 * T + 58.798 * 0.0001 * T + 21.959 * 0.000001 * T * T + -10.451 * 0.00000001 * T * T * T * T));
        B += -0.00011941 * System.Math.Sin(System.Math.PI / 180 * (69.6146935 + -515133.7736 * T + -72.241 * 0.0001 * T + -12.232 * 0.000001 * T * T + 5.797 * 0.00000001 * T * T * T * T));
        B += 0.00011526 * System.Math.Sin(System.Math.PI / 180 * (20.5996083 + 1261867.378 * T + -29.636 * 0.0001 * T + 7.571 * 0.000001 * T * T + -3.654 * 0.00000001 * T * T * T * T));
        B += 0.00010653 * System.Math.Sin(System.Math.PI / 180 * (333.9142894 + 1301738.14 * T + -63.558 * 0.0001 * T + 3.299 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += -0.00009773 * System.Math.Sin(System.Math.PI / 180 * (80.2785133 + 852599.317 * T + -14.872 * 0.0001 * T + 5.779 * 0.000001 * T * T + -2.769 * 0.00000001 * T * T * T * T));
        B += 0.00009411 * System.Math.Sin(System.Math.PI / 180 * (72.1803956 + 1751072.546 * T + -187.665 * 0.0001 * T + -7.344 * 0.000001 * T * T + 3.375 * 0.00000001 * T * T * T * T));
        B += 0.00009141 * System.Math.Sin(System.Math.PI / 180 * (180.9206991 + -1036270.697 * T + -20.483 * 0.0001 * T + -9.833 * 0.000001 * T * T + 4.681 * 0.00000001 * T * T * T * T));
        B += 0.00008742 * System.Math.Sin(System.Math.PI / 180 * (198.950878 + 824539.2723 * T + -153.528 * 0.0001 * T + -11.049 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += -0.00008692 * System.Math.Sin(System.Math.PI / 180 * (174.1838326 + 507194.768 * T + 212.434 * 0.0001 * T + 29.019 * 0.000001 * T * T + -13.71 * 0.00000001 * T * T * T * T));
        B += -0.00008477 * System.Math.Sin(System.Math.PI / 180 * (305.3151019 + 375400.4494 * T + -104.842 * 0.0001 * T + -8.568 * 0.000001 * T * T + 4.028 * 0.00000001 * T * T * T * T));
        B += -0.00008369 * System.Math.Sin(System.Math.PI / 180 * (180.8743857 + -435196.6674 * T + -215.506 * 0.0001 * T + -28.938 * 0.000001 * T * T + 13.71 * 0.00000001 * T * T * T * T));
        B += -0.00008088 * System.Math.Sin(System.Math.PI / 180 * (90.8475218 + -81872.96192 * T + 159.457 * 0.0001 * T + 18.862 * 0.000001 * T * T + -8.914 * 0.00000001 * T * T * T * T));
        B += 0.00007462 * System.Math.Sin(System.Math.PI / 180 * (12.4066793 + -141864.7627 * T + -85.47 * 0.0001 * T + -10.482 * 0.000001 * T * T + 4.913 * 0.00000001 * T * T * T * T));
        B += 0.00007313 * System.Math.Sin(System.Math.PI / 180 * (273.1257448 + 2391997.488 * T + 325.852 * 0.0001 * T + 57.106 * 0.000001 * T * T + -27.073 * 0.00000001 * T * T * T * T));
        B += 0.00007058 * System.Math.Sin(System.Math.PI / 180 * (284.0822736 + -57860.36233 * T + -336.541 * 0.0001 * T + -39.662 * 0.000001 * T * T + 18.739 * 0.00000001 * T * T * T * T));
        B += -0.00006801 * System.Math.Sin(System.Math.PI / 180 * (20.553295 + 1862941.408 * T + -224.658 * 0.0001 * T + -11.534 * 0.000001 * T * T + 5.376 * 0.00000001 * T * T * T * T));
        B += -0.00006584 * System.Math.Sin(System.Math.PI / 180 * (101.4650283 + 1886934.158 * T + 21.805 * 0.0001 * T + 17.769 * 0.000001 * T * T + -8.45 * 0.00000001 * T * T * T * T));
        B += 0.00005938 * System.Math.Sin(System.Math.PI / 180 * (297.2169842 + 1273873.678 * T + -277.635 * 0.0001 * T + -21.692 * 0.000001 * T * T + 10.173 * 0.00000001 * T * T * T * T));
        B += 0.00005905 * System.Math.Sin(System.Math.PI / 180 * (339.6363275 + 2741469.331 * T + -9.26 * 0.0001 * T + 21.392 * 0.000001 * T * T + -10.219 * 0.00000001 * T * T * T * T));
        B += -0.0000572 * System.Math.Sin(System.Math.PI / 180 * (131.8593005 + 1341804.484 * T + -172.9 * 0.0001 * T + -9.135 * 0.000001 * T * T + 4.26 * 0.00000001 * T * T * T * T));
        B += -0.00004775 * System.Math.Sin(System.Math.PI / 180 * (240.6944153 + 856666.6112 * T + -122.678 * 0.0001 * T + -6.695 * 0.000001 * T * T + 3.144 * 0.00000001 * T * T * T * T));
        B += 0.00004386 * System.Math.Sin(System.Math.PI / 180 * (207.1438069 + 2228271.413 * T + -97.694 * 0.0001 * T + 7.003 * 0.000001 * T * T + -3.422 * 0.00000001 * T * T * T * T));
        B += 0.00004067 * System.Math.Sin(System.Math.PI / 180 * (187.3185432 + 1838928.808 * T + 271.339 * 0.0001 * T + 46.99 * 0.000001 * T * T + -22.276 * 0.00000001 * T * T * T * T));
        B += -0.00004015 * System.Math.Sin(System.Math.PI / 180 * (155.5167064 + 2340140.276 * T + -134.688 * 0.0001 * T + 2.813 * 0.000001 * T * T + -1.421 * 0.00000001 * T * T * T * T));
        B += 0.00003869 * System.Math.Sin(System.Math.PI / 180 * (256.1588921 + 451270.2614 * T + -140.3 * 0.0001 * T + -12.799 * 0.000001 * T * T + 6.029 * 0.00000001 * T * T * T * T));
        B += 0.00003832 * System.Math.Sin(System.Math.PI / 180 * (13.8627419 + 2805332.843 * T + 203.281 * 0.0001 * T + 46.423 * 0.000001 * T * T + -22.045 * 0.00000001 * T * T * T * T));
        B += -0.00003726 * System.Math.Sin(System.Math.PI / 180 * (137.4865274 + 479330.3061 * T + -1.643 * 0.0001 * T + 4.029 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += 0.00003717 * System.Math.Sin(System.Math.PI / 180 * (322.5746636 + -1501463.265 * T + -358.453 * 0.0001 * T + -53.443 * 0.000001 * T * T + 25.304 * 0.00000001 * T * T * T * T));
        B += -0.00003621 * System.Math.Sin(System.Math.PI / 180 * (350.1105248 + -495208.3173 * T + 282.028 * 0.0001 * T + 29.546 * 0.000001 * T * T + -13.942 * 0.00000001 * T * T * T * T));
        B += 0.00003582 * System.Math.Sin(System.Math.PI / 180 * (54.8260227 + 1325730.89 * T + 182.905 * 0.0001 * T + 32.602 * 0.000001 * T * T + -15.479 * 0.00000001 * T * T * T * T));
        B += 0.00003441 * System.Math.Sin(System.Math.PI / 180 * (241.3702213 + 2292134.926 * T + 114.847 * 0.0001 * T + 32.034 * 0.000001 * T * T + -15.248 * 0.00000001 * T * T * T * T));
        B += -0.00003274 * System.Math.Sin(System.Math.PI / 180 * (189.7431207 + 2404003.788 * T + 77.853 * 0.0001 * T + 27.844 * 0.000001 * T * T + -13.247 * 0.00000001 * T * T * T * T));
        B += -0.00003148 * System.Math.Sin(System.Math.PI / 180 * (126.8227077 + -888402.7846 * T + -59.013 * 0.0001 * T + -13.982 * 0.000001 * T * T + 6.681 * 0.00000001 * T * T * T * T));
        B += -0.00003147 * System.Math.Sin(System.Math.PI / 180 * (189.0673147 + 968535.4735 * T + -159.672 * 0.0001 * T + -10.886 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += -0.00003141 * System.Math.Sin(System.Math.PI / 180 * (15.6578267 + 1333865.479 * T + -32.708 * 0.0001 * T + 7.652 * 0.000001 * T * T + -3.654 * 0.00000001 * T * T * T * T));
        B += -0.00003046 * System.Math.Sin(System.Math.PI / 180 * (294.6512821 + -992332.6413 * T + -162.212 * 0.0001 * T + -26.579 * 0.000001 * T * T + 12.594 * 0.00000001 * T * T * T * T));
        B += -0.00002926 * System.Math.Sin(System.Math.PI / 180 * (2.5231161 + 2131.438457 * T + -91.613 * 0.0001 * T + -10.318 * 0.000001 * T * T + 4.913 * 0.00000001 * T * T * T * T));
        B += 0.00002827 * System.Math.Sin(System.Math.PI / 180 * (163.6148241 + 1441667.047 * T + 38.105 * 0.0001 * T + 15.937 * 0.000001 * T * T + -7.566 * 0.00000001 * T * T * T * T));
        B += -0.00002642 * System.Math.Sin(System.Math.PI / 180 * (313.3669063 + 78001.25048 * T + -127.071 * 0.0001 * T + -14.549 * 0.000001 * T * T + 6.913 * 0.00000001 * T * T * T * T));
        B += 0.00002612 * System.Math.Sin(System.Math.PI / 180 * (118.8657145 + 1711201.784 * T + -153.743 * 0.0001 * T + -3.072 * 0.000001 * T * T + 1.375 * 0.00000001 * T * T * T * T));
        B += 0.00002544 * System.Math.Sin(System.Math.PI / 180 * (86.5815462 + 1425593.453 * T + 393.91 * 0.0001 * T + 57.674 * 0.000001 * T * T + -27.305 * 0.00000001 * T * T * T * T));
        B += 0.00002448 * System.Math.Sin(System.Math.PI / 180 * (318.3550013 + -595070.8798 * T + 71.023 * 0.0001 * T + 4.474 * 0.000001 * T * T + -2.116 * 0.00000001 * T * T * T * T));
        B += 0.00002249 * System.Math.Sin(System.Math.PI / 180 * (343.9023031 + 1234002.916 * T + -243.713 * 0.0001 * T + -17.42 * 0.000001 * T * T + 8.172 * 0.00000001 * T * T * T * T));
        B += 0.00002198 * System.Math.Sin(System.Math.PI / 180 * (230.0305955 + -511066.4795 * T + -180.048 * 0.0001 * T + -24.707 * 0.000001 * T * T + 11.71 * 0.00000001 * T * T * T * T));
        B += -0.00002179 * System.Math.Sin(System.Math.PI / 180 * (121.1954808 + -25928.60622 * T + -230.27 * 0.0001 * T + -27.147 * 0.000001 * T * T + 12.826 * 0.00000001 * T * T * T * T));
        B += -0.00002078 * System.Math.Sin(System.Math.PI / 180 * (219.3667757 + -1878799.57 * T + -237.418 * 0.0001 * T + -42.718 * 0.000001 * T * T + 20.276 * 0.00000001 * T * T * T * T));
        B += 0.00001921 * System.Math.Sin(System.Math.PI / 180 * (282.3335021 + 812532.9726 * T + 94.471 * 0.0001 * T + 18.213 * 0.000001 * T * T + -8.682 * 0.00000001 * T * T * T * T));
        B += -0.00001823 * System.Math.Sin(System.Math.PI / 180 * (245.5898836 + 1385742.54 * T + -314.629 * 0.0001 * T + -25.882 * 0.000001 * T * T + 12.173 * 0.00000001 * T * T * T * T));
        B += -0.00001773 * System.Math.Sin(System.Math.PI / 180 * (301.0491263 + 1882866.864 * T + 129.611 * 0.0001 * T + 30.243 * 0.000001 * T * T + -14.363 * 0.00000001 * T * T * T * T));
        B += -0.00001745 * System.Math.Sin(System.Math.PI / 180 * (49.884241 + 1397728.991 * T + 179.833 * 0.0001 * T + 32.683 * 0.000001 * T * T + -15.479 * 0.00000001 * T * T * T * T));
        B += 0.00001738 * System.Math.Sin(System.Math.PI / 180 * (191.5845188 + 331462.3935 * T + 36.886 * 0.0001 * T + 8.179 * 0.000001 * T * T + -3.885 * 0.00000001 * T * T * T * T));
        B += -0.00001724 * System.Math.Sin(System.Math.PI / 180 * (61.5165758 + 383339.455 * T + -245.034 * 0.0001 * T + -25.356 * 0.000001 * T * T + 11.941 * 0.00000001 * T * T * T * T));
        B += -0.00001718 * System.Math.Sin(System.Math.PI / 180 * (36.7495304 + 65994.95069 * T + 120.928 * 0.0001 * T + 14.713 * 0.000001 * T * T + -6.913 * 0.00000001 * T * T * T * T));
        B += -0.00001716 * System.Math.Sin(System.Math.PI / 180 * (135.6914426 + 1950797.671 * T + 234.346 * 0.0001 * T + 42.8 * 0.000001 * T * T + -20.276 * 0.00000001 * T * T * T * T));
        B += 0.00001656 * System.Math.Sin(System.Math.PI / 180 * (170.4465018 + 2200406.951 * T + -311.771 * 0.0001 * T + -17.987 * 0.000001 * T * T + 8.404 * 0.00000001 * T * T * T * T));
        B += 0.00001624 * System.Math.Sin(System.Math.PI / 180 * (108.8777007 + 1778937.008 * T + 26.412 * 0.0001 * T + 17.646 * 0.000001 * T * T + -8.45 * 0.00000001 * T * T * T * T));
        B += -0.00001591 * System.Math.Sin(System.Math.PI / 180 * (88.3303177 + 555200.1181 * T + -37.101 * 0.0001 * T + -0.202 * 0.000001 * T * T + 0.116 * 0.00000001 * T * T * T * T));
        B += 0.00001579 * System.Math.Sin(System.Math.PI / 180 * (155.5630197 + 1739066.246 * T + 60.334 * 0.0001 * T + 21.918 * 0.000001 * T * T + -10.451 * 0.00000001 * T * T * T * T));
        B += -0.00001553 * System.Math.Sin(System.Math.PI / 180 * (253.6880013 + 487269.3117 * T + -141.836 * 0.0001 * T + -12.758 * 0.000001 * T * T + 6.029 * 0.00000001 * T * T * T * T));
        B += -0.00001529 * System.Math.Sin(System.Math.PI / 180 * (223.2937291 + 1032398.986 * T + 52.869 * 0.0001 * T + 14.146 * 0.000001 * T * T + -6.681 * 0.00000001 * T * T * T * T));
        B += 0.00001528 * System.Math.Sin(System.Math.PI / 180 * (100.0089658 + -1060263.448 * T + -266.946 * 0.0001 * T + -39.136 * 0.000001 * T * T + 18.507 * 0.00000001 * T * T * T * T));
        B += -0.00001516 * System.Math.Sin(System.Math.PI / 180 * (313.4132196 + -523072.7793 * T + 67.951 * 0.0001 * T + 4.556 * 0.000001 * T * T + -2.116 * 0.00000001 * T * T * T * T));
        B += 0.00001508 * System.Math.Sin(System.Math.PI / 180 * (56.5747941 + 455337.5556 * T + -248.106 * 0.0001 * T + -25.274 * 0.000001 * T * T + 11.941 * 0.00000001 * T * T * T * T));
        B += 0.00001459 * System.Math.Sin(System.Math.PI / 180 * (110.6727855 + 307469.643 * T + -209.577 * 0.0001 * T + -21.124 * 0.000001 * T * T + 9.941 * 0.00000001 * T * T * T * T));
        B += -0.00001416 * System.Math.Sin(System.Math.PI / 180 * (67.2386139 + 1823070.646 * T + -190.736 * 0.0001 * T + -7.263 * 0.000001 * T * T + 3.375 * 0.00000001 * T * T * T * T));
        B += -0.00001348 * System.Math.Sin(System.Math.PI / 180 * (356.8958892 + 864605.6168 * T + -262.871 * 0.0001 * T + -23.483 * 0.000001 * T * T + 11.057 * 0.00000001 * T * T * T * T));
        B += 0.00001343 * System.Math.Sin(System.Math.PI / 180 * (288.0555402 + 2252264.164 * T + 148.769 * 0.0001 * T + 36.306 * 0.000001 * T * T + -17.248 * 0.00000001 * T * T * T * T));
        B += 0.00001171 * System.Math.Sin(System.Math.PI / 180 * (305.4099131 + 2677605.819 * T + -221.801 * 0.0001 * T + -3.639 * 0.000001 * T * T + 1.606 * 0.00000001 * T * T * T * T));
        B += -0.00001095 * System.Math.Sin(System.Math.PI / 180 * (170.3516905 + -101798.4182 * T + -194.812 * 0.0001 * T + -22.916 * 0.000001 * T * T + 10.825 * 0.00000001 * T * T * T * T));
        B += 0.00001021 * System.Math.Sin(System.Math.PI / 180 * (253.8291259 + 2188400.652 * T + -63.773 * 0.0001 * T + 11.275 * 0.000001 * T * T + -5.423 * 0.00000001 * T * T * T * T));
        B += 0.00001013 * System.Math.Sin(System.Math.PI / 180 * (149.8409815 + 299335.0546 * T + 6.036 * 0.0001 * T + 3.825 * 0.000001 * T * T + -1.885 * 0.00000001 * T * T * T * T));
        B += -0.0000101 * System.Math.Sin(System.Math.PI / 180 * (114.5049276 + 916462.8293 * T + 197.669 * 0.0001 * T + 30.811 * 0.000001 * T * T + -14.595 * 0.00000001 * T * T * T * T));
        B += -0.00001003 * System.Math.Sin(System.Math.PI / 180 * (215.2419247 + 1329798.185 * T + 75.099 * 0.0001 * T + 20.127 * 0.000001 * T * T + -9.566 * 0.00000001 * T * T * T * T));
        B += 0.00000963 * System.Math.Sin(System.Math.PI / 180 * (337.0706254 + 475263.0119 * T + 106.163 * 0.0001 * T + 16.504 * 0.000001 * T * T + -7.797 * 0.00000001 * T * T * T * T));
        B += 0.00000962 * System.Math.Sin(System.Math.PI / 180 * (248.1070877 + 748669.4603 * T + -118.071 * 0.0001 * T + -6.818 * 0.000001 * T * T + 3.144 * 0.00000001 * T * T * T * T));
        B += 0.00000954 * System.Math.Sin(System.Math.PI / 180 * (77.8076225 + 888598.3673 * T + -16.408 * 0.0001 * T + 5.82 * 0.000001 * T * T + -2.769 * 0.00000001 * T * T * T * T));
        B += -0.00000896 * System.Math.Sin(System.Math.PI / 180 * (18.0339062 + -1004338.941 * T + 85.787 * 0.0001 * T + 2.683 * 0.000001 * T * T + -1.232 * 0.00000001 * T * T * T * T));
        B += -0.00000873 * System.Math.Sin(System.Math.PI / 180 * (236.4284397 + 2364133.026 * T + 111.775 * 0.0001 * T + 32.116 * 0.000001 * T * T + -15.248 * 0.00000001 * T * T * T * T));
        B += 0.00000866 * System.Math.Sin(System.Math.PI / 180 * (35.4830904 + 1723208.084 * T + -401.742 * 0.0001 * T + -32.334 * 0.000001 * T * T + 15.201 * 0.00000001 * T * T * T * T));
        B += -0.00000844 * System.Math.Sin(System.Math.PI / 180 * (290.4801177 + 2817339.143 * T + -44.718 * 0.0001 * T + 17.161 * 0.000001 * T * T + -8.219 * 0.00000001 * T * T * T * T));
        B += 0.00000836 * System.Math.Sin(System.Math.PI / 180 * (342.1072183 + 2705470.281 * T + -7.724 * 0.0001 * T + 21.351 * 0.000001 * T * T + -10.219 * 0.00000001 * T * T * T * T));
        B += -0.00000821 * System.Math.Sin(System.Math.PI / 180 * (292.2752025 + 1345871.779 * T + -280.707 * 0.0001 * T + -21.61 * 0.000001 * T * T + 10.173 * 0.00000001 * T * T * T * T));
        B += 0.00000805 * System.Math.Sin(System.Math.PI / 180 * (23.0704991 + 1225868.328 * T + -28.1 * 0.0001 * T + 7.53 * 0.000001 * T * T + -3.654 * 0.00000001 * T * T * T * T));
        B += -0.00000789 * System.Math.Sin(System.Math.PI / 180 * (266.8227119 + 1819003.352 * T + -82.93 * 0.0001 * T + 5.212 * 0.000001 * T * T + -2.538 * 0.00000001 * T * T * T * T));
        B += 0.00000786 * System.Math.Sin(System.Math.PI / 180 * (114.5997389 + 3218668.199 * T + 80.71 * 0.0001 * T + 35.739 * 0.000001 * T * T + -17.016 * 0.00000001 * T * T * T * T));
        B += -0.00000714 * System.Math.Sin(System.Math.PI / 180 * (82.7494041 + 816600.2667 * T + -13.336 * 0.0001 * T + 5.739 * 0.000001 * T * T + -2.769 * 0.00000001 * T * T * T * T));
        B += -0.00000708 * System.Math.Sin(System.Math.PI / 180 * (202.2020253 + 2300269.514 * T + -100.766 * 0.0001 * T + 7.085 * 0.000001 * T * T + -3.422 * 0.00000001 * T * T * T * T));
        B += 0.00000693 * System.Math.Sin(System.Math.PI / 180 * (149.1188622 + -535059.23 * T + -426.511 * 0.0001 * T + -54.01 * 0.000001 * T * T + 25.536 * 0.00000001 * T * T * T * T));
        B += -0.00000672 * System.Math.Sin(System.Math.PI / 180 * (309.147244 + 984393.6357 * T + 302.404 * 0.0001 * T + 43.367 * 0.000001 * T * T + -20.507 * 0.00000001 * T * T * T * T));
        B += 0.00000661 * System.Math.Sin(System.Math.PI / 180 * (74.6512864 + 1715073.495 * T + -186.129 * 0.0001 * T + -7.385 * 0.000001 * T * T + 3.375 * 0.00000001 * T * T * T * T));
        B += -0.00000657 * System.Math.Sin(System.Math.PI / 180 * (45.9109744 + -912395.5351 * T + -305.476 * 0.0001 * T + -43.285 * 0.000001 * T * T + 20.507 * 0.00000001 * T * T * T * T));
        B += 0.00000635 * System.Math.Sin(System.Math.PI / 180 * (237.443268 + -619063.6303 * T + -175.44 * 0.0001 * T + -24.829 * 0.000001 * T * T + 11.71 * 0.00000001 * T * T * T * T));
        B += 0.00000604 * System.Math.Sin(System.Math.PI / 180 * (159.782682 + 832673.8607 * T + -369.141 * 0.0001 * T + -35.998 * 0.000001 * T * T + 16.97 * 0.00000001 * T * T * T * T));
        B += -0.00000584 * System.Math.Sin(System.Math.PI / 180 * (307.7859927 + 339401.3991 * T + -103.306 * 0.0001 * T + -8.609 * 0.000001 * T * T + 4.028 * 0.00000001 * T * T * T * T));
        B += 0.00000579 * System.Math.Sin(System.Math.PI / 180 * (129.3884097 + 1377803.535 * T + -174.436 * 0.0001 * T + -9.094 * 0.000001 * T * T + 4.26 * 0.00000001 * T * T * T * T));
        B += 0.00000568 * System.Math.Sin(System.Math.PI / 180 * (45.9572877 + -1513469.565 * T + -110.454 * 0.0001 * T + -24.18 * 0.000001 * T * T + 11.478 * 0.00000001 * T * T * T * T));
        B += -0.00000559 * System.Math.Sin(System.Math.PI / 180 * (342.0124071 + 403264.9113 * T + 109.235 * 0.0001 * T + 16.422 * 0.000001 * T * T + -7.797 * 0.00000001 * T * T * T * T));
        B += -0.00000508 * System.Math.Sin(System.Math.PI / 180 * (33.5931943 + 892470.0788 * T + -48.794 * 0.0001 * T + 1.508 * 0.000001 * T * T + -0.769 * 0.00000001 * T * T * T * T));
        B += 0.00000505 * System.Math.Sin(System.Math.PI / 180 * (95.0671841 + -988265.3471 * T + -270.018 * 0.0001 * T + -39.054 * 0.000001 * T * T + 18.507 * 0.00000001 * T * T * T * T));
        B += -0.000005 * System.Math.Sin(System.Math.PI / 180 * (261.786119 + -411203.9169 * T + 30.958 * 0.0001 * T + 0.365 * 0.000001 * T * T + -0.116 * 0.00000001 * T * T * T * T));
        B += 0.00000491 * System.Math.Sin(System.Math.PI / 180 * (48.0891562 + 2869196.356 * T + 415.822 * 0.0001 * T + 71.454 * 0.000001 * T * T + -33.87 * 0.00000001 * T * T * T * T));
        B += -0.0000047 * System.Math.Sin(System.Math.PI / 180 * (150.621238 + 1811064.346 * T + 57.263 * 0.0001 * T + 22 * 0.000001 * T * T + -10.451 * 0.00000001 * T * T * T * T));
        B += 0.00000467 * System.Math.Sin(System.Math.PI / 180 * (118.7245899 + 10070.44407 * T + -231.806 * 0.0001 * T + -27.106 * 0.000001 * T * T + 12.826 * 0.00000001 * T * T * T * T));
        B += -0.00000464 * System.Math.Sin(System.Math.PI / 180 * (93.3184126 + -117872.0122 * T + 160.993 * 0.0001 * T + 18.821 * 0.000001 * T * T + -8.914 * 0.00000001 * T * T * T * T));
        B += 0.00000445 * System.Math.Sin(System.Math.PI / 180 * (336.3851802 + 1265739.09 * T + -62.022 * 0.0001 * T + 3.258 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += 0.00000444 * System.Math.Sin(System.Math.PI / 180 * (292.1803913 + -956333.591 * T + -163.748 * 0.0001 * T + -26.539 * 0.000001 * T * T + 12.594 * 0.00000001 * T * T * T * T));
        B += -0.00000436 * System.Math.Sin(System.Math.PI / 180 * (351.8592963 + -1365601.652 * T + -148.983 * 0.0001 * T + -28.33 * 0.000001 * T * T + 13.479 * 0.00000001 * T * T * T * T));
        B += 0.00000413 * System.Math.Sin(System.Math.PI / 180 * (121.3366053 + 1675202.734 * T + -152.207 * 0.0001 * T + -3.113 * 0.000001 * T * T + 1.375 * 0.00000001 * T * T * T * T));
        B += -0.00000412 * System.Math.Sin(System.Math.PI / 180 * (324.0307261 + 1445734.341 * T + -69.701 * 0.0001 * T + 3.462 * 0.000001 * T * T + -1.653 * 0.00000001 * T * T * T * T));
        B += 0.00000407 * System.Math.Sin(System.Math.PI / 180 * (80.3733245 + 3154804.687 * T + -131.831 * 0.0001 * T + 10.708 * 0.000001 * T * T + -5.191 * 0.00000001 * T * T * T * T));
        B += -0.00000377 * System.Math.Sin(System.Math.PI / 180 * (134.3301914 + 1305805.434 * T + -171.364 * 0.0001 * T + -9.176 * 0.000001 * T * T + 4.26 * 0.00000001 * T * T * T * T));
        B += 0.00000375 * System.Math.Sin(System.Math.PI / 180 * (264.3518211 + 1855002.402 * T + -84.466 * 0.0001 * T + 5.253 * 0.000001 * T * T + -2.538 * 0.00000001 * T * T * T * T));
        B += -0.00000374 * System.Math.Sin(System.Math.PI / 180 * (207.0489957 + -73933.9563 * T + 19.265 * 0.0001 * T + 2.075 * 0.000001 * T * T + -1 * 0.00000001 * T * T * T * T));
        B += 0.00000367 * System.Math.Sin(System.Math.PI / 180 * (302.8442111 + 411399.4997 * T + -106.378 * 0.0001 * T + -8.527 * 0.000001 * T * T + 4.028 * 0.00000001 * T * T * T * T));
        B += 0.00000353 * System.Math.Sin(System.Math.PI / 180 * (209.6146978 + 2192272.363 * T + -96.159 * 0.0001 * T + 6.962 * 0.000001 * T * T + -3.422 * 0.00000001 * T * T * T * T));
        B += -0.00000351 * System.Math.Sin(System.Math.PI / 180 * (227.5597047 + -475067.4292 * T + -181.584 * 0.0001 * T + -24.666 * 0.000001 * T * T + 11.71 * 0.00000001 * T * T * T * T));
        B += -0.00000349 * System.Math.Sin(System.Math.PI / 180 * (159.6878707 + -1469531.509 * T + -252.182 * 0.0001 * T + -40.927 * 0.000001 * T * T + 19.391 * 0.00000001 * T * T * T * T));
        B += 0.00000342 * System.Math.Sin(System.Math.PI / 180 * (299.687875 + 1237874.628 * T + -276.099 * 0.0001 * T + -21.733 * 0.000001 * T * T + 10.173 * 0.00000001 * T * T * T * T));
        B += 0.00000336 * System.Math.Sin(System.Math.PI / 180 * (16.3336327 + 2769333.793 * T + 204.817 * 0.0001 * T + 46.382 * 0.000001 * T * T + -22.045 * 0.00000001 * T * T * T * T));
        B += 0.00000329 * System.Math.Sin(System.Math.PI / 180 * (148.8261532 + 3282531.711 * T + 293.251 * 0.0001 * T + 60.77 * 0.000001 * T * T + -28.842 * 0.00000001 * T * T * T * T));
        B += -0.00000328 * System.Math.Sin(System.Math.PI / 180 * (324.7065321 + 2881202.655 * T + 167.823 * 0.0001 * T + 42.192 * 0.000001 * T * T + -20.044 * 0.00000001 * T * T * T * T));
        B += -0.00000327 * System.Math.Sin(System.Math.PI / 180 * (23.0241858 + 1826942.358 * T + -223.123 * 0.0001 * T + -11.575 * 0.000001 * T * T + 5.376 * 0.00000001 * T * T * T * T));
        B += 0.00000321 * System.Math.Sin(System.Math.PI / 180 * (277.3454071 + 1485605.103 * T + -103.623 * 0.0001 * T + -0.81 * 0.000001 * T * T + 0.348 * 0.00000001 * T * T * T * T));
        B += 0.00000313 * System.Math.Sin(System.Math.PI / 180 * (187.6112522 + -1978662.133 * T + -448.423 * 0.0001 * T + -67.79 * 0.000001 * T * T + 32.101 * 0.00000001 * T * T * T * T));
        B += 0.00000303 * System.Math.Sin(System.Math.PI / 180 * (346.3731939 + 1198003.866 * T + -242.177 * 0.0001 * T + -17.461 * 0.000001 * T * T + 8.172 * 0.00000001 * T * T * T * T));
        B += -0.00000291 * System.Math.Sin(System.Math.PI / 180 * (181.0155103 + 1265934.672 * T + -137.443 * 0.0001 * T + -4.904 * 0.000001 * T * T + 2.259 * 0.00000001 * T * T * T * T));
        B += 0.00000289 * System.Math.Sin(System.Math.PI / 180 * (201.4217688 + 788540.2221 * T + -151.993 * 0.0001 * T + -11.09 * 0.000001 * T * T + 5.144 * 0.00000001 * T * T * T * T));
        B += 0.00000287 * System.Math.Sin(System.Math.PI / 180 * (183.3915899 + -1072269.747 * T + -18.948 * 0.0001 * T + -9.874 * 0.000001 * T * T + 4.681 * 0.00000001 * T * T * T * T));
        B += 0.00000286 * System.Math.Sin(System.Math.PI / 180 * (72.0855843 + -551132.8239 * T + -70.706 * 0.0001 * T + -12.273 * 0.000001 * T * T + 5.797 * 0.00000001 * T * T * T * T));
        B += 0.00000285 * System.Math.Sin(System.Math.PI / 180 * (322.2819546 + 2316127.676 * T + 361.31 * 0.0001 * T + 61.338 * 0.000001 * T * T + -29.074 * 0.00000001 * T * T * T * T));
        B += 0.00000282 * System.Math.Sin(System.Math.PI / 180 * (298.5782355 + 1918865.915 * T + 128.075 * 0.0001 * T + 30.284 * 0.000001 * T * T + -14.363 * 0.00000001 * T * T * T * T));
        B += -0.0000028 * System.Math.Sin(System.Math.PI / 180 * (253.7343146 + -113804.718 * T + 53.187 * 0.0001 * T + 6.347 * 0.000001 * T * T + -3.001 * 0.00000001 * T * T * T * T));

        double B01 = 0;
        B01 += -2.23474 * System.Math.Sin(System.Math.PI / 180 * (218.3174 + 481267.8813 * T));
        B01 += 0.4195 * System.Math.Sin(System.Math.PI / 180 * (314.9967 + 481266.4844 * T));
        B01 += 0.1751 * System.Math.Sin(System.Math.PI / 180 * (213.0248 + 483333.8664 * T));
        B01 += 0.17504 * System.Math.Sin(System.Math.PI / 180 * (26.4804 + -483070.1687 * T));
        B01 += 0.12663 * System.Math.Sin(System.Math.PI / 180 * (83.354 + 4069.0137 * T));
        B01 += -0.11548 * System.Math.Sin(System.Math.PI / 180 * (353.2808 + 958466.749 * T));
        B01 += 0.09062 * System.Math.Sin(System.Math.PI / 180 * (31.7733 + -485136.1537 * T));
        B01 += 0.08293 * System.Math.Sin(System.Math.PI / 180 * (342.617 + -409266.3417 * T));
        B01 += -0.02319 * System.Math.Sin(System.Math.PI / 180 * (319.0544 + 894603.2367 * T));
        B01 += 0.02234 * System.Math.Sin(System.Math.PI / 180 * (343.3612 + 479333.7452 * T));
        B01 += -0.02154 * System.Math.Sin(System.Math.PI / 180 * (178.4856 + 4067.6167 * T));
        B01 += 0.02037 * System.Math.Sin(System.Math.PI / 180 * (117.5804 + 67932.5259 * T));
        B01 += 0.02013 * System.Math.Sin(System.Math.PI / 180 * (88.4122 + 958465.352 * T));
        B01 += 0.01935 * System.Math.Sin(System.Math.PI / 180 * (251.5173 + -960269.0363 * T));
        B01 += 0.01874 * System.Math.Sin(System.Math.PI / 180 * (347.9895 + 960532.734 * T));
        B01 += 0.01851 * System.Math.Sin(System.Math.PI / 180 * (1.8346 + 483925.0468 * T));
        B01 += -0.01451 * System.Math.Sin(System.Math.PI / 180 * (139.8144 + -3937.7278 * T));
        B01 += -0.01408 * System.Math.Sin(System.Math.PI / 180 * (326.3604 + 962466.3073 * T));
        B01 += -0.01379 * System.Math.Sin(System.Math.PI / 180 * (250.1212 + 475196.673 * T));
        B01 += -0.01343 * System.Math.Sin(System.Math.PI / 180 * (77.7485 + -409267.7387 * T));
        B01 += -0.01288 * System.Math.Sin(System.Math.PI / 180 * (94.0178 + 1371802.104 * T));
        B01 += 0.01171 * System.Math.Sin(System.Math.PI / 180 * (27.0252 + 474887.534 * T));
        B01 += 0.01105 * System.Math.Sin(System.Math.PI / 180 * (256.8101 + -962335.0213 * T));
        B01 += -0.01079 * System.Math.Sin(System.Math.PI / 180 * (272.4669 + 483547.7102 * T));
        B01 += -0.01031 * System.Math.Sin(System.Math.PI / 180 * (133.766 + 485860.5799 * T));
        B01 += 0.00967 * System.Math.Sin(System.Math.PI / 180 * (148.1767 + 484301.39 * T));
        B01 += -0.00859 * System.Math.Sin(System.Math.PI / 180 * (251.9923 + -2311.3337 * T));
        B01 += 0.00849 * System.Math.Sin(System.Math.PI / 180 * (285.4666 + -374367.7383 * T));
        B01 += 0.00801 * System.Math.Sin(System.Math.PI / 180 * (239.9516 + 499341.5099 * T));
        B01 += -0.00795 * System.Math.Sin(System.Math.PI / 180 * (78.5308 + 964092.7014 * T));
        B01 += -0.0076 * System.Math.Sin(System.Math.PI / 180 * (43.1678 + 503784.9272 * T));
        B01 += 0.00692 * System.Math.Sin(System.Math.PI / 180 * (183.352 + -483220.847 * T));
        B01 += 0.00692 * System.Math.Sin(System.Math.PI / 180 * (9.939 + 483183.1881 * T));
        B01 += -0.00668 * System.Math.Sin(System.Math.PI / 180 * (128.2441 + 1435665.617 * T));
        B01 += -0.00655 * System.Math.Sin(System.Math.PI / 180 * (108.5203 + 497405.9768 * T));
        B01 += 0.00652 * System.Math.Sin(System.Math.PI / 180 * (250.5689 + 407312.0193 * T));
        B01 += 0.00652 * System.Math.Sin(System.Math.PI / 180 * (325.7099 + -407352.3917 * T));
        B01 += 0.00626 * System.Math.Sin(System.Math.PI / 180 * (20.9585 + -362295.3199 * T));
        B01 += 0.00609 * System.Math.Sin(System.Math.PI / 180 * (274.6895 + 473261.1399 * T));
        B01 += 0.00606 * System.Math.Sin(System.Math.PI / 180 * (337.3239 + -407200.3566 * T));
        B01 += 0.00605 * System.Math.Sin(System.Math.PI / 180 * (262.1806 + 407464.0544 * T));
        B01 += 0.00559 * System.Math.Sin(System.Math.PI / 180 * (301.9728 + 959431.4016 * T));
        B01 += -0.00558 * System.Math.Sin(System.Math.PI / 180 * (299.0703 + -384813.7627 * T));
        B01 += 0.00554 * System.Math.Sin(System.Math.PI / 180 * (305.4557 + 452369.0911 * T));
        B01 += 0.00533 * System.Math.Sin(System.Math.PI / 180 * (115.4239 + -6972.6334 * T));
        B01 += 0.00485 * System.Math.Sin(System.Math.PI / 180 * (308.3905 + -473129.8539 * T));
        B01 += 0.00457 * System.Math.Sin(System.Math.PI / 180 * (207.6536 + -886465.2093 * T));
        B01 += -0.00455 * System.Math.Sin(System.Math.PI / 180 * (232.0839 + 478822.2568 * T));
        B01 += 0.00418 * System.Math.Sin(System.Math.PI / 180 * (54.1859 + 894601.8398 * T));
        B01 += 0.00391 * System.Math.Sin(System.Math.PI / 180 * (208.9975 + 440296.6727 * T));
        B01 += 0.00391 * System.Math.Sin(System.Math.PI / 180 * (285.742 + -896405.5241 * T));
        B01 += 0.0039 * System.Math.Sin(System.Math.PI / 180 * (340.1461 + -373267.2914 * T));
        B01 += -0.00388 * System.Math.Sin(System.Math.PI / 180 * (275.6916 + 481225.7267 * T));
        B01 += -0.00386 * System.Math.Sin(System.Math.PI / 180 * (76.983 + 454304.6243 * T));
        B01 += 0.00379 * System.Math.Sin(System.Math.PI / 180 * (313.7613 + 896669.2218 * T));
        B01 += -0.00375 * System.Math.Sin(System.Math.PI / 180 * (124.6414 + 526303.37 * T));
        B01 += -0.00356 * System.Math.Sin(System.Math.PI / 180 * (62.5822 + 482488.5982 * T));
        B01 += -0.00342 * System.Math.Sin(System.Math.PI / 180 * (350.7216 + -341403.2711 * T));
        B01 += 0.00338 * System.Math.Sin(System.Math.PI / 180 * (150.7798 + -1373604.392 * T));
        B01 += -0.00336 * System.Math.Sin(System.Math.PI / 180 * (212.7119 + 67931.129 * T));
        B01 += 0.00335 * System.Math.Sin(System.Math.PI / 180 * (88.7251 + 1373868.089 * T));
        B01 += -0.00308 * System.Math.Sin(System.Math.PI / 180 * (161.5677 + 481417.1627 * T));
        B01 += -0.00283 * System.Math.Sin(System.Math.PI / 180 * (158.2395 + 476823.0671 * T));
        B01 += 0.00279 * System.Math.Sin(System.Math.PI / 180 * (267.4739 + 405398.0693 * T));

        double B02 = 0;
        B02 += -0.02064 * System.Math.Sin(System.Math.PI / 180 * (144.899 + 371333.155 * T));
        B02 += 0.00845 * System.Math.Sin(System.Math.PI / 180 * (139.957 + 443331.256 * T));
        B02 += -0.00619 * System.Math.Sin(System.Math.PI / 180 * (196.48 + 860538.323 * T));
        B02 += -0.00555 * System.Math.Sin(System.Math.PI / 180 * (331.443 + 1337737.19 * T));
        B02 += -0.00519 * System.Math.Sin(System.Math.PI / 180 * (9.936 + -105865.712 * T));
        B02 += 0.00471 * System.Math.Sin(System.Math.PI / 180 * (129.294 + -924401.835 * T));
        B02 += 0.00451 * System.Math.Sin(System.Math.PI / 180 * (90.801 + 519201.068 * T));
        B02 += 0.00394 * System.Math.Sin(System.Math.PI / 180 * (315.838 + 42002.2 * T));
        B02 += 0.00372 * System.Math.Sin(System.Math.PI / 180 * (225.765 + 996399.935 * T));
        B02 += 0.00362 * System.Math.Sin(System.Math.PI / 180 * (52.758 + 481266.484 * T));
        B02 += 0.00355 * System.Math.Sin(System.Math.PI / 180 * (39.22 + 29995.9 * T));
        B02 += 0.00338 * System.Math.Sin(System.Math.PI / 180 * (264.257 + -447202.967 * T));
        B02 += -0.00313 * System.Math.Sin(System.Math.PI / 180 * (294.447 + -483070.169 * T));
        B02 += -0.00312 * System.Math.Sin(System.Math.PI / 180 * (121.106 + 483333.866 * T));
        B02 += -0.00152 * System.Math.Sin(System.Math.PI / 180 * (147.37 + 335334.105 * T));
        B02 += -0.00123 * System.Math.Sin(System.Math.PI / 180 * (279.863 + 848532.023 * T));
        B02 += 0.00095 * System.Math.Sin(System.Math.PI / 180 * (218.317 + 481267.881 * T));
        B02 += 0.00092 * System.Math.Sin(System.Math.PI / 180 * (191.538 + 932536.423 * T));
        B02 += 0.00088 * System.Math.Sin(System.Math.PI / 180 * (326.502 + 1409735.291 * T));
        B02 += 0.00082 * System.Math.Sin(System.Math.PI / 180 * (142.428 + 407332.206 * T));
        B02 += -0.00079 * System.Math.Sin(System.Math.PI / 180 * (106.407 + 1814936.058 * T));
        B02 += 0.00057 * System.Math.Sin(System.Math.PI / 180 * (274.921 + 920530.123 * T));
        B02 += -0.00056 * System.Math.Sin(System.Math.PI / 180 * (28.651 + 964468.179 * T));
        B02 += -0.00056 * System.Math.Sin(System.Math.PI / 180 * (202.107 + -1935.856 * T));
        B02 += 0.00056 * System.Math.Sin(System.Math.PI / 180 * (354.33 + -1401600.702 * T));
        B02 += 0.00055 * System.Math.Sin(System.Math.PI / 180 * (4.994 + -33867.612 * T));
        B02 += -0.00054 * System.Math.Sin(System.Math.PI / 180 * (333.914 + 1301738.14 * T));
        B02 += -0.00046 * System.Math.Sin(System.Math.PI / 180 * (234.972 + -583064.58 * T));
        B02 += 0.00045 * System.Math.Sin(System.Math.PI / 180 * (0.728 + 1473598.803 * T));
        B02 += -0.00044 * System.Math.Sin(System.Math.PI / 180 * (198.951 + 824539.272 * T));
        B02 += -0.00041 * System.Math.Sin(System.Math.PI / 180 * (245.636 + 784668.511 * T));
        B02 += -0.00038 * System.Math.Sin(System.Math.PI / 180 * (12.407 + -141864.763 * T));
        B02 += -0.00035 * System.Math.Sin(System.Math.PI / 180 * (159.534 + -960269.036 * T));
        B02 += -0.00034 * System.Math.Sin(System.Math.PI / 180 * (256.123 + 960532.734 * T));
        B02 += -0.00029 * System.Math.Sin(System.Math.PI / 180 * (20.6 + 1261867.378 * T));
        B02 += -0.00024 * System.Math.Sin(System.Math.PI / 180 * (72.18 + 1751072.546 * T));
        B02 += 0.00022 * System.Math.Sin(System.Math.PI / 180 * (174.184 + 507194.768 * T));
        B02 += 0.00021 * System.Math.Sin(System.Math.PI / 180 * (180.874 + -435196.667 * T));
        B02 += 0.00019 * System.Math.Sin(System.Math.PI / 180 * (137.487 + 479330.306 * T));
        B02 += -0.00018 * System.Math.Sin(System.Math.PI / 180 * (278.166 + 4067.617 * T));
        B02 += 0.00018 * System.Math.Sin(System.Math.PI / 180 * (96.899 + 483183.188 * T));
        B02 += 0.00018 * System.Math.Sin(System.Math.PI / 180 * (270.354 + -483220.847 * T));
        B02 += 0.00017 * System.Math.Sin(System.Math.PI / 180 * (188.093 + 958465.352 * T));
        B02 += 0.00017 * System.Math.Sin(System.Math.PI / 180 * (101.465 + 1886934.158 * T));
        B02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (189.067 + 968535.474 * T));
        B02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (105.132 + 483925.047 * T));
        B02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (126.823 + -888402.785 * T));
        B02 += -0.00015 * System.Math.Sin(System.Math.PI / 180 * (297.217 + 1273873.678 * T));
        B02 += 0.00015 * System.Math.Sin(System.Math.PI / 180 * (2.523 + 2131.438 * T));
        B02 += 0.00015 * System.Math.Sin(System.Math.PI / 180 * (328.973 + 1373736.241 * T));
        B02 += 0.00013 * System.Math.Sin(System.Math.PI / 180 * (313.367 + 78001.25 * T));
        B02 += 0.00012 * System.Math.Sin(System.Math.PI / 180 * (240.694 + 856666.611 * T));
        B02 += 0.00011 * System.Math.Sin(System.Math.PI / 180 * (62.211 + -485709.902 * T));
        B02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (177.429 + -409267.739 * T));
        B02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (207.144 + 2228271.413 * T));
        B02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (245.347 + -407200.357 * T));
        B02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (170.204 + 407464.054 * T));
        B02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (194.009 + 896537.373 * T));
        B02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (156.11 + 499341.51 * T));
        B02 += -0.0001 * System.Math.Sin(System.Math.PI / 180 * (282.334 + 812532.973 * T));
        B02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (54.826 + 1325730.89 * T));
        B02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (303.156 + 475196.673 * T));
        B02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (241.37 + 2292134.926 * T));
        B02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (36.75 + 65994.951 * T));

        double B03 = 0;
        B03 += -0.61 * System.Math.Sin(System.Math.PI / 180 * (144.9 + 371333.2 * T));
        B03 += 0.25 * System.Math.Sin(System.Math.PI / 180 * (140 + 443331.3 * T));
        B03 += -0.17 * System.Math.Sin(System.Math.PI / 180 * (331.4 + 1337737.2 * T));
        B03 += -0.17 * System.Math.Sin(System.Math.PI / 180 * (196.5 + 860538.3 * T));
        B03 += -0.14 * System.Math.Sin(System.Math.PI / 180 * (9.9 + -105865.7 * T));
        B03 += 0.14 * System.Math.Sin(System.Math.PI / 180 * (90.8 + 519201.1 * T));
        B03 += 0.14 * System.Math.Sin(System.Math.PI / 180 * (129.3 + -924401.8 * T));
        B03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (225.8 + 996399.9 * T));
        B03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (39.2 + 29995.9 * T));
        B03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (264.3 + -447203 * T));
        B03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (315.8 + 42002.2 * T));
        B03 += -0.06 * System.Math.Sin(System.Math.PI / 180 * (147.4 + 335334.1 * T));

        double Aberasi = -0.00001754 * System.Math.Sin(System.Math.PI / 180 * (183.3 + 483202 * T));
        double trueB = B + (B01 + B02 * T + B03 * T * T / 10000) / 1000;

        /*T = (JDE - 2451545) / 36525
Aberasi = -0.00001754 * DegSin(183.3 + 483202 * T)
B = TermB(T): B01 = TermB01(T): B02 = TermB02(T): B03 = TermB03(T)
trueB = B + (B01 + B02 * T + B03 * T * T / 10000) / 1000
BetaBulan = trueB + Aberasi*/


        return Aberasi + trueB;
    }

    // fungsi koreksi jarak Bulan
    public double jarakBulan(double T)
    {

        double R = 0;

        R += -20905.355 * System.Math.Cos(System.Math.PI / 180 * (134.9634114 + 477198.8676 * T + 89.97 * 0.0001 * T + 14.348 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        R += -3699.1109 * System.Math.Cos(System.Math.PI / 180 * (100.736997 + 413335.3554 * T + -122.571 * 0.0001 * T + -10.684 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += -2955.9676 * System.Math.Cos(System.Math.PI / 180 * (235.7004084 + 890534.223 * T + -32.601 * 0.0001 * T + 3.664 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += -569.9251 * System.Math.Cos(System.Math.PI / 180 * (269.9268228 + 954397.7353 * T + 179.941 * 0.0001 * T + 28.695 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        R += 246.1585 * System.Math.Cos(System.Math.PI / 180 * (325.7735856 + -63863.51223 * T + -212.541 * 0.0001 * T + -25.031 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        R += -204.586 * System.Math.Cos(System.Math.PI / 180 * (238.1712992 + 854535.1727 * T + -31.065 * 0.0001 * T + 3.623 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += -170.7331 * System.Math.Cos(System.Math.PI / 180 * (10.6638198 + 1367733.091 * T + 57.37 * 0.0001 * T + 18.011 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        R += -152.1377 * System.Math.Cos(System.Math.PI / 180 * (103.2078878 + 377336.3051 * T + -121.035 * 0.0001 * T + -10.724 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += -129.6201 * System.Math.Cos(System.Math.PI / 180 * (222.5656978 + -441199.8173 * T + -91.506 * 0.0001 * T + -14.307 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        R += 108.7427 * System.Math.Cos(System.Math.PI / 180 * (297.8502042 + 445267.1115 * T + -16.3 * 0.0001 * T + 1.832 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        R += 104.7552 * System.Math.Cos(System.Math.PI / 180 * (132.4925206 + 513197.9179 * T + 88.434 * 0.0001 * T + 14.388 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        R += 79.6606 * System.Math.Cos(System.Math.PI / 180 * (308.4192127 + -489205.1674 * T + 158.029 * 0.0001 * T + 14.915 * 0.000001 * T * T + -7.029 * 0.00000001 * T * T * T * T));
        R += 48.8883 * System.Math.Cos(System.Math.PI / 180 * (357.5291092 + 35999.05029 * T + -1.536 * 0.0001 * T + 0.041 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        R += -34.7825 * System.Math.Cos(System.Math.PI / 180 * (336.4374054 + 1303869.578 * T + -155.171 * 0.0001 * T + -7.02 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        R += 30.8238 * System.Math.Cos(System.Math.PI / 180 * (233.2295176 + 926533.2733 * T + -34.136 * 0.0001 * T + 3.705 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += 24.2085 * System.Math.Cos(System.Math.PI / 180 * (98.2661062 + 449334.4057 * T + -124.107 * 0.0001 * T + -10.643 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += -23.2104 * System.Math.Cos(System.Math.PI / 180 * (44.8902341 + 1431596.603 * T + 269.911 * 0.0001 * T + 43.043 * 0.000001 * T * T + -20.392 * 0.00000001 * T * T * T * T));
        R += -21.6363 * System.Math.Cos(System.Math.PI / 180 * (201.473994 + 826670.7108 * T + -245.142 * 0.0001 * T + -21.367 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        R += -16.6747 * System.Math.Cos(System.Math.PI / 180 * (295.3793134 + 481266.1618 * T + -17.836 * 0.0001 * T + 1.873 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        R += 14.4027 * System.Math.Cos(System.Math.PI / 180 * (190.8101743 + -541062.3799 * T + -302.511 * 0.0001 * T + -39.379 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        R += -12.8314 * System.Math.Cos(System.Math.PI / 180 * (13.1347106 + 1331734.04 * T + 58.906 * 0.0001 * T + 17.971 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        R += -11.65 * System.Math.Cos(System.Math.PI / 180 * (111.4008168 + 1781068.446 * T + -65.201 * 0.0001 * T + 7.328 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        R += -10.4448 * System.Math.Cos(System.Math.PI / 180 * (145.6272312 + 1844931.958 * T + 147.34 * 0.0001 * T + 32.359 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        R += 10.3211 * System.Math.Cos(System.Math.PI / 180 * (49.1562098 + -75869.81202 * T + 35.458 * 0.0001 * T + 4.231 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        R += 10.0562 * System.Math.Cos(System.Math.PI / 180 * (328.2444765 + -99862.56252 * T + -211.005 * 0.0001 * T + -25.072 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        R += -9.8844 * System.Math.Cos(System.Math.PI / 180 * (240.64219 + 818536.1225 * T + -29.529 * 0.0001 * T + 3.582 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += 8.7516 * System.Math.Cos(System.Math.PI / 180 * (274.1927984 + -553068.6797 * T + -54.513 * 0.0001 * T + -10.116 * 0.000001 * T * T + 4.797 * 0.00000001 * T * T * T * T));
        R += -8.3791 * System.Math.Cos(System.Math.PI / 180 * (162.8867928 + -31931.75611 * T + -106.271 * 0.0001 * T + -12.516 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        R += -7.0027 * System.Math.Cos(System.Math.PI / 180 * (87.6022864 + -918398.685 * T + -181.476 * 0.0001 * T + -28.654 * 0.000001 * T * T + 13.594 * 0.00000001 * T * T * T * T));
        R += 6.322 * System.Math.Cos(System.Math.PI / 180 * (72.8136156 + 922465.9791 * T + 73.67 * 0.0001 * T + 16.179 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        R += 5.7509 * System.Math.Cos(System.Math.PI / 180 * (267.4559319 + 990396.7856 * T + 178.405 * 0.0001 * T + 28.736 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        R += -4.9501 * System.Math.Cos(System.Math.PI / 180 * (105.6787787 + 341337.2548 * T + -119.499 * 0.0001 * T + -10.765 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += -4.4212 * System.Math.Cos(System.Math.PI / 180 * (83.3826241 + -12006.29979 * T + 247.999 * 0.0001 * T + 29.262 * 0.000001 * T * T + -13.826 * 0.00000001 * T * T * T * T));
        R += 4.1311 * System.Math.Cos(System.Math.PI / 180 * (184.1196211 + 401329.0556 * T + 125.428 * 0.0001 * T + 18.579 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        R += -3.958 * System.Math.Cos(System.Math.PI / 180 * (338.9082962 + 1267870.528 * T + -153.636 * 0.0001 * T + -7.061 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        R += 3.2582 * System.Math.Cos(System.Math.PI / 180 * (38.5872012 + 858602.4669 * T + -138.871 * 0.0001 * T + -8.852 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        R += -3.1483 * System.Math.Cos(System.Math.PI / 180 * (186.5441986 + 966404.0351 * T + -68.058 * 0.0001 * T + -0.567 * 0.000001 * T * T + 0.232 * 0.00000001 * T * T * T * T));
        R += 2.6164 * System.Math.Cos(System.Math.PI / 180 * (8.192929 + 1403732.141 * T + 55.834 * 0.0001 * T + 18.052 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        R += 2.3536 * System.Math.Cos(System.Math.PI / 180 * (95.7952154 + 485333.456 * T + -125.643 * 0.0001 * T + -10.602 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += -2.1171 * System.Math.Cos(System.Math.PI / 180 * (220.094807 + -405200.767 * T + -93.042 * 0.0001 * T + -14.266 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        R += -1.897 * System.Math.Cos(System.Math.PI / 180 * (203.9448849 + 790671.6605 * T + -243.606 * 0.0001 * T + -21.408 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        R += -1.7385 * System.Math.Cos(System.Math.PI / 180 * (27.9233814 + -509130.6237 * T + -196.241 * 0.0001 * T + -26.863 * 0.000001 * T * T + 12.71 * 0.00000001 * T * T * T * T));
        R += -1.5714 * System.Math.Cos(System.Math.PI / 180 * (113.8717076 + 1745069.396 * T + -63.665 * 0.0001 * T + 7.287 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        R += -1.4226 * System.Math.Cos(System.Math.PI / 180 * (246.3642282 + 2258267.314 * T + 24.769 * 0.0001 * T + 21.675 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        R += -1.4189 * System.Math.Cos(System.Math.PI / 180 * (173.5506126 + 1335801.335 * T + -48.901 * 0.0001 * T + 5.496 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        R += 1.1655 * System.Math.Cos(System.Math.PI / 180 * (130.0216297 + 549196.9682 * T + 86.899 * 0.0001 * T + 14.429 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        R += -1.1169 * System.Math.Cos(System.Math.PI / 180 * (179.8536455 + 1908795.471 * T + 359.881 * 0.0001 * T + 57.39 * 0.000001 * T * T + -27.189 * 0.00000001 * T * T * T * T));
        R += 1.0657 * System.Math.Cos(System.Math.PI / 180 * (355.0582184 + 71998.10058 * T + -3.072 * 0.0001 * T + 0.082 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        R += -0.9333 * System.Math.Cos(System.Math.PI / 180 * (70.3427248 + 958465.0294 * T + 72.134 * 0.0001 * T + 16.22 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        R += 0.8624 * System.Math.Cos(System.Math.PI / 180 * (263.6237898 + 381403.5993 * T + -228.841 * 0.0001 * T + -23.199 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        R += 0.8512 * System.Math.Cos(System.Math.PI / 180 * (160.415902 + 4067.294176 * T + -107.806 * 0.0001 * T + -12.475 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        R += -0.8488 * System.Math.Cos(System.Math.PI / 180 * (148.098122 + 1808932.908 * T + 148.876 * 0.0001 * T + 32.318 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        R += -0.7956 * System.Math.Cos(System.Math.PI / 180 * (111.3060056 + -521136.9235 * T + 51.758 * 0.0001 * T + 2.399 * 0.000001 * T * T + -1.116 * 0.00000001 * T * T * T * T));
        R += 0.7785 * System.Math.Cos(System.Math.PI / 180 * (55.8467629 + -1018261.247 * T + -392.482 * 0.0001 * T + -53.726 * 0.000001 * T * T + 25.42 * 0.00000001 * T * T * T * T));
        R += 0.774 * System.Math.Cos(System.Math.PI / 180 * (152.3177843 + 902540.5228 * T + -280.599 * 0.0001 * T + -25.598 * 0.000001 * T * T + 12.057 * 0.00000001 * T * T * T * T));
        R += -0.6697 * System.Math.Cos(System.Math.PI / 180 * (280.5906425 + 2322130.826 * T + 237.31 * 0.0001 * T + 46.706 * 0.000001 * T * T + -22.161 * 0.00000001 * T * T * T * T));
        R += -0.6575 * System.Math.Cos(System.Math.PI / 180 * (15.6056014 + 1295734.99 * T + 60.441 * 0.0001 * T + 17.93 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        R += 0.6571 * System.Math.Cos(System.Math.PI / 180 * (51.6271006 + -111868.8623 * T + 36.994 * 0.0001 * T + 4.19 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        R += 0.5963 * System.Math.Cos(System.Math.PI / 180 * (287.2811957 + 1379739.39 * T + -190.629 * 0.0001 * T + -11.251 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        R += 0.5788 * System.Math.Cos(System.Math.PI / 180 * (333.9665146 + 1339868.629 * T + -156.707 * 0.0001 * T + -6.979 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        R += -0.5142 * System.Math.Cos(System.Math.PI / 180 * (66.5105827 + 349471.8432 * T + -335.112 * 0.0001 * T + -35.715 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        R += -0.5079 * System.Math.Cos(System.Math.PI / 180 * (284.8566182 + 814664.411 * T + 2.857 * 0.0001 * T + 7.895 * 0.000001 * T * T + -3.769 * 0.00000001 * T * T * T * T));
        R += 0.4976 * System.Math.Cos(System.Math.PI / 180 * (300.321095 + 409268.0612 * T + -14.764 * 0.0001 * T + 1.791 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        R += 0.495 * System.Math.Cos(System.Math.PI / 180 * (193.2810651 + -577061.4302 * T + -300.976 * 0.0001 * T + -39.419 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        R += 0.4726 * System.Math.Cos(System.Math.PI / 180 * (139.229387 + -1030267.547 * T + -144.483 * 0.0001 * T + -24.464 * 0.000001 * T * T + 11.594 * 0.00000001 * T * T * T * T));
        R += -0.4225 * System.Math.Cos(System.Math.PI / 180 * (77.1744024 + 1717204.934 * T + -277.742 * 0.0001 * T + -17.703 * 0.000001 * T * T + 8.288 * 0.00000001 * T * T * T * T));
        R += -0.4224 * System.Math.Cos(System.Math.PI / 180 * (312.6388751 + -1395597.553 * T + -271.447 * 0.0001 * T + -43.002 * 0.000001 * T * T + 20.392 * 0.00000001 * T * T * T * T));
        R += -0.4107 * System.Math.Cos(System.Math.PI / 180 * (243.1130809 + 782537.0722 * T + -27.993 * 0.0001 * T + 3.541 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += 0.3785 * System.Math.Cos(System.Math.PI / 180 * (207.777027 + 1399664.847 * T + 163.64 * 0.0001 * T + 30.527 * 0.000001 * T * T + -14.479 * 0.00000001 * T * T * T * T));
        R += 0.3551 * System.Math.Cos(System.Math.PI / 180 * (42.4193433 + 1467595.653 * T + 268.375 * 0.0001 * T + 43.083 * 0.000001 * T * T + -20.392 * 0.00000001 * T * T * T * T));
        R += 0.343 * System.Math.Cos(System.Math.PI / 180 * (330.7153673 + -135861.6128 * T + -209.469 * 0.0001 * T + -25.113 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        R += 0.3346 * System.Math.Cos(System.Math.PI / 180 * (49.1098964 + 525204.2177 * T + -159.564 * 0.0001 * T + -14.874 * 0.000001 * T * T + 7.029 * 0.00000001 * T * T * T * T));
        R += 0.3323 * System.Math.Cos(System.Math.PI / 180 * (25.4524906 + -473131.5735 * T + -197.777 * 0.0001 * T + -26.822 * 0.000001 * T * T + 12.71 * 0.00000001 * T * T * T * T));
        R += 0.3233 * System.Math.Cos(System.Math.PI / 180 * (276.6636892 + -589067.7299 * T + -52.977 * 0.0001 * T + -10.157 * 0.000001 * T * T + 4.797 * 0.00000001 * T * T * T * T));
        R += -0.3218 * System.Math.Cos(System.Math.PI / 180 * (149.8932068 + 337465.5434 * T + -87.113 * 0.0001 * T + -6.453 * 0.000001 * T * T + 3.028 * 0.00000001 * T * T * T * T));
        R += -0.2866 * System.Math.Cos(System.Math.PI / 180 * (212.1378138 + 2194403.801 * T + -187.772 * 0.0001 * T + -3.356 * 0.000001 * T * T + 1.491 * 0.00000001 * T * T * T * T));
        R += 0.284 * System.Math.Cos(System.Math.PI / 180 * (319.0830325 + 878527.9232 * T + 215.398 * 0.0001 * T + 32.926 * 0.000001 * T * T + -15.595 * 0.00000001 * T * T * T * T));
        R += -0.279 * System.Math.Cos(System.Math.PI / 180 * (341.3791871 + 1231871.478 * T + -152.1 * 0.0001 * T + -7.101 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        R += 0.2556 * System.Math.Cos(System.Math.PI / 180 * (41.058092 + 822603.4166 * T + -137.335 * 0.0001 * T + -8.893 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        R += -0.2481 * System.Math.Cos(System.Math.PI / 180 * (305.9483219 + -453206.1171 * T + 156.493 * 0.0001 * T + 14.956 * 0.000001 * T * T + -7.029 * 0.00000001 * T * T * T * T));
        R += 0.2445 * System.Math.Cos(System.Math.PI / 180 * (108.929926 + 1817067.496 * T + -66.737 * 0.0001 * T + 7.369 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        R += 0.237 * System.Math.Cos(System.Math.PI / 180 * (199.0031032 + 862669.7611 * T + -246.678 * 0.0001 * T + -21.326 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        R += -0.2126 * System.Math.Cos(System.Math.PI / 180 * (36.1163104 + 894601.5172 * T + -140.407 * 0.0001 * T + -8.811 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        R += 0.2125 * System.Math.Cos(System.Math.PI / 180 * (143.1563403 + 1880931.009 * T + 145.804 * 0.0001 * T + 32.4 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        R += 0.2094 * System.Math.Cos(System.Math.PI / 180 * (186.590512 + 365330.0053 * T + 126.964 * 0.0001 * T + 18.538 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        R += -0.2029 * System.Math.Cos(System.Math.PI / 180 * (248.835119 + 2222268.263 * T + 26.305 * 0.0001 * T + 21.634 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        R += 0.201 * System.Math.Cos(System.Math.PI / 180 * (347.006414 + 369397.2995 * T + 19.158 * 0.0001 * T + 6.063 * 0.000001 * T * T + -2.885 * 0.00000001 * T * T * T * T));
        R += -0.1857 * System.Math.Cos(System.Math.PI / 180 * (170.9849105 + -930404.9848 * T + 66.523 * 0.0001 * T + 0.608 * 0.000001 * T * T + -0.232 * 0.00000001 * T * T * T * T));
        R += -0.1832 * System.Math.Cos(System.Math.PI / 180 * (302.2109911 + 1240006.066 * T + -367.713 * 0.0001 * T + -32.051 * 0.000001 * T * T + 15.085 * 0.00000001 * T * T * T * T));
        R += 0.1686 * System.Math.Cos(System.Math.PI / 180 * (188.3392834 + -505063.3296 * T + -304.047 * 0.0001 * T + -39.338 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        R += -0.158 * System.Math.Cos(System.Math.PI / 180 * (184.0733078 + 1002403.085 * T + -69.594 * 0.0001 * T + -0.526 * 0.000001 * T * T + 0.232 * 0.00000001 * T * T * T * T));
        R += -0.1571 * System.Math.Cos(System.Math.PI / 180 * (176.0215034 + 1299802.284 * T + -47.365 * 0.0001 * T + 5.455 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        R += -0.1481 * System.Math.Cos(System.Math.PI / 180 * (108.1496695 + 305338.2045 * T + -117.963 * 0.0001 * T + -10.806 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        R += 0.1476 * System.Math.Cos(System.Math.PI / 180 * (230.7586268 + 962532.3236 * T + -35.672 * 0.0001 * T + 3.746 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        R += 0.1437 * System.Math.Cos(System.Math.PI / 180 * (323.3026948 + -27864.46194 * T + -214.077 * 0.0001 * T + -24.99 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        R += -0.1392 * System.Math.Cos(System.Math.PI / 180 * (21.3276396 + 2735466.181 * T + 114.739 * 0.0001 * T + 36.023 * 0.000001 * T * T + -17.132 * 0.00000001 * T * T * T * T));
        R += -0.1362 * System.Math.Cos(System.Math.PI / 180 * (85.1313956 + -882399.6347 * T + -183.012 * 0.0001 * T + -28.613 * 0.000001 * T * T + 13.594 * 0.00000001 * T * T * T * T));
        R += -0.1357 * System.Math.Cos(System.Math.PI / 180 * (46.6853189 + -39870.76173 * T + 33.922 * 0.0001 * T + 4.272 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        R += -0.1281 * System.Math.Cos(System.Math.PI / 180 * (116.3425984 + 1709070.345 * T + -62.129 * 0.0001 * T + 7.246 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        R += 0.1141 * System.Math.Cos(System.Math.PI / 180 * (165.3576836 + -67930.80641 * T + -104.735 * 0.0001 * T + -12.556 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        R += 0.11 * System.Math.Cos(System.Math.PI / 180 * (75.2845064 + 886466.9289 * T + 75.206 * 0.0001 * T + 16.139 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        R += -0.1089 * System.Math.Cos(System.Math.PI / 180 * (320.831804 + 8134.588353 * T + -215.613 * 0.0001 * T + -24.949 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        R += -0.1083 * System.Math.Cos(System.Math.PI / 180 * (206.4157757 + 754672.6102 * T + -242.07 * 0.0001 * T + -21.449 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        R += -0.1077 * System.Math.Cos(System.Math.PI / 180 * (171.0797218 + 1371800.385 * T + -50.437 * 0.0001 * T + 5.537 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        R += -0.1033 * System.Math.Cos(System.Math.PI / 180 * (321.50761 + 1443602.903 * T + 21.912 * 0.0001 * T + 13.78 * 0.000001 * T * T + -6.566 * 0.00000001 * T * T * T * T));
        R += -0.0994 * System.Math.Cos(System.Math.PI / 180 * (252.9599701 + -986329.4914 * T + -286.211 * 0.0001 * T + -41.211 * 0.000001 * T * T + 19.507 * 0.00000001 * T * T * T * T));
        R += -0.0859 * System.Math.Cos(System.Math.PI / 180 * (347.1012252 + 2671602.669 * T + -97.802 * 0.0001 * T + 10.992 * 0.000001 * T * T + -5.307 * 0.00000001 * T * T * T * T));
        R += -0.0798 * System.Math.Cos(System.Math.PI / 180 * (14.9297954 + -139733.3243 * T + -177.083 * 0.0001 * T + -20.8 * 0.000001 * T * T + 9.825 * 0.00000001 * T * T * T * T));
        R += -0.0668 * System.Math.Cos(System.Math.PI / 180 * (79.6452933 + 1681205.884 * T + -276.206 * 0.0001 * T + -17.744 * 0.000001 * T * T + 8.288 * 0.00000001 * T * T * T * T));
        R += -0.0654 * System.Math.Cos(System.Math.PI / 180 * (308.514024 + 1813000.202 * T + 41.069 * 0.0001 * T + 19.843 * 0.000001 * T * T + -9.451 * 0.00000001 * T * T * T * T));
        R += 0.0606 * System.Math.Cos(System.Math.PI / 180 * (246.2694169 + -43938.05591 * T + 141.728 * 0.0001 * T + 16.747 * 0.000001 * T * T + -7.913 * 0.00000001 * T * T * T * T));
        R += -0.059 * System.Math.Cos(System.Math.PI / 180 * (205.3061361 + 1435663.897 * T + 162.104 * 0.0001 * T + 30.568 * 0.000001 * T * T + -14.479 * 0.00000001 * T * T * T * T));
        R += -0.0589 * System.Math.Cos(System.Math.PI / 180 * (314.8170569 + 2385994.338 * T + 449.851 * 0.0001 * T + 71.738 * 0.000001 * T * T + -33.986 * 0.00000001 * T * T * T * T));
        R += -0.0585 * System.Math.Cos(System.Math.PI / 180 * (283.0615334 + 2286131.776 * T + 238.846 * 0.0001 * T + 46.666 * 0.000001 * T * T + -22.161 * 0.00000001 * T * T * T * T));
        R += -0.0579 * System.Math.Cos(System.Math.PI / 180 * (287.327509 + 778665.3607 * T + 4.393 * 0.0001 * T + 7.854 * 0.000001 * T * T + -3.769 * 0.00000001 * T * T * T * T));
        R += -0.0553 * System.Math.Cos(System.Math.PI / 180 * (181.6487303 + 437328.1059 * T + 123.892 * 0.0001 * T + 18.619 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        R += 0.0529 * System.Math.Cos(System.Math.PI / 180 * (266.0946807 + 345404.549 * T + -227.306 * 0.0001 * T + -23.24 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        R += -0.0519 * System.Math.Cos(System.Math.PI / 180 * (214.6087046 + 2158404.751 * T + -186.236 * 0.0001 * T + -3.397 * 0.000001 * T * T + 1.491 * 0.00000001 * T * T * T * T));
        R += 0.0507 * System.Math.Cos(System.Math.PI / 180 * (264.9850411 + 1026395.836 * T + 176.869 * 0.0001 * T + 28.777 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        R += -0.0502 * System.Math.Cos(System.Math.PI / 180 * (274.1464851 + 48005.35008 * T + -249.535 * 0.0001 * T + -29.221 * 0.000001 * T * T + 13.826 * 0.00000001 * T * T * T * T));
        R += -0.0484 * System.Math.Cos(System.Math.PI / 180 * (128.6603785 + -95795.26834 * T + -318.812 * 0.0001 * T + -37.547 * 0.000001 * T * T + 17.738 * 0.00000001 * T * T * T * T));
        R += 0.0474 * System.Math.Cos(System.Math.PI / 180 * (280.8833515 + -1495460.115 * T + -482.452 * 0.0001 * T + -68.074 * 0.000001 * T * T + 32.217 * 0.00000001 * T * T * T * T));
        R += -0.0474 * System.Math.Cos(System.Math.PI / 180 * (271.7219076 + -517069.6294 * T + -56.048 * 0.0001 * T + -10.076 * 0.000001 * T * T + 4.797 * 0.00000001 * T * T * T * T));
        R += -0.0461 * System.Math.Cos(System.Math.PI / 180 * (150.5690128 + 1772933.858 * T + 150.412 * 0.0001 * T + 32.277 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        R += 0.0459 * System.Math.Cos(System.Math.PI / 180 * (139.3241982 + 1271937.822 * T + -261.442 * 0.0001 * T + -19.535 * 0.000001 * T * T + 9.172 * 0.00000001 * T * T * T * T));
        R += -0.0442 * System.Math.Cos(System.Math.PI / 180 * (55.5540539 + 2799329.694 * T + 327.281 * 0.0001 * T + 61.054 * 0.000001 * T * T + -28.958 * 0.00000001 * T * T * T * T));
        R += -0.0432 * System.Math.Cos(System.Math.PI / 180 * (68.9814735 + 313472.7929 * T + -333.576 * 0.0001 * T + -35.756 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        R += -0.0423 * System.Math.Cos(System.Math.PI / 180 * (336.3425942 + -998335.7912 * T + -38.212 * 0.0001 * T + -11.948 * 0.000001 * T * T + 5.681 * 0.00000001 * T * T * T * T));
        R += -0.0389 * System.Math.Cos(System.Math.PI / 180 * (217.6239162 + -369201.7168 * T + -94.578 * 0.0001 * T + -14.225 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        R += 0.0381 * System.Math.Cos(System.Math.PI / 180 * (261.152899 + 417402.6496 * T + -230.377 * 0.0001 * T + -23.158 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        R += 0.0373 * System.Math.Cos(System.Math.PI / 180 * (289.7520865 + 1343740.34 * T + -189.093 * 0.0001 * T + -11.292 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        R += 0.0373 * System.Math.Cos(System.Math.PI / 180 * (292.9084226 + 517265.2121 * T + -19.372 * 0.0001 * T + 1.914 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        R += 0.0368 * System.Math.Cos(System.Math.PI / 180 * (243.8933374 + 2294266.364 * T + 23.233 * 0.0001 * T + 21.716 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        R += 0.0338 * System.Math.Cos(System.Math.PI / 180 * (108.8351147 + -485137.8732 * T + 50.222 * 0.0001 * T + 2.44 * 0.000001 * T * T + -1.116 * 0.00000001 * T * T * T * T));
        R += 0.0327 * System.Math.Cos(System.Math.PI / 180 * (80.9117333 + 23992.7505 * T + 246.463 * 0.0001 * T + 29.303 * 0.000001 * T * T + -13.826 * 0.00000001 * T * T * T * T));
        R += 0.0314 * System.Math.Cos(System.Math.PI / 180 * (62.244607 + 1856938.258 * T + -100.659 * 0.0001 * T + 3.097 * 0.000001 * T * T + -1.537 * 0.00000001 * T * T * T * T));
        R += 0.0302 * System.Math.Cos(System.Math.PI / 180 * (154.7886751 + 866541.4725 * T + -279.064 * 0.0001 * T + -25.639 * 0.000001 * T * T + 12.057 * 0.00000001 * T * T * T * T));
        R += -0.0295 * System.Math.Cos(System.Math.PI / 180 * (302.7919858 + 373269.0109 * T + -13.229 * 0.0001 * T + 1.75 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        R += -0.0294 * System.Math.Cos(System.Math.PI / 180 * (291.5471713 + -127727.0245 * T + -425.082 * 0.0001 * T + -50.062 * 0.000001 * T * T + 23.651 * 0.00000001 * T * T * T * T));
        R += 0.0291 * System.Math.Cos(System.Math.PI / 180 * (4.2659756 + -1507466.415 * T + -234.453 * 0.0001 * T + -38.811 * 0.000001 * T * T + 18.391 * 0.00000001 * T * T * T * T));
        R += -0.0286 * System.Math.Cos(System.Math.PI / 180 * (18.0764922 + 1259735.94 * T + 61.977 * 0.0001 * T + 17.889 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        R += 0.0284 * System.Math.Cos(System.Math.PI / 180 * (54.0979914 + -147867.9126 * T + 38.529 * 0.0001 * T + 4.149 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        R += -0.027 * System.Math.Cos(System.Math.PI / 180 * (152.3640976 + 301466.4931 * T + -85.577 * 0.0001 * T + -6.493 * 0.000001 * T * T + 3.028 * 0.00000001 * T * T * T * T));
        R += -0.0267 * System.Math.Cos(System.Math.PI / 180 * (177.6754637 + -1872796.42 * T + -361.417 * 0.0001 * T + -57.349 * 0.000001 * T * T + 27.189 * 0.00000001 * T * T * T * T));
        R += 0.0266 * System.Math.Cos(System.Math.PI / 180 * (196.5322124 + 898668.8114 * T + -248.213 * 0.0001 * T + -21.286 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        R += -0.0247 * System.Math.Cos(System.Math.PI / 180 * (349.4309915 + 934472.2789 * T + -174.329 * 0.0001 * T + -13.083 * 0.000001 * T * T + 6.144 * 0.00000001 * T * T * T * T));
        R += -0.0244 * System.Math.Cos(System.Math.PI / 180 * (304.6818819 + 1204007.016 * T + -366.177 * 0.0001 * T + -32.092 * 0.000001 * T * T + 15.085 * 0.00000001 * T * T * T * T));
        R += -0.024 * System.Math.Cos(System.Math.PI / 180 * (64.0396919 + 385470.8935 * T + -336.648 * 0.0001 * T + -35.674 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        R += 0.0237 * System.Math.Cos(System.Math.PI / 180 * (342.7404383 + 1876863.714 * T + 253.611 * 0.0001 * T + 44.874 * 0.000001 * T * T + -21.276 * 0.00000001 * T * T * T * T));
        R += 0.0233 * System.Math.Cos(System.Math.PI / 180 * (58.3176537 + -1054260.298 * T + -390.946 * 0.0001 * T + -53.767 * 0.000001 * T * T + 25.42 * 0.00000001 * T * T * T * T));
        R += 0.023 * System.Math.Cos(System.Math.PI / 180 * (177.3827547 + 1944794.521 * T + 358.345 * 0.0001 * T + 57.431 * 0.000001 * T * T + -27.189 * 0.00000001 * T * T * T * T));
        R += 0.0213 * System.Math.Cos(System.Math.PI / 180 * (352.5873276 + 107997.1509 * T + -4.608 * 0.0001 * T + 0.123 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        R += -0.0208 * System.Math.Cos(System.Math.PI / 180 * (23.7985304 + 2699467.131 * T + 116.275 * 0.0001 * T + 35.982 * 0.000001 * T * T + -17.132 * 0.00000001 * T * T * T * T));
        R += -0.0201 * System.Math.Cos(System.Math.PI / 180 * (17.3543729 + 425341.6552 * T + -370.57 * 0.0001 * T + -39.946 * 0.000001 * T * T + 18.854 * 0.00000001 * T * T * T * T));

        double R01 = 0;

        R01 += 1.0587 * System.Math.Cos(System.Math.PI / 180 * (233.0866 + 479264.2898 * T));
        R01 += 0.7278 * System.Math.Cos(System.Math.PI / 180 * (344.7895 + -477067.0188 * T));
        R01 += -0.6826 * System.Math.Cos(System.Math.PI / 180 * (254.719 + 477330.7165 * T));
        R01 += 0.5983 * System.Math.Cos(System.Math.PI / 180 * (345.2589 + 480890.6839 * T));
        R01 += -0.4565 * System.Math.Cos(System.Math.PI / 180 * (260.0092 + 475264.7314 * T));
        R01 += 0.4528 * System.Math.Cos(System.Math.PI / 180 * (350.0824 + -479133.0038 * T));
        R01 += -0.4101 * System.Math.Cos(System.Math.PI / 180 * (208.6847 + 476229.3841 * T));
        R01 += 0.205 * System.Math.Cos(System.Math.PI / 180 * (192.2132 + -857569.7559 * T));
        R01 += 0.2047 * System.Math.Cos(System.Math.PI / 180 * (244.0516 + -890402.3742 * T));
        R01 += -0.2037 * System.Math.Cos(System.Math.PI / 180 * (355.4532 + 890666.0719 * T));
        R01 += 0.1664 * System.Math.Cos(System.Math.PI / 180 * (287.6902 + -845497.3374 * T));
        R01 += -0.1578 * System.Math.Cos(System.Math.PI / 180 * (241.4058 + 477178.6814 * T));
        R01 += 0.1578 * System.Math.Cos(System.Math.PI / 180 * (331.4791 + -477219.0538 * T));
        R01 += 0.1575 * System.Math.Cos(System.Math.PI / 180 * (327.1237 + -380370.8882 * T));
        R01 += 0.1445 * System.Math.Cos(System.Math.PI / 180 * (357.2452 + -411269.9333 * T));
        R01 += -0.1381 * System.Math.Cos(System.Math.PI / 180 * (306.5599 + -454680.4248 * T));
        R01 += 0.1348 * System.Math.Cos(System.Math.PI / 180 * (19.0126 + -413203.5065 * T));
        R01 += -0.1267 * System.Math.Cos(System.Math.PI / 180 * (220.4892 + 413467.2043 * T));
        R01 += 0.1267 * System.Math.Cos(System.Math.PI / 180 * (292.3791 + -444234.4005 * T));
        R01 += -0.1236 * System.Math.Cos(System.Math.PI / 180 * (205.7982 + -868015.7802 * T));
        R01 += -0.1205 * System.Math.Cos(System.Math.PI / 180 * (263.7606 + 458372.241 * T));
        R01 += 0.12 * System.Math.Cos(System.Math.PI / 180 * (216.4928 + 499717.3105 * T));
        R01 += 0.1162 * System.Math.Cos(System.Math.PI / 180 * (62.6005 + -368298.4698 * T));
        R01 += -0.1126 * System.Math.Cos(System.Math.PI / 180 * (209.3053 + 413315.1692 * T));
        R01 += 0.1125 * System.Math.Cos(System.Math.PI / 180 * (7.8297 + -413355.5416 * T));
        R01 += -0.1123 * System.Math.Cos(System.Math.PI / 180 * (343.8467 + 890514.0368 * T));
        R01 += 0.1122 * System.Math.Cos(System.Math.PI / 180 * (232.4426 + -890554.4092 * T));
        R01 += -0.1069 * System.Math.Cos(System.Math.PI / 180 * (0.7459 + 888600.0868 * T));
        R01 += -0.105 * System.Math.Cos(System.Math.PI / 180 * (202.1456 + 510163.3348 * T));
        R01 += -0.105 * System.Math.Cos(System.Math.PI / 180 * (257.4688 + -824605.2887 * T));
        R01 += -0.1006 * System.Math.Cos(System.Math.PI / 180 * (340.7609 + -390816.9126 * T));
        R01 += 0.0993 * System.Math.Cos(System.Math.PI / 180 * (109.682 + -409643.5392 * T));
        R01 += 0.0955 * System.Math.Cos(System.Math.PI / 180 * (249.3451 + -892468.3592 * T));
        R01 += -0.0851 * System.Math.Cos(System.Math.PI / 180 * (176.626 + 487271.0312 * T));
        R01 += 0.0795 * System.Math.Cos(System.Math.PI / 180 * (66.7826 + 503409.1267 * T));
        R01 += -0.0773 * System.Math.Cos(System.Math.PI / 180 * (333.0802 + -414304.8389 * T));
        R01 += 0.0705 * System.Math.Cos(System.Math.PI / 180 * (16.1051 + 476447.2666 * T));
        R01 += -0.0631 * System.Math.Cos(System.Math.PI / 180 * (299.8407 + 477158.11 * T));
        R01 += 0.0631 * System.Math.Cos(System.Math.PI / 180 * (29.9119 + -477239.6253 * T));
        R01 += 0.0621 * System.Math.Cos(System.Math.PI / 180 * (4.6741 + 478231.5787 * T));
        R01 += -0.0609 * System.Math.Cos(System.Math.PI / 180 * (98.1213 + 2065.4221 * T));
        R01 += -0.0608 * System.Math.Cos(System.Math.PI / 180 * (32.3536 + -347406.421 * T));
        R01 += -0.0601 * System.Math.Cos(System.Math.PI / 180 * (352.2127 + 476823.0671 * T));
        R01 += -0.059 * System.Math.Cos(System.Math.PI / 180 * (198.0307 + 474917.6418 * T));
        R01 += 0.0586 * System.Math.Cos(System.Math.PI / 180 * (287.9045 + -479480.0934 * T));
        R01 += 0.0577 * System.Math.Cos(System.Math.PI / 180 * (355.1425 + 475263.3345 * T));
        R01 += 0.0572 * System.Math.Cos(System.Math.PI / 180 * (332.9419 + -856816.076 * T));
        R01 += -0.057 * System.Math.Cos(System.Math.PI / 180 * (85.2157 + -479134.4008 * T));
        R01 += -0.0551 * System.Math.Cos(System.Math.PI / 180 * (16.3088 + -468161.3548 * T));
        R01 += -0.0534 * System.Math.Cos(System.Math.PI / 180 * (225.782 + 411401.2192 * T));
        R01 += 0.0525 * System.Math.Cos(System.Math.PI / 180 * (98.2942 + -881496.7102 * T));
        R01 += 0.0516 * System.Math.Cos(System.Math.PI / 180 * (286.0818 + 486236.3804 * T));
        R01 += -0.0504 * System.Math.Cos(System.Math.PI / 180 * (100.8011 + 413335.3554 * T));
        R01 += -0.0492 * System.Math.Cos(System.Math.PI / 180 * (298.133 + 522235.7533 * T));
        R01 += 0.0492 * System.Math.Cos(System.Math.PI / 180 * (28.455 + -432161.982 * T));
        R01 += 0.0488 * System.Math.Cos(System.Math.PI / 180 * (233.4132 + -404297.8426 * T));
        R01 += 0.0461 * System.Math.Cos(System.Math.PI / 180 * (293.4551 + -410300.4497 * T));
        R01 += 0.0456 * System.Math.Cos(System.Math.PI / 180 * (178.9132 + -858978.2674 * T));
        R01 += 0.044 * System.Math.Cos(System.Math.PI / 180 * (108.2005 + -379617.2084 * T));
        R01 += -0.0437 * System.Math.Cos(System.Math.PI / 180 * (167.4024 + 446299.8226 * T));
        R01 += 0.0435 * System.Math.Cos(System.Math.PI / 180 * (8.056 + 956463.1574 * T));
        R01 += 0.0432 * System.Math.Cos(System.Math.PI / 180 * (102.0889 + -860604.6615 * T));
        R01 += -0.0428 * System.Math.Cos(System.Math.PI / 180 * (131.1841 + 416370.2611 * T));
        R01 += -0.0428 * System.Math.Cos(System.Math.PI / 180 * (67.3412 + 32964.4672 * T));
        R01 += -0.0427 * System.Math.Cos(System.Math.PI / 180 * (38.6974 + 935571.1087 * T));
        R01 += 0.0411 * System.Math.Cos(System.Math.PI / 180 * (153.9518 + -887499.3174 * T));
        R01 += 0.0397 * System.Math.Cos(System.Math.PI / 180 * (242.2038 + 478490.4237 * T));
        R01 += 0.0397 * System.Math.Cos(System.Math.PI / 180 * (209.8262 + -954265.8864 * T));
        R01 += -0.0388 * System.Math.Cos(System.Math.PI / 180 * (302.2798 + 923498.6902 * T));
        R01 += 0.0386 * System.Math.Cos(System.Math.PI / 180 * (24.3078 + -415269.4916 * T));
        R01 += 0.0376 * System.Math.Cos(System.Math.PI / 180 * (148.3721 + 525927.5695 * T));
        R01 += -0.0374 * System.Math.Cos(System.Math.PI / 180 * (102.8999 + 480233.7733 * T));
        R01 += 0.0374 * System.Math.Cos(System.Math.PI / 180 * (81.5574 + 22518.4428 * T));
        R01 += 0.0373 * System.Math.Cos(System.Math.PI / 180 * (74.6382 + -443480.7206 * T));
        R01 += -0.0372 * System.Math.Cos(System.Math.PI / 180 * (29.6822 + 954529.5841 * T));
        R01 += 0.0372 * System.Math.Cos(System.Math.PI / 180 * (194.3603 + -474163.962 * T));
        R01 += -0.0358 * System.Math.Cos(System.Math.PI / 180 * (68.2525 + -477048.1893 * T));
        R01 += 0.0357 * System.Math.Cos(System.Math.PI / 180 * (338.1715 + 477349.5459 * T));
        R01 += -0.0354 * System.Math.Cos(System.Math.PI / 180 * (256.2067 + 893569.1287 * T));
        R01 += 0.0349 * System.Math.Cos(System.Math.PI / 180 * (313.9481 + -381779.3998 * T));
        R01 += 0.0349 * System.Math.Cos(System.Math.PI / 180 * (280.3017 + -445642.912 * T));
        R01 += -0.0345 * System.Math.Cos(System.Math.PI / 180 * (210.3094 + 3691.8162 * T));
        R01 += 0.0343 * System.Math.Cos(System.Math.PI / 180 * (237.0396 + -383405.7939 * T));
        R01 += 0.0335 * System.Math.Cos(System.Math.PI / 180 * (197.8798 + -447269.3061 * T));
        R01 += 0.0328 * System.Math.Cos(System.Math.PI / 180 * (267.5876 + 543127.802 * T));
        R01 += -0.0313 * System.Math.Cos(System.Math.PI / 180 * (107.1223 + -413184.6771 * T));
        R01 += -0.0312 * System.Math.Cos(System.Math.PI / 180 * (305.5552 + 888252.9972 * T));
        R01 += -0.0312 * System.Math.Cos(System.Math.PI / 180 * (345.1736 + 510917.0147 * T));
        R01 += 0.031 * System.Math.Cos(System.Math.PI / 180 * (308.5586 + 413486.0337 * T));
        R01 += -0.0305 * System.Math.Cos(System.Math.PI / 180 * (322.4131 + 476209.1979 * T));
        R01 += -0.0301 * System.Math.Cos(System.Math.PI / 180 * (331.4188 + -890383.5447 * T));
        R01 += 0.0298 * System.Math.Cos(System.Math.PI / 180 * (82.6856 + 890684.9013 * T));
        R01 += -0.0287 * System.Math.Cos(System.Math.PI / 180 * (51.4328 + 477180.0382 * T));
        R01 += 0.0286 * System.Math.Cos(System.Math.PI / 180 * (192.1168 + -892815.4488 * T));
        R01 += 0.0285 * System.Math.Cos(System.Math.PI / 180 * (141.5781 + -477217.6971 * T));
        R01 += -0.0284 * System.Math.Cos(System.Math.PI / 180 * (172.3154 + 411054.1296 * T));
        R01 += -0.0283 * System.Math.Cos(System.Math.PI / 180 * (74.3152 + 422372.8682 * T));
        R01 += 0.0281 * System.Math.Cos(System.Math.PI / 180 * (125.0446 + -1934.1362 * T));
        R01 += -0.0278 * System.Math.Cos(System.Math.PI / 180 * (190.1819 + 508754.8232 * T));
        R01 += -0.0276 * System.Math.Cos(System.Math.PI / 180 * (108.1767 + 507128.4291 * T));
        R01 += 0.0275 * System.Math.Cos(System.Math.PI / 180 * (317.223 + 913052.6659 * T));
        R01 += 0.027 * System.Math.Cos(System.Math.PI / 180 * (28.2595 + 899571.7358 * T));
        R01 += 0.0267 * System.Math.Cos(System.Math.PI / 180 * (237.7031 + 467409.7538 * T));
        R01 += -0.0261 * System.Math.Cos(System.Math.PI / 180 * (163.2605 + 45036.8856 * T));
        R01 += 0.0259 * System.Math.Cos(System.Math.PI / 180 * (329.7457 + -415616.5812 * T));
        R01 += -0.0249 * System.Math.Cos(System.Math.PI / 180 * (34.9726 + 952463.5991 * T));
        R01 += 0.0247 * System.Math.Cos(System.Math.PI / 180 * (215.119 + -956331.8714 * T));
        R01 += -0.0246 * System.Math.Cos(System.Math.PI / 180 * (343.9612 + 953428.2517 * T));
        R01 += 0.0234 * System.Math.Cos(System.Math.PI / 180 * (73.7487 + -969.4835 * T));
        R01 += -0.0221 * System.Math.Cos(System.Math.PI / 180 * (232.3556 + -827640.1943 * T));
        R01 += 0.022 * System.Math.Cos(System.Math.PI / 180 * (229.8589 + 548446.0123 * T));
        R01 += 0.0214 * System.Math.Cos(System.Math.PI / 180 * (292.9869 + 512228.7569 * T));
        R01 += -0.0211 * System.Math.Cos(System.Math.PI / 180 * (319.7423 + 489928.1967 * T));
        R01 += -0.0201 * System.Math.Cos(System.Math.PI / 180 * (15.3412 + -821570.383 * T));

        double R02 = 0;
        R02 += 0.514 * System.Math.Cos(System.Math.PI / 180 * (238.171 + 854535.173 * T));
        R02 += 0.3825 * System.Math.Cos(System.Math.PI / 180 * (103.208 + 377336.305 * T));
        R02 += 0.3265 * System.Math.Cos(System.Math.PI / 180 * (222.566 + -441199.817 * T));
        R02 += -0.264 * System.Math.Cos(System.Math.PI / 180 * (132.493 + 513197.918 * T));
        R02 += -0.123 * System.Math.Cos(System.Math.PI / 180 * (357.529 + 35999.05 * T));
        R02 += -0.0775 * System.Math.Cos(System.Math.PI / 180 * (233.23 + 926533.273 * T));
        R02 += -0.0607 * System.Math.Cos(System.Math.PI / 180 * (98.266 + 449334.406 * T));
        R02 += 0.0497 * System.Math.Cos(System.Math.PI / 180 * (240.642 + 818536.122 * T));
        R02 += 0.0419 * System.Math.Cos(System.Math.PI / 180 * (295.379 + 481266.162 * T));
        R02 += 0.0322 * System.Math.Cos(System.Math.PI / 180 * (13.135 + 1331734.04 * T));
        R02 += -0.0253 * System.Math.Cos(System.Math.PI / 180 * (328.244 + -99862.563 * T));
        R02 += 0.0249 * System.Math.Cos(System.Math.PI / 180 * (105.679 + 341337.255 * T));
        R02 += 0.0176 * System.Math.Cos(System.Math.PI / 180 * (87.602 + -918398.685 * T));
        R02 += -0.0145 * System.Math.Cos(System.Math.PI / 180 * (267.456 + 990396.786 * T));
        R02 += -0.0136 * System.Math.Cos(System.Math.PI / 180 * (237.517 + 890534.223 * T));
        R02 += -0.013 * System.Math.Cos(System.Math.PI / 180 * (252.8 + -477067.019 * T));
        R02 += 0.0123 * System.Math.Cos(System.Math.PI / 180 * (162.968 + 477330.716 * T));
        R02 += -0.0119 * System.Math.Cos(System.Math.PI / 180 * (95.795 + 485333.456 * T));
        R02 += 0.0107 * System.Math.Cos(System.Math.PI / 180 * (220.095 + -405200.767 * T));
        R02 += 0.0099 * System.Math.Cos(System.Math.PI / 180 * (338.908 + 1267870.528 * T));
        R02 += -0.0066 * System.Math.Cos(System.Math.PI / 180 * (8.193 + 1403732.141 * T));
        R02 += -0.0063 * System.Math.Cos(System.Math.PI / 180 * (100.737 + 413335.355 * T));
        R02 += -0.0059 * System.Math.Cos(System.Math.PI / 180 * (130.022 + 549196.968 * T));
        R02 += -0.0054 * System.Math.Cos(System.Math.PI / 180 * (355.058 + 71998.101 * T));
        R02 += 0.0048 * System.Math.Cos(System.Math.PI / 180 * (203.945 + 790671.661 * T));
        R02 += 0.0039 * System.Math.Cos(System.Math.PI / 180 * (113.872 + 1745069.396 * T));
        R02 += 0.0036 * System.Math.Cos(System.Math.PI / 180 * (263.476 + 890666.072 * T));
        R02 += -0.0036 * System.Math.Cos(System.Math.PI / 180 * (152.075 + -890402.374 * T));
        R02 += 0.0033 * System.Math.Cos(System.Math.PI / 180 * (15.606 + 1295734.99 * T));
        R02 += 0.0031 * System.Math.Cos(System.Math.PI / 180 * (243.113 + 782537.072 * T));
        R02 += -0.0025 * System.Math.Cos(System.Math.PI / 180 * (134.963 + 477198.868 * T));
        R02 += -0.0024 * System.Math.Cos(System.Math.PI / 180 * (287.062 + -413203.507 * T));
        R02 += 0.0024 * System.Math.Cos(System.Math.PI / 180 * (70.343 + 958465.029 * T));
        R02 += 0.0023 * System.Math.Cos(System.Math.PI / 180 * (128.524 + 413467.204 * T));
        R02 += -0.0023 * System.Math.Cos(System.Math.PI / 180 * (257.953 + 476229.384 * T));
        R02 += -0.0021 * System.Math.Cos(System.Math.PI / 180 * (160.416 + 4067.294 * T));
        R02 += 0.0021 * System.Math.Cos(System.Math.PI / 180 * (148.098 + 1808932.908 * T));
        R02 += -0.0018 * System.Math.Cos(System.Math.PI / 180 * (317.715 + 477178.681 * T));
        R02 += 0.0018 * System.Math.Cos(System.Math.PI / 180 * (47.788 + -477219.054 * T));
        R02 += -0.0017 * System.Math.Cos(System.Math.PI / 180 * (330.715 + -135861.613 * T));
        R02 += -0.0017 * System.Math.Cos(System.Math.PI / 180 * (51.627 + -111868.862 * T));
        R02 += -0.0015 * System.Math.Cos(System.Math.PI / 180 * (333.967 + 1339868.629 * T));
        R02 += 0.0014 * System.Math.Cos(System.Math.PI / 180 * (341.379 + 1231871.478 * T));
        R02 += 0.0013 * System.Math.Cos(System.Math.PI / 180 * (307.724 + -890554.409 * T));
        R02 += -0.0013 * System.Math.Cos(System.Math.PI / 180 * (59.126 + 890514.037 * T));
        R02 += -0.0013 * System.Math.Cos(System.Math.PI / 180 * (284.325 + 413315.169 * T));
        R02 += 0.0013 * System.Math.Cos(System.Math.PI / 180 * (82.849 + -413355.542 * T));
        R02 += -0.0013 * System.Math.Cos(System.Math.PI / 180 * (300.321 + 409268.061 * T));
        R02 += -0.0013 * System.Math.Cos(System.Math.PI / 180 * (193.281 + -577061.43 * T));
        R02 += -0.0012 * System.Math.Cos(System.Math.PI / 180 * (32.361 + 477158.11 * T));
        R02 += 0.0012 * System.Math.Cos(System.Math.PI / 180 * (122.434 + -477239.625 * T));
        R02 += -0.0011 * System.Math.Cos(System.Math.PI / 180 * (10.664 + 1367733.091 * T));
        R02 += 0.0011 * System.Math.Cos(System.Math.PI / 180 * (108.15 + 305338.205 * T));
        R02 += 0.0011 * System.Math.Cos(System.Math.PI / 180 * (312.639 + -1395597.553 * T));
        R02 += -0.0009 * System.Math.Cos(System.Math.PI / 180 * (42.419 + 1467595.653 * T));
        R02 += -0.0008 * System.Math.Cos(System.Math.PI / 180 * (25.452 + -473131.573 * T));
        R02 += -0.0008 * System.Math.Cos(System.Math.PI / 180 * (49.11 + 525204.218 * T));
        R02 += -0.0008 * System.Math.Cos(System.Math.PI / 180 * (276.664 + -589067.73 * T));
        R02 += -0.0007 * System.Math.Cos(System.Math.PI / 180 * (230.759 + 962532.324 * T));
        R02 += 0.0007 * System.Math.Cos(System.Math.PI / 180 * (228.081 + -477217.697 * T));
        R02 += -0.0007 * System.Math.Cos(System.Math.PI / 180 * (117.737 + -954265.886 * T));
        R02 += 0.0007 * System.Math.Cos(System.Math.PI / 180 * (85.131 + -882399.635 * T));
        R02 += 0.0007 * System.Math.Cos(System.Math.PI / 180 * (297.821 + 954529.584 * T));
        R02 += 0.0006 * System.Math.Cos(System.Math.PI / 180 * (116.343 + 1709070.345 * T));
        R02 += -0.0006 * System.Math.Cos(System.Math.PI / 180 * (41.058 + 822603.417 * T));
        R02 += 0.0006 * System.Math.Cos(System.Math.PI / 180 * (305.948 + -453206.117 * T));
        R02 += -0.0006 * System.Math.Cos(System.Math.PI / 180 * (108.93 + 1817067.496 * T));
        R02 += -0.0006 * System.Math.Cos(System.Math.PI / 180 * (199.003 + 862669.761 * T));






        double R03 = 0;
        R03 += 14.9 * System.Math.Cos(System.Math.PI / 180 * (238.2 + 854535.2 * T));
        R03 += 11.1 * System.Math.Cos(System.Math.PI / 180 * (103.2 + 377336.3 * T));
        R03 += 9.5 * System.Math.Cos(System.Math.PI / 180 * (222.6 + -441199.8 * T));
        R03 += -7.7 * System.Math.Cos(System.Math.PI / 180 * (132.5 + 513197.9 * T));
        R03 += -3.6 * System.Math.Cos(System.Math.PI / 180 * (357.5 + 35999.1 * T));
        R03 += -2.3 * System.Math.Cos(System.Math.PI / 180 * (233.2 + 926533.3 * T));
        R03 += -1.8 * System.Math.Cos(System.Math.PI / 180 * (98.3 + 449334.4 * T));
        R03 += 1.4 * System.Math.Cos(System.Math.PI / 180 * (240.6 + 818536.1 * T));
        R03 += 1.2 * System.Math.Cos(System.Math.PI / 180 * (295.4 + 481266.2 * T));
        R03 += 0.9 * System.Math.Cos(System.Math.PI / 180 * (13.1 + 1331734 * T));
        R03 += -0.7 * System.Math.Cos(System.Math.PI / 180 * (328.2 + -99862.6 * T));
        R03 += 0.7 * System.Math.Cos(System.Math.PI / 180 * (105.7 + 341337.3 * T));
        R03 += 0.5 * System.Math.Cos(System.Math.PI / 180 * (87.6 + -918398.7 * T));
        R03 += -0.4 * System.Math.Cos(System.Math.PI / 180 * (235.7 + 890534.2 * T));
        R03 += -0.4 * System.Math.Cos(System.Math.PI / 180 * (267.5 + 990396.8 * T));
        R03 += 0.3 * System.Math.Cos(System.Math.PI / 180 * (338.9 + 1267870.5 * T));
        R03 += -0.3 * System.Math.Cos(System.Math.PI / 180 * (95.8 + 485333.5 * T));
        R03 += 0.3 * System.Math.Cos(System.Math.PI / 180 * (220.1 + -405200.8 * T));
        R03 += -0.2 * System.Math.Cos(System.Math.PI / 180 * (8.2 + 1403732.1 * T));

        double Aberasi = 0.0708 * System.Math.Cos(System.Math.PI / 180 * (225 + 477199 * T));
        double jarak = 385000.57 + R + R01 + R02 * T + R03 * T * T / 10000;




        return jarak + Aberasi;
    }

    // fungsi koreksi bujur Bulan
    public double lambdaBulan(double T, double L1)
    {


        double L = 0;
        L = +6.28877383 * System.Math.Sin(System.Math.PI / 180 * (134.9634114 + 477198.8676 * T + 89.97 * 0.0001 * T + 14.348 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        L += 1.27401064 * System.Math.Sin(System.Math.PI / 180 * (100.736997 + 413335.3554 * T + -122.571 * 0.0001 * T + -10.684 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += 0.65830943 * System.Math.Sin(System.Math.PI / 180 * (235.7004084 + 890534.223 * T + -32.601 * 0.0001 * T + 3.664 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += 0.21361825 * System.Math.Sin(System.Math.PI / 180 * (269.9268228 + 954397.7353 * T + 179.941 * 0.0001 * T + 28.695 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        L += -0.18511586 * System.Math.Sin(System.Math.PI / 180 * (357.5291092 + 35999.05029 * T + -1.536 * 0.0001 * T + 0.041 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        L += -0.11433213 * System.Math.Sin(System.Math.PI / 180 * (186.5441986 + 966404.0351 * T + -68.058 * 0.0001 * T + -0.567 * 0.000001 * T * T + 0.232 * 0.00000001 * T * T * T * T));
        L += 0.05879321 * System.Math.Sin(System.Math.PI / 180 * (325.7735856 + -63863.51223 * T + -212.541 * 0.0001 * T + -25.031 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        L += 0.05706551 * System.Math.Sin(System.Math.PI / 180 * (103.2078878 + 377336.3051 * T + -121.035 * 0.0001 * T + -10.724 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += 0.05332117 * System.Math.Sin(System.Math.PI / 180 * (10.6638198 + 1367733.091 * T + 57.37 * 0.0001 * T + 18.011 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += 0.04575792 * System.Math.Sin(System.Math.PI / 180 * (238.1712992 + 854535.1727 * T + -31.065 * 0.0001 * T + 3.623 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += -0.04092258 * System.Math.Sin(System.Math.PI / 180 * (222.5656978 + -441199.8173 * T + -91.506 * 0.0001 * T + -14.307 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        L += -0.03471892 * System.Math.Sin(System.Math.PI / 180 * (297.8502042 + 445267.1115 * T + -16.3 * 0.0001 * T + 1.832 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        L += -0.03038341 * System.Math.Sin(System.Math.PI / 180 * (132.4925206 + 513197.9179 * T + 88.434 * 0.0001 * T + 14.388 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        L += 0.01532696 * System.Math.Sin(System.Math.PI / 180 * (49.1562098 + -75869.81202 * T + 35.458 * 0.0001 * T + 4.231 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        L += -0.01252767 * System.Math.Sin(System.Math.PI / 180 * (321.50761 + 1443602.903 * T + 21.912 * 0.0001 * T + 13.78 * 0.000001 * T * T + -6.566 * 0.00000001 * T * T * T * T));
        L += 0.01098147 * System.Math.Sin(System.Math.PI / 180 * (308.4192127 + -489205.1674 * T + 158.029 * 0.0001 * T + 14.915 * 0.000001 * T * T + -7.029 * 0.00000001 * T * T * T * T));
        L += 0.01067495 * System.Math.Sin(System.Math.PI / 180 * (336.4374054 + 1303869.578 * T + -155.171 * 0.0001 * T + -7.02 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += 0.01003439 * System.Math.Sin(System.Math.PI / 180 * (44.8902341 + 1431596.603 * T + 269.911 * 0.0001 * T + 43.043 * 0.000001 * T * T + -20.392 * 0.00000001 * T * T * T * T));
        L += 0.00854794 * System.Math.Sin(System.Math.PI / 180 * (201.473994 + 826670.7108 * T + -245.142 * 0.0001 * T + -21.367 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        L += -0.00788808 * System.Math.Sin(System.Math.PI / 180 * (98.2661062 + 449334.4057 * T + -124.107 * 0.0001 * T + -10.643 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += -0.00676617 * System.Math.Sin(System.Math.PI / 180 * (233.2295176 + 926533.2733 * T + -34.136 * 0.0001 * T + 3.705 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += -0.00516242 * System.Math.Sin(System.Math.PI / 180 * (162.8867928 + -31931.75611 * T + -106.271 * 0.0001 * T + -12.516 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        L += 0.00498735 * System.Math.Sin(System.Math.PI / 180 * (295.3793134 + 481266.1618 * T + -17.836 * 0.0001 * T + 1.873 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        L += 0.00403619 * System.Math.Sin(System.Math.PI / 180 * (13.1347106 + 1331734.04 * T + 58.906 * 0.0001 * T + 17.971 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += 0.00399436 * System.Math.Sin(System.Math.PI / 180 * (145.6272312 + 1844931.958 * T + 147.34 * 0.0001 * T + 32.359 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        L += 0.00386085 * System.Math.Sin(System.Math.PI / 180 * (111.4008168 + 1781068.446 * T + -65.201 * 0.0001 * T + 7.328 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        L += 0.00366502 * System.Math.Sin(System.Math.PI / 180 * (190.8101743 + -541062.3799 * T + -302.511 * 0.0001 * T + -39.379 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        L += -0.00268863 * System.Math.Sin(System.Math.PI / 180 * (87.6022864 + -918398.685 * T + -181.476 * 0.0001 * T + -28.654 * 0.000001 * T * T + 13.594 * 0.00000001 * T * T * T * T));
        L += -0.00260163 * System.Math.Sin(System.Math.PI / 180 * (287.2811957 + 1379739.39 * T + -190.629 * 0.0001 * T + -11.251 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        L += 0.00239043 * System.Math.Sin(System.Math.PI / 180 * (328.2444765 + -99862.56252 * T + -211.005 * 0.0001 * T + -25.072 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        L += -0.00234808 * System.Math.Sin(System.Math.PI / 180 * (72.8136156 + 922465.9791 * T + 73.67 * 0.0001 * T + 16.179 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        L += 0.00223616 * System.Math.Sin(System.Math.PI / 180 * (240.64219 + 818536.1225 * T + -29.529 * 0.0001 * T + 3.582 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += -0.00211949 * System.Math.Sin(System.Math.PI / 180 * (267.4559319 + 990396.7856 * T + 178.405 * 0.0001 * T + 28.736 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        L += -0.00206875 * System.Math.Sin(System.Math.PI / 180 * (355.0582184 + 71998.10058 * T + -3.072 * 0.0001 * T + 0.082 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        L += 0.00204755 * System.Math.Sin(System.Math.PI / 180 * (105.6787787 + 341337.2548 * T + -119.499 * 0.0001 * T + -10.765 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += -0.0017731 * System.Math.Sin(System.Math.PI / 180 * (184.1196211 + 401329.0556 * T + 125.428 * 0.0001 * T + 18.579 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        L += -0.00159489 * System.Math.Sin(System.Math.PI / 180 * (62.244607 + 1856938.258 * T + -100.659 * 0.0001 * T + 3.097 * 0.000001 * T * T + -1.537 * 0.00000001 * T * T * T * T));
        L += 0.001215 * System.Math.Sin(System.Math.PI / 180 * (338.9082962 + 1267870.528 * T + -153.636 * 0.0001 * T + -7.061 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += -0.00111045 * System.Math.Sin(System.Math.PI / 180 * (96.4710214 + 1920801.77 * T + 111.882 * 0.0001 * T + 28.128 * 0.000001 * T * T + -13.363 * 0.00000001 * T * T * T * T));
        L += -0.00089158 * System.Math.Sin(System.Math.PI / 180 * (38.5872012 + 858602.4669 * T + -138.871 * 0.0001 * T + -8.852 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        L += -0.00080959 * System.Math.Sin(System.Math.PI / 180 * (8.192929 + 1403732.141 * T + 55.834 * 0.0001 * T + 18.052 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += 0.00075886 * System.Math.Sin(System.Math.PI / 180 * (203.9448849 + 790671.6605 * T + -243.606 * 0.0001 * T + -21.408 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        L += -0.00071332 * System.Math.Sin(System.Math.PI / 180 * (220.094807 + -405200.767 * T + -93.042 * 0.0001 * T + -14.266 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        L += -0.00070033 * System.Math.Sin(System.Math.PI / 180 * (95.7952154 + 485333.456 * T + -125.643 * 0.0001 * T + -10.602 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += 0.00069136 * System.Math.Sin(System.Math.PI / 180 * (323.3026948 + -27864.46194 * T + -214.077 * 0.0001 * T + -24.99 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        L += 0.00059613 * System.Math.Sin(System.Math.PI / 180 * (51.6271006 + -111868.8623 * T + 36.994 * 0.0001 * T + 4.19 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        L += 0.00054937 * System.Math.Sin(System.Math.PI / 180 * (246.3642282 + 2258267.314 * T + 24.769 * 0.0001 * T + 21.675 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        L += 0.00053713 * System.Math.Sin(System.Math.PI / 180 * (179.8536455 + 1908795.471 * T + 359.881 * 0.0001 * T + 57.39 * 0.000001 * T * T + -27.189 * 0.00000001 * T * T * T * T));
        L += 0.00051966 * System.Math.Sin(System.Math.PI / 180 * (113.8717076 + 1745069.396 * T + -63.665 * 0.0001 * T + 7.287 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        L += -0.00048694 * System.Math.Sin(System.Math.PI / 180 * (27.9233814 + -509130.6237 * T + -196.241 * 0.0001 * T + -26.863 * 0.000001 * T * T + 12.71 * 0.00000001 * T * T * T * T));
        L += -0.00039921 * System.Math.Sin(System.Math.PI / 180 * (46.6853189 + -39870.76173 * T + 33.922 * 0.0001 * T + 4.272 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        L += -0.00038127 * System.Math.Sin(System.Math.PI / 180 * (83.3826241 + -12006.29979 * T + 247.999 * 0.0001 * T + 29.262 * 0.000001 * T * T + -13.826 * 0.00000001 * T * T * T * T));
        L += 0.00035051 * System.Math.Sin(System.Math.PI / 180 * (70.3427248 + 958465.0294 * T + 72.134 * 0.0001 * T + 16.22 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        L += -0.00034003 * System.Math.Sin(System.Math.PI / 180 * (263.6237898 + 381403.5993 * T + -228.841 * 0.0001 * T + -23.199 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        L += 0.00032968 * System.Math.Sin(System.Math.PI / 180 * (66.5105827 + 349471.8432 * T + -335.112 * 0.0001 * T + -35.715 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        L += 0.00032694 * System.Math.Sin(System.Math.PI / 180 * (148.098122 + 1808932.908 * T + 148.876 * 0.0001 * T + 32.318 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        L += -0.00032269 * System.Math.Sin(System.Math.PI / 180 * (130.0216297 + 549196.9682 * T + 86.899 * 0.0001 * T + 14.429 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        L += 0.00029936 * System.Math.Sin(System.Math.PI / 180 * (160.415902 + 4067.294176 * T + -107.806 * 0.0001 * T + -12.475 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        L += 0.00029431 * System.Math.Sin(System.Math.PI / 180 * (280.5906425 + 2322130.826 * T + 237.31 * 0.0001 * T + 46.706 * 0.000001 * T * T + -22.161 * 0.00000001 * T * T * T * T));
        L += -0.00027506 * System.Math.Sin(System.Math.PI / 180 * (197.2080184 + 2334137.126 * T + -10.689 * 0.0001 * T + 17.444 * 0.000001 * T * T + -8.334 * 0.00000001 * T * T * T * T));
        L += 0.00026341 * System.Math.Sin(System.Math.PI / 180 * (55.8467629 + -1018261.247 * T + -392.482 * 0.0001 * T + -53.726 * 0.000001 * T * T + 25.42 * 0.00000001 * T * T * T * T));
        L += 0.0002088 * System.Math.Sin(System.Math.PI / 180 * (15.6056014 + 1295734.99 * T + 60.441 * 0.0001 * T + 17.93 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += -0.00018594 * System.Math.Sin(System.Math.PI / 180 * (312.6388751 + -1395597.553 * T + -271.447 * 0.0001 * T + -43.002 * 0.000001 * T * T + 20.392 * 0.00000001 * T * T * T * T));
        L += -0.00017645 * System.Math.Sin(System.Math.PI / 180 * (333.9665146 + 1339868.629 * T + -156.707 * 0.0001 * T + -6.979 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += -0.00016222 * System.Math.Sin(System.Math.PI / 180 * (207.777027 + 1399664.847 * T + 163.64 * 0.0001 * T + 30.527 * 0.000001 * T * T + -14.479 * 0.00000001 * T * T * T * T));
        L += -0.00016203 * System.Math.Sin(System.Math.PI / 180 * (111.3060056 + -521136.9235 * T + 51.758 * 0.0001 * T + 2.399 * 0.000001 * T * T + -1.116 * 0.00000001 * T * T * T * T));
        L += 0.00015877 * System.Math.Sin(System.Math.PI / 180 * (77.1744024 + 1717204.934 * T + -277.742 * 0.0001 * T + -17.703 * 0.000001 * T * T + 8.288 * 0.00000001 * T * T * T * T));
        L += -0.00015573 * System.Math.Sin(System.Math.PI / 180 * (139.229387 + -1030267.547 * T + -144.483 * 0.0001 * T + -24.464 * 0.000001 * T * T + 11.594 * 0.00000001 * T * T * T * T));
        L += -0.0001547 * System.Math.Sin(System.Math.PI / 180 * (300.321095 + 409268.0612 * T + -14.764 * 0.0001 * T + 1.791 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        L += -0.00015164 * System.Math.Sin(System.Math.PI / 180 * (42.4193433 + 1467595.653 * T + 268.375 * 0.0001 * T + 43.083 * 0.000001 * T * T + -20.392 * 0.00000001 * T * T * T * T));
        L += -0.00014881 * System.Math.Sin(System.Math.PI / 180 * (152.3177843 + 902540.5228 * T + -280.599 * 0.0001 * T + -25.598 * 0.000001 * T * T + 12.057 * 0.00000001 * T * T * T * T));
        L += 0.00013289 * System.Math.Sin(System.Math.PI / 180 * (193.2810651 + -577061.4302 * T + -300.976 * 0.0001 * T + -39.419 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        L += -0.00012605 * System.Math.Sin(System.Math.PI / 180 * (319.0830325 + 878527.9232 * T + 215.398 * 0.0001 * T + 32.926 * 0.000001 * T * T + -15.595 * 0.00000001 * T * T * T * T));
        L += -0.00011839 * System.Math.Sin(System.Math.PI / 180 * (289.7520865 + 1343740.34 * T + -189.093 * 0.0001 * T + -11.292 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        L += 0.00011676 * System.Math.Sin(System.Math.PI / 180 * (13.0883973 + 1932808.07 * T + -136.117 * 0.0001 * T + -1.134 * 0.000001 * T * T + 0.463 * 0.00000001 * T * T * T * T));
        L += 0.00011483 * System.Math.Sin(System.Math.PI / 180 * (184.0733078 + 1002403.085 * T + -69.594 * 0.0001 * T + -0.526 * 0.000001 * T * T + 0.232 * 0.00000001 * T * T * T * T));
        L += 0.00011229 * System.Math.Sin(System.Math.PI / 180 * (173.5506126 + 1335801.335 * T + -48.901 * 0.0001 * T + 5.496 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        L += 0.00010959 * System.Math.Sin(System.Math.PI / 180 * (212.1378138 + 2194403.801 * T + -187.772 * 0.0001 * T + -3.356 * 0.000001 * T * T + 1.491 * 0.00000001 * T * T * T * T));
        L += -0.00010615 * System.Math.Sin(System.Math.PI / 180 * (64.7154979 + 1820939.208 * T + -99.123 * 0.0001 * T + 3.056 * 0.000001 * T * T + -1.537 * 0.00000001 * T * T * T * T));
        L += -0.00010403 * System.Math.Sin(System.Math.PI / 180 * (186.590512 + 365330.0053 * T + 126.964 * 0.0001 * T + 18.538 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        L += -0.00009933 * System.Math.Sin(System.Math.PI / 180 * (199.0031032 + 862669.7611 * T + -246.678 * 0.0001 * T + -21.326 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        L += 0.00009713 * System.Math.Sin(System.Math.PI / 180 * (25.4524906 + -473131.5735 * T + -197.777 * 0.0001 * T + -26.822 * 0.000001 * T * T + 12.71 * 0.00000001 * T * T * T * T));
        L += 0.00009439 * System.Math.Sin(System.Math.PI / 180 * (243.1130809 + 782537.0722 * T + -27.993 * 0.0001 * T + 3.541 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += -0.00009129 * System.Math.Sin(System.Math.PI / 180 * (231.4344328 + 2398000.638 * T + 201.853 * 0.0001 * T + 42.475 * 0.000001 * T * T + -20.16 * 0.00000001 * T * T * T * T));
        L += 0.00008576 * System.Math.Sin(System.Math.PI / 180 * (341.3791871 + 1231871.478 * T + -152.1 * 0.0001 * T + -7.101 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += 0.00008376 * System.Math.Sin(System.Math.PI / 180 * (36.0214992 + -1407603.852 * T + -23.448 * 0.0001 * T + -13.739 * 0.000001 * T * T + 6.566 * 0.00000001 * T * T * T * T));
        L += 0.00008357 * System.Math.Sin(System.Math.PI / 180 * (149.8932068 + 337465.5434 * T + -87.113 * 0.0001 * T + -6.453 * 0.000001 * T * T + 3.028 * 0.00000001 * T * T * T * T));
        L += 0.00008172 * System.Math.Sin(System.Math.PI / 180 * (330.7153673 + -135861.6128 * T + -209.469 * 0.0001 * T + -25.113 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        L += 0.00008126 * System.Math.Sin(System.Math.PI / 180 * (302.2109911 + 1240006.066 * T + -367.713 * 0.0001 * T + -32.051 * 0.000001 * T * T + 15.085 * 0.00000001 * T * T * T * T));
        L += -0.00008062 * System.Math.Sin(System.Math.PI / 180 * (143.1563403 + 1880931.009 * T + 145.804 * 0.0001 * T + 32.4 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        L += -0.00008031 * System.Math.Sin(System.Math.PI / 180 * (108.929926 + 1817067.496 * T + -66.737 * 0.0001 * T + 7.369 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        L += 0.00007847 * System.Math.Sin(System.Math.PI / 180 * (248.835119 + 2222268.263 * T + 26.305 * 0.0001 * T + 21.634 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        L += 0.00007604 * System.Math.Sin(System.Math.PI / 180 * (36.1163104 + 894601.5172 * T + -140.407 * 0.0001 * T + -8.811 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        L += 0.00007316 * System.Math.Sin(System.Math.PI / 180 * (319.0367192 + 1479601.953 * T + 20.376 * 0.0001 * T + 13.821 * 0.000001 * T * T + -6.566 * 0.00000001 * T * T * T * T));
        L += 0.00007064 * System.Math.Sin(System.Math.PI / 180 * (124.3944028 + 1411671.147 * T + -84.359 * 0.0001 * T + 1.265 * 0.000001 * T * T + -0.653 * 0.00000001 * T * T * T * T));
        L += -0.00007029 * System.Math.Sin(System.Math.PI / 180 * (347.006414 + 369397.2995 * T + 19.158 * 0.0001 * T + 6.063 * 0.000001 * T * T + -2.885 * 0.00000001 * T * T * T * T));
        L += -0.00006941 * System.Math.Sin(System.Math.PI / 180 * (320.831804 + 8134.588353 * T + -215.613 * 0.0001 * T + -24.949 * 0.000001 * T * T + 11.826 * 0.00000001 * T * T * T * T));
        L += 0.00006859 * System.Math.Sin(System.Math.PI / 180 * (108.1496695 + 305338.2045 * T + -117.963 * 0.0001 * T + -10.806 * 0.000001 * T * T + 5.028 * 0.00000001 * T * T * T * T));
        L += -0.00006428 * System.Math.Sin(System.Math.PI / 180 * (41.058092 + 822603.4166 * T + -137.335 * 0.0001 * T + -8.893 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        L += 0.0000607 * System.Math.Sin(System.Math.PI / 180 * (21.3276396 + 2735466.181 * T + 114.739 * 0.0001 * T + 36.023 * 0.000001 * T * T + -17.132 * 0.00000001 * T * T * T * T));
        L += -0.00005593 * System.Math.Sin(System.Math.PI / 180 * (162.9816041 + 2270273.613 * T + -223.23 * 0.0001 * T + -7.587 * 0.000001 * T * T + 3.491 * 0.00000001 * T * T * T * T));
        L += -0.00005364 * System.Math.Sin(System.Math.PI / 180 * (85.1313956 + -882399.6347 * T + -183.012 * 0.0001 * T + -28.613 * 0.000001 * T * T + 13.594 * 0.00000001 * T * T * T * T));
        L += -0.0000516 * System.Math.Sin(System.Math.PI / 180 * (230.7586268 + 962532.3236 * T + -35.672 * 0.0001 * T + 3.746 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += 0.00004973 * System.Math.Sin(System.Math.PI / 180 * (274.1927984 + -553068.6797 * T + -54.513 * 0.0001 * T + -10.116 * 0.000001 * T * T + 4.797 * 0.00000001 * T * T * T * T));
        L += 0.00004895 * System.Math.Sin(System.Math.PI / 180 * (188.3392834 + -505063.3296 * T + -304.047 * 0.0001 * T + -39.338 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        L += -0.00004716 * System.Math.Sin(System.Math.PI / 180 * (28.0181927 + 1793074.746 * T + -313.2 * 0.0001 * T + -21.934 * 0.000001 * T * T + 10.288 * 0.00000001 * T * T * T * T));
        L += 0.00004383 * System.Math.Sin(System.Math.PI / 180 * (206.4157757 + 754672.6102 * T + -242.07 * 0.0001 * T + -21.449 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        L += 0.00004229 * System.Math.Sin(System.Math.PI / 180 * (116.3425984 + 1709070.345 * T + -62.129 * 0.0001 * T + 7.246 * 0.000001 * T * T + -3.538 * 0.00000001 * T * T * T * T));
        L += 0.00004164 * System.Math.Sin(System.Math.PI / 180 * (171.0797218 + 1371800.385 * T + -50.437 * 0.0001 * T + 5.537 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        L += -0.00003788 * System.Math.Sin(System.Math.PI / 180 * (165.3576836 + -67930.80641 * T + -104.735 * 0.0001 * T + -12.556 * 0.000001 * T * T + 5.913 * 0.00000001 * T * T * T * T));
        L += -0.00003559 * System.Math.Sin(System.Math.PI / 180 * (252.9599701 + -986329.4914 * T + -286.211 * 0.0001 * T + -41.211 * 0.000001 * T * T + 19.507 * 0.00000001 * T * T * T * T));
        L += 0.00003504 * System.Math.Sin(System.Math.PI / 180 * (347.1012252 + 2671602.669 * T + -97.802 * 0.0001 * T + 10.992 * 0.000001 * T * T + -5.307 * 0.00000001 * T * T * T * T));
        L += -0.00003441 * System.Math.Sin(System.Math.PI / 180 * (332.1714298 + 2811335.993 * T + 79.282 * 0.0001 * T + 31.792 * 0.000001 * T * T + -15.132 * 0.00000001 * T * T * T * T));
        L += -0.00003354 * System.Math.Sin(System.Math.PI / 180 * (75.2845064 + 886466.9289 * T + 75.206 * 0.0001 * T + 16.139 * 0.000001 * T * T + -7.682 * 0.00000001 * T * T * T * T));
        L += 0.00003083 * System.Math.Sin(System.Math.PI / 180 * (314.8170569 + 2385994.338 * T + 449.851 * 0.0001 * T + 71.738 * 0.000001 * T * T + -33.986 * 0.00000001 * T * T * T * T));
        L += -0.00002815 * System.Math.Sin(System.Math.PI / 180 * (352.5873276 + 107997.1509 * T + -4.608 * 0.0001 * T + 0.123 * 0.000001 * T * T + 0 * 0.00000001 * T * T * T * T));
        L += 0.00002773 * System.Math.Sin(System.Math.PI / 180 * (68.9814735 + 313472.7929 * T + -333.576 * 0.0001 * T + -35.756 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        L += 0.00002589 * System.Math.Sin(System.Math.PI / 180 * (283.0615334 + 2286131.776 * T + 238.846 * 0.0001 * T + 46.666 * 0.000001 * T * T + -22.161 * 0.00000001 * T * T * T * T));
        L += 0.00002557 * System.Math.Sin(System.Math.PI / 180 * (205.3061361 + 1435663.897 * T + 162.104 * 0.0001 * T + 30.568 * 0.000001 * T * T + -14.479 * 0.00000001 * T * T * T * T));
        L += -0.00002543 * System.Math.Sin(System.Math.PI / 180 * (4.2659756 + -1507466.415 * T + -234.453 * 0.0001 * T + -38.811 * 0.000001 * T * T + 18.391 * 0.00000001 * T * T * T * T));
        L += 0.00002526 * System.Math.Sin(System.Math.PI / 180 * (148.0518087 + 2410006.938 * T + -46.146 * 0.0001 * T + 13.213 * 0.000001 * T * T + -6.334 * 0.00000001 * T * T * T * T));
        L += 0.00002509 * System.Math.Sin(System.Math.PI / 180 * (79.6452933 + 1681205.884 * T + -276.206 * 0.0001 * T + -17.744 * 0.000001 * T * T + 8.288 * 0.00000001 * T * T * T * T));
        L += -0.00002361 * System.Math.Sin(System.Math.PI / 180 * (297.9450154 + 2747472.481 * T + -133.259 * 0.0001 * T + 6.761 * 0.000001 * T * T + -3.306 * 0.00000001 * T * T * T * T));
        L += 0.00002353 * System.Math.Sin(System.Math.PI / 180 * (181.6487303 + 437328.1059 * T + 123.892 * 0.0001 * T + 18.619 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        L += -0.00002309 * System.Math.Sin(System.Math.PI / 180 * (266.0946807 + 345404.549 * T + -227.306 * 0.0001 * T + -23.24 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        L += -0.00002301 * System.Math.Sin(System.Math.PI / 180 * (305.9483219 + -453206.1171 * T + 156.493 * 0.0001 * T + 14.956 * 0.000001 * T * T + -7.029 * 0.00000001 * T * T * T * T));
        L += -0.00002236 * System.Math.Sin(System.Math.PI / 180 * (49.1098964 + 525204.2177 * T + -159.564 * 0.0001 * T + -14.874 * 0.000001 * T * T + 7.029 * 0.00000001 * T * T * T * T));
        L += -0.00002228 * System.Math.Sin(System.Math.PI / 180 * (121.8750141 + -1455609.202 * T + 226.087 * 0.0001 * T + 15.482 * 0.000001 * T * T + -7.261 * 0.00000001 * T * T * T * T));
        L += 0.00002157 * System.Math.Sin(System.Math.PI / 180 * (55.5540539 + 2799329.694 * T + 327.281 * 0.0001 * T + 61.054 * 0.000001 * T * T + -28.958 * 0.00000001 * T * T * T * T));
        L += -0.00002088 * System.Math.Sin(System.Math.PI / 180 * (222.6120111 + -1042273.847 * T + 103.516 * 0.0001 * T + 4.798 * 0.000001 * T * T + -2.232 * 0.00000001 * T * T * T * T));
        L += 0.00002084 * System.Math.Sin(System.Math.PI / 180 * (170.9849105 + -930404.9848 * T + 66.523 * 0.0001 * T + 0.608 * 0.000001 * T * T + -0.232 * 0.00000001 * T * T * T * T));
        L += -0.00002048 * System.Math.Sin(System.Math.PI / 180 * (199.6789092 + 2298138.075 * T + -9.153 * 0.0001 * T + 17.403 * 0.000001 * T * T + -8.334 * 0.00000001 * T * T * T * T));
        L += 0.00001984 * System.Math.Sin(System.Math.PI / 180 * (214.6087046 + 2158404.751 * T + -186.236 * 0.0001 * T + -3.397 * 0.000001 * T * T + 1.491 * 0.00000001 * T * T * T * T));
        L += 0.00001903 * System.Math.Sin(System.Math.PI / 180 * (280.8833515 + -1495460.115 * T + -482.452 * 0.0001 * T + -68.074 * 0.000001 * T * T + 32.217 * 0.00000001 * T * T * T * T));
        L += 0.00001873 * System.Math.Sin(System.Math.PI / 180 * (284.8103048 + 1415738.441 * T + -192.165 * 0.0001 * T + -11.21 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        L += -0.00001834 * System.Math.Sin(System.Math.PI / 180 * (59.8200295 + 1291863.279 * T + 92.828 * 0.0001 * T + 22.243 * 0.000001 * T * T + -10.567 * 0.00000001 * T * T * T * T));
        L += 0.00001817 * System.Math.Sin(System.Math.PI / 180 * (59.7737162 + 1892937.308 * T + -102.195 * 0.0001 * T + 3.138 * 0.000001 * T * T + -1.537 * 0.00000001 * T * T * T * T));
        L += -0.00001809 * System.Math.Sin(System.Math.PI / 180 * (264.9850411 + 1026395.836 * T + 176.869 * 0.0001 * T + 28.777 * 0.000001 * T * T + -13.594 * 0.00000001 * T * T * T * T));
        L += 0.00001808 * System.Math.Sin(System.Math.PI / 180 * (176.0215034 + 1299802.284 * T + -47.365 * 0.0001 * T + 5.455 * 0.000001 * T * T + -2.653 * 0.00000001 * T * T * T * T));
        L += 0.00001789 * System.Math.Sin(System.Math.PI / 180 * (150.5690128 + 1772933.858 * T + 150.412 * 0.0001 * T + 32.277 * 0.000001 * T * T + -15.363 * 0.00000001 * T * T * T * T));
        L += 0.00001754 * System.Math.Sin(System.Math.PI / 180 * (54.0979914 + -147867.9126 * T + 38.529 * 0.0001 * T + 4.149 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        L += -0.00001695 * System.Math.Sin(System.Math.PI / 180 * (276.6636892 + -589067.7299 * T + -52.977 * 0.0001 * T + -10.157 * 0.000001 * T * T + 4.797 * 0.00000001 * T * T * T * T));
        L += -0.0000159 * System.Math.Sin(System.Math.PI / 180 * (139.3241982 + 1271937.822 * T + -261.442 * 0.0001 * T + -19.535 * 0.000001 * T * T + 9.172 * 0.00000001 * T * T * T * T));
        L += -0.00001579 * System.Math.Sin(System.Math.PI / 180 * (218.3460355 + 465192.5678 * T + 337.969 * 0.0001 * T + 43.61 * 0.000001 * T * T + -20.623 * 0.00000001 * T * T * T * T));
        L += 0.00001435 * System.Math.Sin(System.Math.PI / 180 * (261.0580878 + -1884802.72 * T + -113.418 * 0.0001 * T + -28.087 * 0.000001 * T * T + 13.363 * 0.00000001 * T * T * T * T));
        L += -0.00001428 * System.Math.Sin(System.Math.PI / 180 * (217.6239162 + -369201.7168 * T + -94.578 * 0.0001 * T + -14.225 * 0.000001 * T * T + 6.797 * 0.00000001 * T * T * T * T));
        L += -0.00001408 * System.Math.Sin(System.Math.PI / 180 * (243.8933374 + 2294266.364 * T + 23.233 * 0.0001 * T + 21.716 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        L += -0.00001306 * System.Math.Sin(System.Math.PI / 180 * (177.6754637 + -1872796.42 * T + -361.417 * 0.0001 * T + -57.349 * 0.000001 * T * T + 27.189 * 0.00000001 * T * T * T * T));
        L += 0.00001236 * System.Math.Sin(System.Math.PI / 180 * (259.3578142 + 1888870.014 * T + 5.612 * 0.0001 * T + 15.612 * 0.000001 * T * T + -7.45 * 0.00000001 * T * T * T * T));
        L += -0.00001234 * System.Math.Sin(System.Math.PI / 180 * (128.6603785 + -95795.26834 * T + -318.812 * 0.0001 * T + -37.547 * 0.000001 * T * T + 17.738 * 0.00000001 * T * T * T * T));
        L += 0.00001205 * System.Math.Sin(System.Math.PI / 180 * (94.0001306 + 1956800.821 * T + 110.346 * 0.0001 * T + 28.169 * 0.000001 * T * T + -13.363 * 0.00000001 * T * T * T * T));
        L += 0.00001196 * System.Math.Sin(System.Math.PI / 180 * (302.7919858 + 373269.0109 * T + -13.229 * 0.0001 * T + 1.75 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        L += -0.00001164 * System.Math.Sin(System.Math.PI / 180 * (261.152899 + 417402.6496 * T + -230.377 * 0.0001 * T + -23.158 * 0.000001 * T * T + 10.941 * 0.00000001 * T * T * T * T));
        L += -0.00001132 * System.Math.Sin(System.Math.PI / 180 * (342.7404383 + 1876863.714 * T + 253.611 * 0.0001 * T + 44.874 * 0.000001 * T * T + -21.276 * 0.00000001 * T * T * T * T));
        L += -0.00001114 * System.Math.Sin(System.Math.PI / 180 * (246.2694169 + -43938.05591 * T + 141.728 * 0.0001 * T + 16.747 * 0.000001 * T * T + -7.913 * 0.00000001 * T * T * T * T));
        L += -0.00001102 * System.Math.Sin(System.Math.PI / 180 * (292.9084226 + 517265.2121 * T + -19.372 * 0.0001 * T + 1.914 * 0.000001 * T * T + -0.884 * 0.00000001 * T * T * T * T));
        L += -0.00001096 * System.Math.Sin(System.Math.PI / 180 * (177.3827547 + 1944794.521 * T + 358.345 * 0.0001 * T + 57.431 * 0.000001 * T * T + -27.189 * 0.00000001 * T * T * T * T));
        L += 0.00001083 * System.Math.Sin(System.Math.PI / 180 * (304.6818819 + 1204007.016 * T + -366.177 * 0.0001 * T + -32.092 * 0.000001 * T * T + 15.085 * 0.00000001 * T * T * T * T));
        L += -0.00000996 * System.Math.Sin(System.Math.PI / 180 * (121.923512 + 1447670.197 * T + -85.894 * 0.0001 * T + 1.306 * 0.000001 * T * T + -0.653 * 0.00000001 * T * T * T * T));
        L += -0.00000976 * System.Math.Sin(System.Math.PI / 180 * (196.5322124 + 898668.8114 * T + -248.213 * 0.0001 * T + -21.286 * 0.000001 * T * T + 10.057 * 0.00000001 * T * T * T * T));
        L += -0.00000927 * System.Math.Sin(System.Math.PI / 180 * (94.0464439 + 1355726.791 * T + 305.369 * 0.0001 * T + 47.274 * 0.000001 * T * T + -22.392 * 0.00000001 * T * T * T * T));
        L += 0.00000917 * System.Math.Sin(System.Math.PI / 180 * (18.0764922 + 1259735.94 * T + 61.977 * 0.0001 * T + 17.889 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += 0.00000909 * System.Math.Sin(System.Math.PI / 180 * (23.7985304 + 2699467.131 * T + 116.275 * 0.0001 * T + 35.982 * 0.000001 * T * T + -17.132 * 0.00000001 * T * T * T * T));
        L += -0.00000828 * System.Math.Sin(System.Math.PI / 180 * (212.0430026 + -107801.5681 * T + -70.813 * 0.0001 * T + -8.284 * 0.000001 * T * T + 3.912 * 0.00000001 * T * T * T * T));
        L += 0.00000819 * System.Math.Sin(System.Math.PI / 180 * (58.3176537 + -1054260.298 * T + -390.946 * 0.0001 * T + -53.767 * 0.000001 * T * T + 25.42 * 0.00000001 * T * T * T * T));
        L += -0.00000802 * System.Math.Sin(System.Math.PI / 180 * (321.5539233 + 842528.873 * T + 216.934 * 0.0001 * T + 32.885 * 0.000001 * T * T + -15.595 * 0.00000001 * T * T * T * T));
        L += -0.00000779 * System.Math.Sin(System.Math.PI / 180 * (141.7002778 + -1066266.598 * T + -142.947 * 0.0001 * T + -24.505 * 0.000001 * T * T + 11.594 * 0.00000001 * T * T * T * T));
        L += 0.00000745 * System.Math.Sin(System.Math.PI / 180 * (64.0396919 + 385470.8935 * T + -336.648 * 0.0001 * T + -35.674 * 0.000001 * T * T + 16.854 * 0.00000001 * T * T * T * T));
        L += 0.00000744 * System.Math.Sin(System.Math.PI / 180 * (80.9117333 + 23992.7505 * T + 246.463 * 0.0001 * T + 29.303 * 0.000001 * T * T + -13.826 * 0.00000001 * T * T * T * T));
        L += -0.00000743 * System.Math.Sin(System.Math.PI / 180 * (278.1197517 + 2358129.876 * T + 235.774 * 0.0001 * T + 46.747 * 0.000001 * T * T + -22.161 * 0.00000001 * T * T * T * T));
        L += -0.00000723 * System.Math.Sin(System.Math.PI / 180 * (6.3978442 + 2875199.506 * T + 291.823 * 0.0001 * T + 56.823 * 0.000001 * T * T + -26.957 * 0.00000001 * T * T * T * T));
        L += 0.00000697 * System.Math.Sin(System.Math.PI / 180 * (349.572116 + 2635603.619 * T + -96.266 * 0.0001 * T + 10.951 * 0.000001 * T * T + -5.307 * 0.00000001 * T * T * T * T));
        L += 0.00000675 * System.Math.Sin(System.Math.PI / 180 * (274.1464851 + 48005.35008 * T + -249.535 * 0.0001 * T + -29.221 * 0.000001 * T * T + 13.826 * 0.00000001 * T * T * T * T));
        L += 0.0000067 * System.Math.Sin(System.Math.PI / 180 * (251.3060098 + 2186269.213 * T + 27.841 * 0.0001 * T + 21.594 * 0.000001 * T * T + -10.335 * 0.00000001 * T * T * T * T));
        L += -0.00000664 * System.Math.Sin(System.Math.PI / 180 * (284.8566182 + 814664.411 * T + 2.857 * 0.0001 * T + 7.895 * 0.000001 * T * T + -3.769 * 0.00000001 * T * T * T * T));
        L += -0.00000661 * System.Math.Sin(System.Math.PI / 180 * (336.3425942 + -998335.7912 * T + -38.212 * 0.0001 * T + -11.948 * 0.000001 * T * T + 5.681 * 0.00000001 * T * T * T * T));
        L += -0.00000653 * System.Math.Sin(System.Math.PI / 180 * (44.2144281 + -3871.711439 * T + 32.386 * 0.0001 * T + 4.313 * 0.000001 * T * T + -2.001 * 0.00000001 * T * T * T * T));
        L += 0.00000638 * System.Math.Sin(System.Math.PI / 180 * (250.4890792 + -950330.4411 * T + -287.747 * 0.0001 * T + -41.17 * 0.000001 * T * T + 19.507 * 0.00000001 * T * T * T * T));
        L += 0.00000636 * System.Math.Sin(System.Math.PI / 180 * (152.3640976 + 301466.4931 * T + -85.577 * 0.0001 * T + -6.493 * 0.000001 * T * T + 3.028 * 0.00000001 * T * T * T * T));
        L += 0.00000635 * System.Math.Sin(System.Math.PI / 180 * (122.0646366 + 3148801.537 * T + -7.831 * 0.0001 * T + 25.339 * 0.000001 * T * T + -12.104 * 0.00000001 * T * T * T * T));
        L += -0.00000631 * System.Math.Sin(System.Math.PI / 180 * (165.4524949 + 2234274.563 * T + -221.694 * 0.0001 * T + -7.628 * 0.000001 * T * T + 3.491 * 0.00000001 * T * T * T * T));
        L += 0.00000623 * System.Math.Sin(System.Math.PI / 180 * (306.0431332 + 1848999.252 * T + 39.534 * 0.0001 * T + 19.884 * 0.000001 * T * T + -9.451 * 0.00000001 * T * T * T * T));
        L += -0.00000603 * System.Math.Sin(System.Math.PI / 180 * (331.4956238 + 1375867.679 * T + -158.243 * 0.0001 * T + -6.938 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += -0.00000599 * System.Math.Sin(System.Math.PI / 180 * (154.7886751 + 866541.4725 * T + -279.064 * 0.0001 * T + -25.639 * 0.000001 * T * T + 12.057 * 0.00000001 * T * T * T * T));
        L += 0.00000597 * System.Math.Sin(System.Math.PI / 180 * (156.2910509 + 3212665.049 * T + 204.71 * 0.0001 * T + 50.37 * 0.000001 * T * T + -23.929 * 0.00000001 * T * T * T * T));
        L += 0.00000554 * System.Math.Sin(System.Math.PI / 180 * (113.8253943 + 2346143.426 * T + -258.688 * 0.0001 * T + -11.818 * 0.000001 * T * T + 5.492 * 0.00000001 * T * T * T * T));
        L += -0.00000541 * System.Math.Sin(System.Math.PI / 180 * (349.4773048 + 333398.2492 * T + 20.693 * 0.0001 * T + 6.022 * 0.000001 * T * T + -2.885 * 0.00000001 * T * T * T * T));
        L += -0.00000521 * System.Math.Sin(System.Math.PI / 180 * (147.422316 + 373464.5937 * T + -88.649 * 0.0001 * T + -6.412 * 0.000001 * T * T + 3.028 * 0.00000001 * T * T * T * T));
        L += 0.00000505 * System.Math.Sin(System.Math.PI / 180 * (53.3758721 + -982262.1972 * T + -394.018 * 0.0001 * T + -53.685 * 0.000001 * T * T + 25.42 * 0.00000001 * T * T * T * T));
        L += -0.00000504 * System.Math.Sin(System.Math.PI / 180 * (67.1863887 + 1784940.158 * T + -97.587 * 0.0001 * T + 3.015 * 0.000001 * T * T + -1.537 * 0.00000001 * T * T * T * T));
        L += -0.00000499 * System.Math.Sin(System.Math.PI / 180 * (127.5507389 + 585196.0185 * T + 85.363 * 0.0001 * T + 14.47 * 0.000001 * T * T + -6.797 * 0.00000001 * T * T * T * T));
        L += -0.00000495 * System.Math.Sin(System.Math.PI / 180 * (72.9084268 + 3224671.349 * T + -43.289 * 0.0001 * T + 21.108 * 0.000001 * T * T + -10.103 * 0.00000001 * T * T * T * T));
        L += 0.00000484 * System.Math.Sin(System.Math.PI / 180 * (343.8500779 + 1195872.428 * T + -150.564 * 0.0001 * T + -7.142 * 0.000001 * T * T + 3.259 * 0.00000001 * T * T * T * T));
        L += -0.00000468 * System.Math.Sin(System.Math.PI / 180 * (4.3607869 + 794738.9547 * T + -351.412 * 0.0001 * T + -33.883 * 0.000001 * T * T + 15.969 * 0.00000001 * T * T * T * T));
        L += -0.00000457 * System.Math.Sin(System.Math.PI / 180 * (189.0614028 + 329330.955 * T + 128.5 * 0.0001 * T + 18.497 * 0.000001 * T * T + -8.798 * 0.00000001 * T * T * T * T));
        L += 0.00000446 * System.Math.Sin(System.Math.PI / 180 * (194.7371276 + 2370136.176 * T + -12.224 * 0.0001 * T + 17.485 * 0.000001 * T * T + -8.334 * 0.00000001 * T * T * T * T));
        L += 0.00000444 * System.Math.Sin(System.Math.PI / 180 * (349.4309915 + 934472.2789 * T + -174.329 * 0.0001 * T + -13.083 * 0.000001 * T * T + 6.144 * 0.00000001 * T * T * T * T));
        L += 0.00000429 * System.Math.Sin(System.Math.PI / 180 * (195.7519559 + -613060.4804 * T + -299.44 * 0.0001 * T + -39.46 * 0.000001 * T * T + 18.623 * 0.00000001 * T * T * T * T));
        L += -0.00000428 * System.Math.Sin(System.Math.PI / 180 * (292.2229773 + 1307741.29 * T + -187.558 * 0.0001 * T + -11.333 * 0.000001 * T * T + 5.26 * 0.00000001 * T * T * T * T));
        L += -0.00000426 * System.Math.Sin(System.Math.PI / 180 * (30.4890835 + 1757075.696 * T + -311.664 * 0.0001 * T + -21.975 * 0.000001 * T * T + 10.288 * 0.00000001 * T * T * T * T));
        L += -0.00000421 * System.Math.Sin(System.Math.PI / 180 * (310.1679842 + -1359598.502 * T + -272.983 * 0.0001 * T + -42.961 * 0.000001 * T * T + 20.392 * 0.00000001 * T * T * T * T));
        L += -0.00000412 * System.Math.Sin(System.Math.PI / 180 * (210.2479178 + 1363665.796 * T + 165.176 * 0.0001 * T + 30.486 * 0.000001 * T * T + -14.479 * 0.00000001 * T * T * T * T));
        L += 0.00000382 * System.Math.Sin(System.Math.PI / 180 * (167.2475797 + 762807.1986 * T + -457.683 * 0.0001 * T + -46.398 * 0.000001 * T * T + 21.882 * 0.00000001 * T * T * T * T));
        L += 0.00000381 * System.Math.Sin(System.Math.PI / 180 * (248.7888057 + 2823342.293 * T + -168.717 * 0.0001 * T + 2.529 * 0.000001 * T * T + -1.306 * 0.00000001 * T * T * T * T));
        L += -0.00000375 * System.Math.Sin(System.Math.PI / 180 * (274.2876096 + 1749136.69 * T + -171.472 * 0.0001 * T + -5.188 * 0.000001 * T * T + 2.375 * 0.00000001 * T * T * T * T));
        L += -0.00000373 * System.Math.Sin(System.Math.PI / 180 * (5.7220381 + 1439731.191 * T + 54.298 * 0.0001 * T + 18.093 * 0.000001 * T * T + -8.566 * 0.00000001 * T * T * T * T));
        L += -0.0000037 * System.Math.Sin(System.Math.PI / 180 * (107.1348412 + 3288534.861 * T + 169.252 * 0.0001 * T + 46.139 * 0.000001 * T * T + -21.929 * 0.00000001 * T * T * T * T));
        L += 0.0000037 * System.Math.Sin(System.Math.PI / 180 * (245.5839717 + 746538.0219 * T + -26.457 * 0.0001 * T + 3.501 * 0.000001 * T * T + -1.769 * 0.00000001 * T * T * T * T));
        L += 0.0000036 * System.Math.Sin(System.Math.PI / 180 * (283.01522 + 2887205.805 * T + 43.824 * 0.0001 * T + 27.561 * 0.000001 * T * T + -13.131 * 0.00000001 * T * T * T * T));
        L += -0.00000356 * System.Math.Sin(System.Math.PI / 180 * (74.7035116 + 1753203.984 * T + -279.278 * 0.0001 * T + -17.663 * 0.000001 * T * T + 8.288 * 0.00000001 * T * T * T * T));
        L += -0.00000356 * System.Math.Sin(System.Math.PI / 180 * (113.7768964 + -557135.9738 * T + 53.294 * 0.0001 * T + 2.358 * 0.000001 * T * T + -1.116 * 0.00000001 * T * T * T * T));
        L += 0.00000338 * System.Math.Sin(System.Math.PI / 180 * (225.1313999 + 1825006.502 * T + -206.929 * 0.0001 * T + -9.419 * 0.000001 * T * T + 4.376 * 0.00000001 * T * T * T * T));
        L += -0.00000328 * System.Math.Sin(System.Math.PI / 180 * (43.5289829 + 786604.3663 * T + -135.799 * 0.0001 * T + -8.933 * 0.000001 * T * T + 4.144 * 0.00000001 * T * T * T * T));
        L += -0.00000309 * System.Math.Sin(System.Math.PI / 180 * (300.4159063 + 2711473.431 * T + -131.724 * 0.0001 * T + 6.72 * 0.000001 * T * T + -3.306 * 0.00000001 * T * T * T * T));
        L += -0.00000299 * System.Math.Sin(System.Math.PI / 180 * (229.3025643 + -1984665.283 * T + -324.423 * 0.0001 * T + -53.159 * 0.000001 * T * T + 25.188 * 0.00000001 * T * T * T * T));
        L += -0.00000296 * System.Math.Sin(System.Math.PI / 180 * (209.666923 + 2230402.852 * T + -189.308 * 0.0001 * T + -3.315 * 0.000001 * T * T + 1.491 * 0.00000001 * T * T * T * T));
        L += -0.00000295 * System.Math.Sin(System.Math.PI / 180 * (121.9698253 + 846596.1671 * T + 109.128 * 0.0001 * T + 20.411 * 0.000001 * T * T + -9.682 * 0.00000001 * T * T * T * T));
        L += -0.0000028 * System.Math.Sin(System.Math.PI / 180 * (334.6423206 + 2775336.943 * T + 80.817 * 0.0001 * T + 31.751 * 0.000001 * T * T + -15.132 * 0.00000001 * T * T * T * T));

        double L01 = 0;
        L01 += 3.95801 * System.Math.Sin(System.Math.PI / 180 * (119.7524 + 131.8489 * T));
        L01 += 1.96196 * System.Math.Sin(System.Math.PI / 180 * (125.0455 + -1934.1362 * T));
        L01 += -0.31752 * System.Math.Sin(System.Math.PI / 180 * (233.0867 + 479264.2898 * T));
        L01 += 0.25032 * System.Math.Sin(System.Math.PI / 180 * (107.4411 + -20.1862 * T));
        L01 += -0.22821 * System.Math.Sin(System.Math.PI / 180 * (81.5232 + 22518.4428 * T));
        L01 += 0.21892 * System.Math.Sin(System.Math.PI / 180 * (344.7896 + -477067.0188 * T));
        L01 += 0.20536 * System.Math.Sin(System.Math.PI / 180 * (254.7188 + 477330.7165 * T));
        L01 += -0.17881 * System.Math.Sin(System.Math.PI / 180 * (345.2585 + 480890.6839 * T));
        L01 += 0.17744 * System.Math.Sin(System.Math.PI / 180 * (67.3439 + 32964.4672 * T));
        L01 += 0.1565 * System.Math.Sin(System.Math.PI / 180 * (276.7408 + -18.8294 * T));
        L01 += 0.13703 * System.Math.Sin(System.Math.PI / 180 * (260.0092 + 475264.7314 * T));
        L01 += 0.1365 * System.Math.Sin(System.Math.PI / 180 * (350.0824 + -479133.0038 * T));
        L01 += 0.1237 * System.Math.Sin(System.Math.PI / 180 * (208.6855 + 476229.3841 * T));
        L01 += 0.10017 * System.Math.Sin(System.Math.PI / 180 * (311.5895 + 964469.8989 * T));
        L01 += -0.09543 * System.Math.Sin(System.Math.PI / 180 * (152.5142 + 9037.5128 * T));
        L01 += 0.09015 * System.Math.Sin(System.Math.PI / 180 * (67.7377 + -2281.2258 * T));
        L01 += 0.08376 * System.Math.Sin(System.Math.PI / 180 * (163.2312 + 45036.8856 * T));
        L01 += -0.08038 * System.Math.Sin(System.Math.PI / 180 * (220.1798 + -1935.5332 * T));
        L01 += 0.07856 * System.Math.Sin(System.Math.PI / 180 * (73.6904 + -969.4835 * T));
        L01 += 0.0681 * System.Math.Sin(System.Math.PI / 180 * (98.0899 + 2065.4221 * T));
        L01 += -0.06292 * System.Math.Sin(System.Math.PI / 180 * (205.5247 + 150.6783 * T));
        L01 += 0.05866 * System.Math.Sin(System.Math.PI / 180 * (327.1213 + -380370.8882 * T));
        L01 += 0.05401 * System.Math.Sin(System.Math.PI / 180 * (209.8312 + 33718.147 * T));
        L01 += -0.05127 * System.Math.Sin(System.Math.PI / 180 * (132.666 + 65928.9344 * T));
        L01 += 0.05071 * System.Math.Sin(System.Math.PI / 180 * (357.251 + -411269.9333 * T));
        L01 += 0.04864 * System.Math.Sin(System.Math.PI / 180 * (55.0668 + 31555.9556 * T));
        L01 += 0.04745 * System.Math.Sin(System.Math.PI / 180 * (331.4784 + -477219.0538 * T));
        L01 += 0.04745 * System.Math.Sin(System.Math.PI / 180 * (241.4051 + 477178.6814 * T));
        L01 += 0.04642 * System.Math.Sin(System.Math.PI / 180 * (19.0127 + -413203.5065 * T));
        L01 += 0.04583 * System.Math.Sin(System.Math.PI / 180 * (192.2174 + -857569.7559 * T));
        L01 += 0.04567 * System.Math.Sin(System.Math.PI / 180 * (244.0516 + -890402.3742 * T));
        L01 += 0.04563 * System.Math.Sin(System.Math.PI / 180 * (332.7695 + 29929.5615 * T));
        L01 += 0.04549 * System.Math.Sin(System.Math.PI / 180 * (166.0821 + -40.7576 * T));
        L01 += 0.04528 * System.Math.Sin(System.Math.PI / 180 * (355.4532 + 890666.0719 * T));
        L01 += 0.04469 * System.Math.Sin(System.Math.PI / 180 * (62.6015 + -368298.4698 * T));
        L01 += 0.04364 * System.Math.Sin(System.Math.PI / 180 * (220.4891 + 413467.2043 * T));
        L01 += -0.04264 * System.Math.Sin(System.Math.PI / 180 * (306.5588 + -454680.4248 * T));
        L01 += 0.03985 * System.Math.Sin(System.Math.PI / 180 * (292.3874 + -444234.4005 * T));
        L01 += 0.03881 * System.Math.Sin(System.Math.PI / 180 * (209.3049 + 413315.1692 * T));
        L01 += 0.03878 * System.Math.Sin(System.Math.PI / 180 * (7.8292 + -413355.5416 * T));
        L01 += 0.03776 * System.Math.Sin(System.Math.PI / 180 * (263.7613 + 458372.241 * T));
        L01 += 0.03731 * System.Math.Sin(System.Math.PI / 180 * (287.6929 + -845497.3374 * T));
        L01 += -0.03645 * System.Math.Sin(System.Math.PI / 180 * (340.7607 + -390816.9126 * T));
        L01 += -0.03534 * System.Math.Sin(System.Math.PI / 180 * (216.4919 + 499717.3105 * T));
        L01 += 0.03483 * System.Math.Sin(System.Math.PI / 180 * (109.6971 + -409643.5392 * T));
        L01 += 0.03054 * System.Math.Sin(System.Math.PI / 180 * (202.1901 + 510163.3348 * T));
        L01 += 0.02959 * System.Math.Sin(System.Math.PI / 180 * (260.8658 + 1034.1282 * T));
        L01 += 0.02914 * System.Math.Sin(System.Math.PI / 180 * (317.9851 + 282.5272 * T));
        L01 += 0.02885 * System.Math.Sin(System.Math.PI / 180 * (217.3033 + -375.8005 * T));
        L01 += -0.02756 * System.Math.Sin(System.Math.PI / 180 * (205.7945 + -868015.7802 * T));
        L01 += 0.02678 * System.Math.Sin(System.Math.PI / 180 * (0.7459 + 888600.0868 * T));
        L01 += -0.02644 * System.Math.Sin(System.Math.PI / 180 * (333.0947 + -414304.8389 * T));
        L01 += 0.02549 * System.Math.Sin(System.Math.PI / 180 * (159.3389 + -4562.4516 * T));
        L01 += 0.02503 * System.Math.Sin(System.Math.PI / 180 * (343.8472 + 890514.0368 * T));
        L01 += 0.02501 * System.Math.Sin(System.Math.PI / 180 * (232.4432 + -890554.4092 * T));
        L01 += -0.02475 * System.Math.Sin(System.Math.PI / 180 * (32.354 + -347406.421 * T));
        L01 += 0.02398 * System.Math.Sin(System.Math.PI / 180 * (321.0478 + 3034.9057 * T));
        L01 += -0.02336 * System.Math.Sin(System.Math.PI / 180 * (257.4887 + -824605.2887 * T));
        L01 += 0.02299 * System.Math.Sin(System.Math.PI / 180 * (28.1371 + -4443.4172 * T));
        L01 += -0.02288 * System.Math.Sin(System.Math.PI / 180 * (66.8002 + 503409.1267 * T));
        L01 += -0.0213 * System.Math.Sin(System.Math.PI / 180 * (16.1068 + 476447.2666 * T));
        L01 += 0.02 * System.Math.Sin(System.Math.PI / 180 * (210.3553 + 3691.8162 * T));
        L01 += -0.01906 * System.Math.Sin(System.Math.PI / 180 * (8.0621 + 956463.1574 * T));
        L01 += 0.01896 * System.Math.Sin(System.Math.PI / 180 * (299.7687 + 477158.11 * T));
        L01 += 0.01896 * System.Math.Sin(System.Math.PI / 180 * (29.8392 + -477239.6253 * T));
        L01 += -0.01864 * System.Math.Sin(System.Math.PI / 180 * (4.6743 + 478231.5787 * T));
        L01 += 0.01825 * System.Math.Sin(System.Math.PI / 180 * (249.3451 + -892468.3592 * T));
        L01 += 0.01809 * System.Math.Sin(System.Math.PI / 180 * (352.2098 + 476823.0671 * T));
        L01 += 0.01793 * System.Math.Sin(System.Math.PI / 180 * (225.782 + 411401.2192 * T));
        L01 += 0.01779 * System.Math.Sin(System.Math.PI / 180 * (198.0425 + 474917.6418 * T));
        L01 += -0.01769 * System.Math.Sin(System.Math.PI / 180 * (179.1666 + 345.6927 * T));
        L01 += 0.01756 * System.Math.Sin(System.Math.PI / 180 * (287.94 + -479480.0934 * T));
        L01 += -0.01735 * System.Math.Sin(System.Math.PI / 180 * (355.1425 + 475263.3345 * T));
        L01 += 0.01719 * System.Math.Sin(System.Math.PI / 180 * (233.3895 + -404297.8426 * T));
        L01 += -0.01715 * System.Math.Sin(System.Math.PI / 180 * (85.2157 + -479134.4008 * T));
        L01 += -0.01709 * System.Math.Sin(System.Math.PI / 180 * (46.721 + 964468.5019 * T));
        L01 += -0.01675 * System.Math.Sin(System.Math.PI / 180 * (16.2933 + -468161.3548 * T));
        L01 += -0.01652 * System.Math.Sin(System.Math.PI / 180 * (241.0476 + -751.601 * T));
        L01 += 0.01648 * System.Math.Sin(System.Math.PI / 180 * (100.8137 + 413335.3554 * T));
        L01 += 0.0164 * System.Math.Sin(System.Math.PI / 180 * (108.1981 + -379617.2084 * T));
        L01 += 0.01599 * System.Math.Sin(System.Math.PI / 180 * (293.4239 + -410300.4497 * T));
        L01 += 0.01565 * System.Math.Sin(System.Math.PI / 180 * (28.4618 + -432161.982 * T));
        L01 += -0.01539 * System.Math.Sin(System.Math.PI / 180 * (286.0924 + 486236.3804 * T));
        L01 += 0.01487 * System.Math.Sin(System.Math.PI / 180 * (209.8262 + -954265.8864 * T));
        L01 += 0.01465 * System.Math.Sin(System.Math.PI / 180 * (131.2257 + 416370.2611 * T));
        L01 += 0.01464 * System.Math.Sin(System.Math.PI / 180 * (268.5523 + 723.0292 * T));
        L01 += -0.01435 * System.Math.Sin(System.Math.PI / 180 * (108.3144 + 62894.0287 * T));
        L01 += 0.01419 * System.Math.Sin(System.Math.PI / 180 * (167.4312 + 446299.8226 * T));
        L01 += 0.01409 * System.Math.Sin(System.Math.PI / 180 * (298.1469 + 522235.7533 * T));
        L01 += 0.01399 * System.Math.Sin(System.Math.PI / 180 * (176.6259 + 487271.0312 * T));
        L01 += 0.01395 * System.Math.Sin(System.Math.PI / 180 * (29.6822 + 954529.5841 * T));
        L01 += 0.01378 * System.Math.Sin(System.Math.PI / 180 * (24.3078 + -415269.4916 * T));
        L01 += 0.01318 * System.Math.Sin(System.Math.PI / 180 * (75.8891 + 73935.6758 * T));
        L01 += 0.01296 * System.Math.Sin(System.Math.PI / 180 * (289.7534 + 31436.9212 * T));
        L01 += 0.01295 * System.Math.Sin(System.Math.PI / 180 * (313.943 + -381779.3998 * T));
        L01 += -0.01285 * System.Math.Sin(System.Math.PI / 180 * (326.1242 + 90073.7713 * T));
        L01 += 0.01281 * System.Math.Sin(System.Math.PI / 180 * (332.9457 + -856816.076 * T));
        L01 += 0.01269 * System.Math.Sin(System.Math.PI / 180 * (237.0206 + -383405.7939 * T));
        L01 += -0.01244 * System.Math.Sin(System.Math.PI / 180 * (264.7626 + -13480.93 * T));
        L01 += -0.01206 * System.Math.Sin(System.Math.PI / 180 * (243.6398 + 67555.3285 * T));
        L01 += -0.01189 * System.Math.Sin(System.Math.PI / 180 * (242.202 + 478490.4237 * T));
        L01 += -0.01189 * System.Math.Sin(System.Math.PI / 180 * (308.1364 + -901.405 * T));
        L01 += 0.01171 * System.Math.Sin(System.Math.PI / 180 * (98.2408 + -881496.7102 * T));
        L01 += 0.0117 * System.Math.Sin(System.Math.PI / 180 * (74.6193 + -443480.7206 * T));
        L01 += 0.01124 * System.Math.Sin(System.Math.PI / 180 * (194.3722 + -474163.962 * T));
        L01 += 0.01122 * System.Math.Sin(System.Math.PI / 180 * (102.986 + 480233.7733 * T));
        L01 += 0.01115 * System.Math.Sin(System.Math.PI / 180 * (184.92 + 14577.8477 * T));
        L01 += 0.01096 * System.Math.Sin(System.Math.PI / 180 * (280.2841 + -445642.912 * T));
        L01 += 0.01083 * System.Math.Sin(System.Math.PI / 180 * (50.8219 + 34777.2591 * T));
        L01 += -0.01077 * System.Math.Sin(System.Math.PI / 180 * (68.2574 + -477048.1893 * T));
        L01 += -0.01077 * System.Math.Sin(System.Math.PI / 180 * (107.0457 + -413184.6771 * T));
        L01 += -0.01076 * System.Math.Sin(System.Math.PI / 180 * (338.1832 + 477349.5459 * T));
        L01 += -0.01069 * System.Math.Sin(System.Math.PI / 180 * (308.4809 + 413486.0337 * T));
        L01 += 0.01066 * System.Math.Sin(System.Math.PI / 180 * (86.5529 + 1441668.767 * T));
        L01 += 0.0105 * System.Math.Sin(System.Math.PI / 180 * (197.8017 + -447269.3061 * T));
        L01 += -0.01044 * System.Math.Sin(System.Math.PI / 180 * (148.3767 + 525927.5695 * T));
        L01 += 0.01019 * System.Math.Sin(System.Math.PI / 180 * (178.9306 + -858978.2674 * T));
        L01 += -0.01011 * System.Math.Sin(System.Math.PI / 180 * (250.0891 + -3868.2724 * T));
        L01 += 0.00987 * System.Math.Sin(System.Math.PI / 180 * (38.7138 + 935571.1087 * T));
        L01 += 0.00986 * System.Math.Sin(System.Math.PI / 180 * (172.2981 + 411054.1296 * T));
        L01 += -0.00969 * System.Math.Sin(System.Math.PI / 180 * (247.7974 + 883.4499 * T));
        L01 += 0.00965 * System.Math.Sin(System.Math.PI / 180 * (102.0911 + -860604.6615 * T));
        L01 += 0.00959 * System.Math.Sin(System.Math.PI / 180 * (74.3154 + 422372.8682 * T));
        L01 += 0.00945 * System.Math.Sin(System.Math.PI / 180 * (34.9726 + 952463.5991 * T));
        L01 += -0.00927 * System.Math.Sin(System.Math.PI / 180 * (267.6026 + 543127.802 * T));
        L01 += 0.00921 * System.Math.Sin(System.Math.PI / 180 * (322.413 + 476209.1979 * T));
        L01 += 0.00919 * System.Math.Sin(System.Math.PI / 180 * (153.7856 + -887499.3174 * T));
        L01 += -0.00918 * System.Math.Sin(System.Math.PI / 180 * (47.5953 + 112592.2141 * T));
        L01 += 0.00911 * System.Math.Sin(System.Math.PI / 180 * (215.119 + -956331.8714 * T));
        L01 += 0.00905 * System.Math.Sin(System.Math.PI / 180 * (345.1009 + 510917.0147 * T));
        L01 += -0.00901 * System.Math.Sin(System.Math.PI / 180 * (152.6384 + 119.0344 * T));
        L01 += -0.00899 * System.Math.Sin(System.Math.PI / 180 * (136.7609 + -4311.5684 * T));
        L01 += 0.00887 * System.Math.Sin(System.Math.PI / 180 * (329.7828 + -415616.5812 * T));
        L01 += 0.00882 * System.Math.Sin(System.Math.PI / 180 * (343.6647 + 953428.2517 * T));
        L01 += 0.00864 * System.Math.Sin(System.Math.PI / 180 * (302.2493 + 923498.6902 * T));
        L01 += 0.00864 * System.Math.Sin(System.Math.PI / 180 * (51.4327 + 477180.0382 * T));
        L01 += 0.00859 * System.Math.Sin(System.Math.PI / 180 * (141.5781 + -477217.6971 * T));
        L01 += -0.00842 * System.Math.Sin(System.Math.PI / 180 * (120.1832 + 958089.5515 * T));
        L01 += -0.0082 * System.Math.Sin(System.Math.PI / 180 * (237.7231 + 467409.7538 * T));
        L01 += -0.00812 * System.Math.Sin(System.Math.PI / 180 * (112.1146 + -916.7043 * T));
        L01 += 0.00809 * System.Math.Sin(System.Math.PI / 180 * (190.1237 + 508754.8232 * T));
        L01 += 0.00802 * System.Math.Sin(System.Math.PI / 180 * (108.2246 + 507128.4291 * T));
        L01 += 0.00791 * System.Math.Sin(System.Math.PI / 180 * (256.3206 + 893569.1287 * T));
        L01 += -0.00781 * System.Math.Sin(System.Math.PI / 180 * (306.2968 + 966535.8839 * T));
        L01 += -0.00781 * System.Math.Sin(System.Math.PI / 180 * (293.2084 + -966272.1862 * T));
        L01 += -0.00725 * System.Math.Sin(System.Math.PI / 180 * (127.5416 + 890.4929 * T));
        L01 += 0.00719 * System.Math.Sin(System.Math.PI / 180 * (108.3337 + 18075.0256 * T));
        L01 += 0.00706 * System.Math.Sin(System.Math.PI / 180 * (54.8679 + 1099.3725 * T));
        L01 += 0.00698 * System.Math.Sin(System.Math.PI / 180 * (269.2193 + -3559.9674 * T));
        L01 += 0.00698 * System.Math.Sin(System.Math.PI / 180 * (305.4979 + 888252.9972 * T));
        L01 += -0.00672 * System.Math.Sin(System.Math.PI / 180 * (331.4909 + -890383.5447 * T));
        L01 += -0.00665 * System.Math.Sin(System.Math.PI / 180 * (82.6978 + 890684.9013 * T));
        L01 += 0.00649 * System.Math.Sin(System.Math.PI / 180 * (229.6991 + 1032.7111 * T));
        L01 += 0.00643 * System.Math.Sin(System.Math.PI / 180 * (302.019 + 26894.6558 * T));
        L01 += 0.00639 * System.Math.Sin(System.Math.PI / 180 * (192.1289 + -892815.4488 * T));
        L01 += 0.00639 * System.Math.Sin(System.Math.PI / 180 * (131.2943 + 408891.9382 * T));
        L01 += 0.00638 * System.Math.Sin(System.Math.PI / 180 * (176.4029 + 4594.0955 * T));
        L01 += 0.0063 * System.Math.Sin(System.Math.PI / 180 * (319.7186 + 489928.1967 * T));
        L01 += -0.00629 * System.Math.Sin(System.Math.PI / 180 * (129.1018 + 135110.6569 * T));
        L01 += -0.00611 * System.Math.Sin(System.Math.PI / 180 * (317.2284 + 913052.6659 * T));
        L01 += -0.00603 * System.Math.Sin(System.Math.PI / 180 * (28.2471 + 899571.7358 * T));
        L01 += -0.00602 * System.Math.Sin(System.Math.PI / 180 * (292.7999 + 512228.7569 * T));
        L01 += -0.00588 * System.Math.Sin(System.Math.PI / 180 * (229.8628 + 548446.0123 * T));
        L01 += 0.00562 * System.Math.Sin(System.Math.PI / 180 * (187.4625 + -989.6698 * T));
        L01 += 0.00558 * System.Math.Sin(System.Math.PI / 180 * (265.0368 + 12296.6219 * T));
        L01 += -0.00558 * System.Math.Sin(System.Math.PI / 180 * (162.7825 + 480771.6495 * T));
        L01 += 0.00555 * System.Math.Sin(System.Math.PI / 180 * (109.0887 + -1367601.242 * T));
        L01 += 0.00541 * System.Math.Sin(System.Math.PI / 180 * (130.4185 + 1367864.94 * T));
        L01 += 0.00533 * System.Math.Sin(System.Math.PI / 180 * (288.753 + -417778.7726 * T));
        L01 += -0.00528 * System.Math.Sin(System.Math.PI / 180 * (130.2916 + 1222.1138 * T));
        L01 += -0.0052 * System.Math.Sin(System.Math.PI / 180 * (201.5485 + 482889.8735 * T));
        L01 += -0.00511 * System.Math.Sin(System.Math.PI / 180 * (232.3856 + -827640.1943 * T));
        L01 += 0.00505 * System.Math.Sin(System.Math.PI / 180 * (74.2115 + 443264.9169 * T));
        L01 += -0.00504 * System.Math.Sin(System.Math.PI / 180 * (7.4393 + -350441.3267 * T));
        L01 += -0.00503 * System.Math.Sin(System.Math.PI / 180 * (40.4796 + 2658.5624 * T));
        L01 += -0.00502 * System.Math.Sin(System.Math.PI / 180 * (176.6101 + -55.3705 * T));
        L01 += 0.00492 * System.Math.Sin(System.Math.PI / 180 * (292.204 + 472636.416 * T));
        L01 += 0.00476 * System.Math.Sin(System.Math.PI / 180 * (22.0617 + -481761.3192 * T));
        L01 += -0.00475 * System.Math.Sin(System.Math.PI / 180 * (358.0099 + 413335.7406 * T));
        L01 += -0.00475 * System.Math.Sin(System.Math.PI / 180 * (156.5359 + -413334.9702 * T));
        L01 += -0.00472 * System.Math.Sin(System.Math.PI / 180 * (15.8504 + 35999.3729 * T));
        L01 += 0.00471 * System.Math.Sin(System.Math.PI / 180 * (344.4315 + 35958.6152 * T));
        L01 += 0.00467 * System.Math.Sin(System.Math.PI / 180 * (107.1891 + 1291.5561 * T));
        L01 += 0.00465 * System.Math.Sin(System.Math.PI / 180 * (240.1422 + -6843.6774 * T));
        L01 += -0.00457 * System.Math.Sin(System.Math.PI / 180 * (15.2599 + -821570.383 * T));
        L01 += 0.00441 * System.Math.Sin(System.Math.PI / 180 * (76.7419 + 68963.84 * T));
        L01 += 0.0044 * System.Math.Sin(System.Math.PI / 180 * (235.8003 + 890534.223 * T));
        L01 += -0.0043 * System.Math.Sin(System.Math.PI / 180 * (210.5793 + 157629.0998 * T));
        L01 += -0.00427 * System.Math.Sin(System.Math.PI / 180 * (150.6765 + -344371.5154 * T));
        L01 += 0.00417 * System.Math.Sin(System.Math.PI / 180 * (11.6614 + -822978.8946 * T));
        L01 += 0.00416 * System.Math.Sin(System.Math.PI / 180 * (157.2343 + 472755.4504 * T));
        L01 += -0.00414 * System.Math.Sin(System.Math.PI / 180 * (298.5012 + -968338.1712 * T));
        L01 += 0.00413 * System.Math.Sin(System.Math.PI / 180 * (146.469 + -345780.0269 * T));
        L01 += -0.00408 * System.Math.Sin(System.Math.PI / 180 * (65.9504 + 507.6494 * T));
        L01 += 0.00405 * System.Math.Sin(System.Math.PI / 180 * (264.2128 + 58517.8157 * T));
        L01 += 0.00404 * System.Math.Sin(System.Math.PI / 180 * (57.4162 + -1334768.624 * T));
        L01 += -0.00404 * System.Math.Sin(System.Math.PI / 180 * (317.7457 + 50577.2206 * T));
        L01 += 0.004 * System.Math.Sin(System.Math.PI / 180 * (140.3136 + -414086.9564 * T));
        L01 += 0.00398 * System.Math.Sin(System.Math.PI / 180 * (222.2885 + -888468.8009 * T));
        L01 += 0.00398 * System.Math.Sin(System.Math.PI / 180 * (187.605 + -381898.4342 * T));
        L01 += 0.00396 * System.Math.Sin(System.Math.PI / 180 * (93.8066 + -494.8349 * T));
        L01 += 0.00396 * System.Math.Sin(System.Math.PI / 180 * (265.8063 + 886090.8058 * T));
        L01 += 0.00395 * System.Math.Sin(System.Math.PI / 180 * (246.7109 + -481642.2849 * T));
        L01 += 0.00392 * System.Math.Sin(System.Math.PI / 180 * (10.4835 + 29155.6954 * T));
        L01 += -0.00391 * System.Math.Sin(System.Math.PI / 180 * (277.6611 + 413294.5978 * T));
        L01 += -0.00389 * System.Math.Sin(System.Math.PI / 180 * (76.2913 + -413376.113 * T));
        L01 += -0.00374 * System.Math.Sin(System.Math.PI / 180 * (104.8851 + -809497.9645 * T));
        L01 += 0.00365 * System.Math.Sin(System.Math.PI / 180 * (311.2549 + 447053.5024 * T));
        L01 += 0.00364 * System.Math.Sin(System.Math.PI / 180 * (184.0244 + 473194.4784 * T));
        L01 += 0.00361 * System.Math.Sin(System.Math.PI / 180 * (214.5674 + 482299.1954 * T));
        L01 += -0.00359 * System.Math.Sin(System.Math.PI / 180 * (182.1301 + 435853.7982 * T));
        L01 += -0.00358 * System.Math.Sin(System.Math.PI / 180 * (311.382 + 570964.4552 * T));
        L01 += 0.00357 * System.Math.Sin(System.Math.PI / 180 * (263.348 + 408772.9038 * T));
        L01 += -0.00347 * System.Math.Sin(System.Math.PI / 180 * (284.2064 + 658.3277 * T));
        L01 += 0.00343 * System.Math.Sin(System.Math.PI / 180 * (135.7094 + 1365798.955 * T));
        L01 += -0.00341 * System.Math.Sin(System.Math.PI / 180 * (333.8327 + 892599.6452 * T));
        L01 += -0.00338 * System.Math.Sin(System.Math.PI / 180 * (19.3837 + 467785.5543 * T));
        L01 += 0.00336 * System.Math.Sin(System.Math.PI / 180 * (310.3369 + -378558.0963 * T));
        L01 += -0.00334 * System.Math.Sin(System.Math.PI / 180 * (239.8963 + -332299.0969 * T));
        L01 += -0.00334 * System.Math.Sin(System.Math.PI / 180 * (148.1926 + 478985.2586 * T));
        L01 += -0.00333 * System.Math.Sin(System.Math.PI / 180 * (116.5731 + -413711.1559 * T));
        L01 += -0.00329 * System.Math.Sin(System.Math.PI / 180 * (156.8717 + -8005.3445 * T));
        L01 += 0.00323 * System.Math.Sin(System.Math.PI / 180 * (16.3707 + 954377.5491 * T));
        L01 += 0.00323 * System.Math.Sin(System.Math.PI / 180 * (196.5165 + -954417.9215 * T));
        L01 += 0.00317 * System.Math.Sin(System.Math.PI / 180 * (241.5814 + -854403.0013 * T));
        L01 += -0.00316 * System.Math.Sin(System.Math.PI / 180 * (177.8587 + 854666.699 * T));
        L01 += 0.00313 * System.Math.Sin(System.Math.PI / 180 * (228.7494 + 476704.0328 * T));
        L01 += -0.00313 * System.Math.Sin(System.Math.PI / 180 * (115.0271 + 252.6303 * T));
        L01 += 0.00311 * System.Math.Sin(System.Math.PI / 180 * (110.7851 + -36019.5591 * T));
        L01 += 0.00311 * System.Math.Sin(System.Math.PI / 180 * (152.8097 + -1322696.205 * T));
        L01 += 0.00305 * System.Math.Sin(System.Math.PI / 180 * (345.2793 + 10015.3961 * T));
        L01 += 0.00305 * System.Math.Sin(System.Math.PI / 180 * (52.2577 + -859097.3018 * T));
        L01 += 0.00304 * System.Math.Sin(System.Math.PI / 180 * (285.8675 + 33555.1453 * T));
        L01 += -0.00304 * System.Math.Sin(System.Math.PI / 180 * (44.2281 + -476853.175 * T));
        L01 += -0.00303 * System.Math.Sin(System.Math.PI / 180 * (289.2042 + 35979.1866 * T));
        L01 += -0.00303 * System.Math.Sin(System.Math.PI / 180 * (314.1579 + 477544.5603 * T));
        L01 += 0.00301 * System.Math.Sin(System.Math.PI / 180 * (84.82 + -398757.5077 * T));
        L01 += -0.00297 * System.Math.Sin(System.Math.PI / 180 * (292.0729 + 180147.5426 * T));
        L01 += 0.00297 * System.Math.Sin(System.Math.PI / 180 * (151.911 + -894977.6403 * T));
        L01 += 0.00292 * System.Math.Sin(System.Math.PI / 180 * (105.9171 + 16859.0735 * T));
        L01 += -0.00288 * System.Math.Sin(System.Math.PI / 180 * (108.7936 + 1369798.513 * T));
        L01 += 0.00284 * System.Math.Sin(System.Math.PI / 180 * (61.0203 + -417897.807 * T));
        L01 += -0.00283 * System.Math.Sin(System.Math.PI / 180 * (171.5956 + -931879.2924 * T));
        L01 += -0.00283 * System.Math.Sin(System.Math.PI / 180 * (346.5619 + -619.7521 * T));

        double L02 = 0;
        L02 += 0.46578 * System.Math.Sin(System.Math.PI / 180 * (357.529 + 35999.05 * T));
        L02 += -0.14345 * System.Math.Sin(System.Math.PI / 180 * (103.208 + 377336.305 * T));
        L02 += -0.11495 * System.Math.Sin(System.Math.PI / 180 * (238.171 + 854535.173 * T));
        L02 += 0.1031 * System.Math.Sin(System.Math.PI / 180 * (222.566 + -441199.817 * T));
        L02 += 0.07656 * System.Math.Sin(System.Math.PI / 180 * (132.493 + 513197.918 * T));
        L02 += -0.07062 * System.Math.Sin(System.Math.PI / 180 * (27.775 + 131.849 * T));
        L02 += 0.01977 * System.Math.Sin(System.Math.PI / 180 * (98.266 + 449334.406 * T));
        L02 += 0.01702 * System.Math.Sin(System.Math.PI / 180 * (233.23 + 926533.273 * T));
        L02 += -0.01254 * System.Math.Sin(System.Math.PI / 180 * (295.379 + 481266.162 * T));
        L02 += -0.01124 * System.Math.Sin(System.Math.PI / 180 * (240.642 + 818536.122 * T));
        L02 += 0.01041 * System.Math.Sin(System.Math.PI / 180 * (355.058 + 71998.101 * T));
        L02 += -0.0103 * System.Math.Sin(System.Math.PI / 180 * (105.679 + 341337.255 * T));
        L02 += -0.01014 * System.Math.Sin(System.Math.PI / 180 * (13.135 + 1331734.04 * T));
        L02 += 0.00677 * System.Math.Sin(System.Math.PI / 180 * (87.602 + -918398.685 * T));
        L02 += -0.00601 * System.Math.Sin(System.Math.PI / 180 * (328.244 + -99862.563 * T));
        L02 += 0.00534 * System.Math.Sin(System.Math.PI / 180 * (267.456 + 990396.786 * T));
        L02 += 0.00401 * System.Math.Sin(System.Math.PI / 180 * (4.098 + -18.829 * T));
        L02 += -0.00392 * System.Math.Sin(System.Math.PI / 180 * (252.8 + -477067.019 * T));
        L02 += -0.00368 * System.Math.Sin(System.Math.PI / 180 * (162.969 + 477330.716 * T));
        L02 += 0.00359 * System.Math.Sin(System.Math.PI / 180 * (220.095 + -405200.767 * T));
        L02 += 0.00353 * System.Math.Sin(System.Math.PI / 180 * (95.795 + 485333.456 * T));
        L02 += -0.00305 * System.Math.Sin(System.Math.PI / 180 * (338.908 + 1267870.528 * T));
        L02 += 0.00298 * System.Math.Sin(System.Math.PI / 180 * (235.7 + 890534.223 * T));
        L02 += 0.00293 * System.Math.Sin(System.Math.PI / 180 * (183.729 + -20.186 * T));
        L02 += 0.00233 * System.Math.Sin(System.Math.PI / 180 * (100.737 + 413335.355 * T));
        L02 += 0.00204 * System.Math.Sin(System.Math.PI / 180 * (8.193 + 1403732.141 * T));
        L02 += -0.00191 * System.Math.Sin(System.Math.PI / 180 * (203.945 + 790671.661 * T));
        L02 += -0.00175 * System.Math.Sin(System.Math.PI / 180 * (323.303 + -27864.462 * T));
        L02 += 0.00163 * System.Math.Sin(System.Math.PI / 180 * (130.022 + 549196.968 * T));
        L02 += -0.0015 * System.Math.Sin(System.Math.PI / 180 * (51.627 + -111868.862 * T));
        L02 += -0.0013 * System.Math.Sin(System.Math.PI / 180 * (113.872 + 1745069.396 * T));
        L02 += -0.00105 * System.Math.Sin(System.Math.PI / 180 * (15.606 + 1295734.99 * T));
        L02 += 0.00101 * System.Math.Sin(System.Math.PI / 180 * (46.685 + -39870.762 * T));
        L02 += 0.00098 * System.Math.Sin(System.Math.PI / 180 * (80.028 + 9037.513 * T));
        L02 += -0.00089 * System.Math.Sin(System.Math.PI / 180 * (63.057 + 150.678 * T));
        L02 += -0.00088 * System.Math.Sin(System.Math.PI / 180 * (70.343 + 958465.029 * T));
        L02 += -0.00083 * System.Math.Sin(System.Math.PI / 180 * (125.045 + -1934.136 * T));
        L02 += -0.00083 * System.Math.Sin(System.Math.PI / 180 * (287.032 + -413203.507 * T));
        L02 += -0.00082 * System.Math.Sin(System.Math.PI / 180 * (148.098 + 1808932.908 * T));
        L02 += 0.00081 * System.Math.Sin(System.Math.PI / 180 * (254.014 + -40.758 * T));
        L02 += -0.00081 * System.Math.Sin(System.Math.PI / 180 * (152.061 + -890402.374 * T));
        L02 += -0.00081 * System.Math.Sin(System.Math.PI / 180 * (263.49 + 890666.072 * T));
        L02 += -0.00078 * System.Math.Sin(System.Math.PI / 180 * (128.524 + 413467.204 * T));
        L02 += -0.00075 * System.Math.Sin(System.Math.PI / 180 * (160.416 + 4067.294 * T));
        L02 += -0.00071 * System.Math.Sin(System.Math.PI / 180 * (243.113 + 782537.072 * T));
        L02 += -0.00069 * System.Math.Sin(System.Math.PI / 180 * (319.858 + -1935.533 * T));
        L02 += 0.00068 * System.Math.Sin(System.Math.PI / 180 * (257.953 + 476229.384 * T));
        L02 += 0.00065 * System.Math.Sin(System.Math.PI / 180 * (167.245 + -2281.226 * T));
        L02 += 0.00056 * System.Math.Sin(System.Math.PI / 180 * (47.818 + -477219.054 * T));
        L02 += 0.00056 * System.Math.Sin(System.Math.PI / 180 * (317.745 + 477178.681 * T));
        L02 += -0.00052 * System.Math.Sin(System.Math.PI / 180 * (108.15 + 305338.205 * T));
        L02 += 0.00047 * System.Math.Sin(System.Math.PI / 180 * (312.639 + -1395597.553 * T));
        L02 += 0.00047 * System.Math.Sin(System.Math.PI / 180 * (284.319 + 413315.169 * T));
        L02 += 0.00046 * System.Math.Sin(System.Math.PI / 180 * (82.844 + -413355.542 * T));
        L02 += 0.00044 * System.Math.Sin(System.Math.PI / 180 * (333.967 + 1339868.629 * T));
        L02 += 0.00044 * System.Math.Sin(System.Math.PI / 180 * (162.159 + 31555.956 * T));
        L02 += 0.00044 * System.Math.Sin(System.Math.PI / 180 * (122.967 + -969.484 * T));
        L02 += -0.00043 * System.Math.Sin(System.Math.PI / 180 * (341.379 + 1231871.478 * T));
        L02 += 0.00043 * System.Math.Sin(System.Math.PI / 180 * (134.963 + 477198.868 * T));
        L02 += -0.00041 * System.Math.Sin(System.Math.PI / 180 * (330.715 + -135861.613 * T));
        L02 += 0.0004 * System.Math.Sin(System.Math.PI / 180 * (247.088 + -4562.452 * T));
        L02 += -0.0004 * System.Math.Sin(System.Math.PI / 180 * (213.092 + 890.493 * T));
        L02 += 0.00039 * System.Math.Sin(System.Math.PI / 180 * (300.321 + 409268.061 * T));
        L02 += 0.00038 * System.Math.Sin(System.Math.PI / 180 * (42.419 + 1467595.653 * T));
        L02 += 0.00036 * System.Math.Sin(System.Math.PI / 180 * (32.981 + 477158.11 * T));
        L02 += 0.00036 * System.Math.Sin(System.Math.PI / 180 * (123.055 + -477239.625 * T));
        L02 += 0.00036 * System.Math.Sin(System.Math.PI / 180 * (10.664 + 1367733.091 * T));
        L02 += 0.00035 * System.Math.Sin(System.Math.PI / 180 * (320.832 + 8134.588 * T));
        L02 += 0.00034 * System.Math.Sin(System.Math.PI / 180 * (160.404 + 883.45 * T));
        L02 += -0.00033 * System.Math.Sin(System.Math.PI / 180 * (193.281 + -577061.43 * T));
        L02 += 0.00033 * System.Math.Sin(System.Math.PI / 180 * (7.248 + 1034.128 * T));
        L02 += 0.0003 * System.Math.Sin(System.Math.PI / 180 * (74.973 + 29929.562 * T));
        L02 += 0.0003 * System.Math.Sin(System.Math.PI / 180 * (59.126 + 890514.037 * T));
        L02 += 0.0003 * System.Math.Sin(System.Math.PI / 180 * (289.752 + 1343740.34 * T));
        L02 += 0.0003 * System.Math.Sin(System.Math.PI / 180 * (307.724 + -890554.409 * T));
        L02 += -0.00029 * System.Math.Sin(System.Math.PI / 180 * (184.073 + 1002403.085 * T));
        L02 += 0.00027 * System.Math.Sin(System.Math.PI / 180 * (85.131 + -882399.635 * T));
        L02 += 0.00027 * System.Math.Sin(System.Math.PI / 180 * (64.715 + 1820939.208 * T));
        L02 += -0.00027 * System.Math.Sin(System.Math.PI / 180 * (117.837 + -954265.886 * T));
        L02 += 0.00026 * System.Math.Sin(System.Math.PI / 180 * (230.759 + 962532.324 * T));
        L02 += 0.00026 * System.Math.Sin(System.Math.PI / 180 * (186.591 + 365330.005 * T));
        L02 += 0.00025 * System.Math.Sin(System.Math.PI / 180 * (199.003 + 862669.761 * T));
        L02 += -0.00025 * System.Math.Sin(System.Math.PI / 180 * (297.932 + 954529.584 * T));
        L02 += -0.00024 * System.Math.Sin(System.Math.PI / 180 * (25.452 + -473131.573 * T));
        L02 += -0.00022 * System.Math.Sin(System.Math.PI / 180 * (206.416 + 754672.61 * T));
        L02 += 0.00022 * System.Math.Sin(System.Math.PI / 180 * (228.08 + -477217.697 * T));
        L02 += -0.00022 * System.Math.Sin(System.Math.PI / 180 * (301.381 + 282.527 * T));
        L02 += -0.00021 * System.Math.Sin(System.Math.PI / 180 * (36.021 + -1407603.852 * T));
        L02 += -0.00021 * System.Math.Sin(System.Math.PI / 180 * (116.343 + 1709070.345 * T));
        L02 += 0.00021 * System.Math.Sin(System.Math.PI / 180 * (352.587 + 107997.151 * T));
        L02 += 0.0002 * System.Math.Sin(System.Math.PI / 180 * (108.93 + 1817067.496 * T));
        L02 += 0.0002 * System.Math.Sin(System.Math.PI / 180 * (143.156 + 1880931.009 * T));
        L02 += -0.0002 * System.Math.Sin(System.Math.PI / 180 * (248.835 + 2222268.263 * T));
        L02 += 0.0002 * System.Math.Sin(System.Math.PI / 180 * (231.465 + -901.405 * T));
        L02 += -0.00019 * System.Math.Sin(System.Math.PI / 180 * (36.116 + 894601.517 * T));
        L02 += -0.00018 * System.Math.Sin(System.Math.PI / 180 * (319.037 + 1479601.953 * T));
        L02 += 0.00018 * System.Math.Sin(System.Math.PI / 180 * (138.579 + 477180.038 * T));
        L02 += 0.00018 * System.Math.Sin(System.Math.PI / 180 * (8.6 + 3034.906 * T));
        L02 += 0.00017 * System.Math.Sin(System.Math.PI / 180 * (306.673 + -468161.355 * T));
        L02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (287.969 + 474917.642 * T));
        L02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (41.058 + 822603.417 * T));
        L02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (321.163 + -375.801 * T));
        L02 += -0.00016 * System.Math.Sin(System.Math.PI / 180 * (44.565 + -99.177 * T));
        L02 += 0.00016 * System.Math.Sin(System.Math.PI / 180 * (17.745 + -479480.093 * T));
        L02 += 0.00015 * System.Math.Sin(System.Math.PI / 180 * (9.166 + 477349.546 * T));
        L02 += 0.00015 * System.Math.Sin(System.Math.PI / 180 * (99.182 + -477048.189 * T));
        L02 += -0.00015 * System.Math.Sin(System.Math.PI / 180 * (184.894 + -479134.401 * T));
        L02 += -0.00015 * System.Math.Sin(System.Math.PI / 180 * (94.821 + 475263.334 * T));
        L02 += 0.00015 * System.Math.Sin(System.Math.PI / 180 * (64.7 + 476209.198 * T));
        L02 += -0.00014 * System.Math.Sin(System.Math.PI / 180 * (146.402 + 964468.502 * T));
        L02 += -0.00014 * System.Math.Sin(System.Math.PI / 180 * (171.225 + -3559.967 * T));
        L02 += -0.00014 * System.Math.Sin(System.Math.PI / 180 * (22.598 + -414304.839 * T));
        L02 += 0.00014 * System.Math.Sin(System.Math.PI / 180 * (332.651 + -404297.843 * T));
        L02 += 0.00014 * System.Math.Sin(System.Math.PI / 180 * (214.319 + 966535.884 * T));
        L02 += 0.00014 * System.Math.Sin(System.Math.PI / 180 * (201.231 + -966272.186 * T));
        L02 += 0.00014 * System.Math.Sin(System.Math.PI / 180 * (45.575 + 476447.267 * T));
        L02 += 0.00014 * System.Math.Sin(System.Math.PI / 180 * (217.293 + 486236.38 * T));
        L02 += -0.00014 * System.Math.Sin(System.Math.PI / 180 * (166.528 + 413486.034 * T));
        L02 += -0.00014 * System.Math.Sin(System.Math.PI / 180 * (32.74 + -4443.417 * T));
        L02 += -0.00013 * System.Math.Sin(System.Math.PI / 180 * (325.703 + -413184.677 * T));
        L02 += -0.00013 * System.Math.Sin(System.Math.PI / 180 * (188.339 + -505063.33 * T));
        L02 += 0.00013 * System.Math.Sin(System.Math.PI / 180 * (326.794 + -6843.677 * T));
        L02 += 0.00012 * System.Math.Sin(System.Math.PI / 180 * (12.627 + 723.029 * T));
        L02 += 0.00012 * System.Math.Sin(System.Math.PI / 180 * (253.402 + -751.601 * T));
        L02 += 0.00011 * System.Math.Sin(System.Math.PI / 180 * (336.437 + 1303869.578 * T));
        L02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (336.935 + 478490.424 * T));
        L02 += 0.00011 * System.Math.Sin(System.Math.PI / 180 * (217.624 + -369201.717 * T));
        L02 += -0.00011 * System.Math.Sin(System.Math.PI / 180 * (171.08 + 1371800.385 * T));
        L02 += 0.00011 * System.Math.Sin(System.Math.PI / 180 * (22.925 + -445642.912 * T));
        L02 += 0.00011 * System.Math.Sin(System.Math.PI / 180 * (93.089 + 476823.067 * T));
        L02 += -0.0001 * System.Math.Sin(System.Math.PI / 180 * (261.243 + 35958.615 * T));
        L02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (335.121 + -383405.794 * T));
        L02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (269.927 + 954397.735 * T));
        L02 += -0.0001 * System.Math.Sin(System.Math.PI / 180 * (17.111 + -1367601.242 * T));
        L02 += -0.0001 * System.Math.Sin(System.Math.PI / 180 * (38.439 + 1367864.94 * T));
        L02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (303.404 + -858978.267 * T));
        L02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (268.33 + 411054.13 * T));
        L02 += 0.0001 * System.Math.Sin(System.Math.PI / 180 * (240.825 + -410300.45 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (165.358 + -67930.806 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (280.672 + -989.67 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (180.064 + 422372.868 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (264.985 + 1026395.836 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (316.645 + 3171.719 * T));
        L02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (54.098 + -147867.913 * T));
        L02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (150.569 + 1772933.858 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (195.62 + 413294.598 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (354.297 + -413376.113 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (82.788 + 416370.261 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (210.356 + -881496.71 * T));
        L02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (325.774 + -63863.512 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (43.697 + -381779.4 * T));
        L02 += 0.00009 * System.Math.Sin(System.Math.PI / 180 * (276.828 + 14577.848 * T));
        L02 += -0.00009 * System.Math.Sin(System.Math.PI / 180 * (298.459 + 890684.901 * T));
        L02 += 0.00008 * System.Math.Sin(System.Math.PI / 180 * (75.285 + 886466.929 * T));


        double L03 = 0;
        L03 += 13.53 * System.Math.Sin(System.Math.PI / 180 * (357.5 + 35999.1 * T));
        L03 += -4.17 * System.Math.Sin(System.Math.PI / 180 * (103.2 + 377336.3 * T));
        L03 += -3.33 * System.Math.Sin(System.Math.PI / 180 * (238.2 + 854535.2 * T));
        L03 += 3 * System.Math.Sin(System.Math.PI / 180 * (222.6 + -441199.8 * T));
        L03 += 2.22 * System.Math.Sin(System.Math.PI / 180 * (132.5 + 513197.9 * T));
        L03 += 0.58 * System.Math.Sin(System.Math.PI / 180 * (98.3 + 449334.4 * T));
        L03 += 0.5 * System.Math.Sin(System.Math.PI / 180 * (233.2 + 926533.3 * T));
        L03 += -0.36 * System.Math.Sin(System.Math.PI / 180 * (295.4 + 481266.2 * T));
        L03 += -0.33 * System.Math.Sin(System.Math.PI / 180 * (240.6 + 818536.1 * T));
        L03 += -0.31 * System.Math.Sin(System.Math.PI / 180 * (13.1 + 1331734 * T));
        L03 += -0.31 * System.Math.Sin(System.Math.PI / 180 * (105.7 + 341337.3 * T));
        L03 += 0.31 * System.Math.Sin(System.Math.PI / 180 * (355.1 + 71998.1 * T));
        L03 += 0.19 * System.Math.Sin(System.Math.PI / 180 * (87.6 + -918398.7 * T));
        L03 += -0.17 * System.Math.Sin(System.Math.PI / 180 * (328.2 + -99862.6 * T));
        L03 += 0.17 * System.Math.Sin(System.Math.PI / 180 * (267.5 + 990396.8 * T));
        L03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (95.8 + 485333.5 * T));
        L03 += 0.11 * System.Math.Sin(System.Math.PI / 180 * (220.1 + -405200.8 * T));
        L03 += -0.08 * System.Math.Sin(System.Math.PI / 180 * (338.9 + 1267870.5 * T));
        L03 += 0.08 * System.Math.Sin(System.Math.PI / 180 * (235.7 + 890534.2 * T));
        L03 += -0.06 * System.Math.Sin(System.Math.PI / 180 * (203.9 + 790671.7 * T));
        L03 += -0.06 * System.Math.Sin(System.Math.PI / 180 * (323.3 + -27864.5 * T));
        L03 += -0.06 * System.Math.Sin(System.Math.PI / 180 * (51.6 + -111868.9 * T));
        L03 += 0.06 * System.Math.Sin(System.Math.PI / 180 * (8.2 + 1403732.1 * T));
        L03 += 0.06 * System.Math.Sin(System.Math.PI / 180 * (100.7 + 413335.4 * T));
        L03 += 0.06 * System.Math.Sin(System.Math.PI / 180 * (130 + 549197 * T));

        double lamdaB = L1 + L + 0.001 * (L01 + L02 * T + 0.0001 * L03 * T * T);


        return lamdaB;
    }

}
