﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Jadwal_salat : MonoBehaviour
{
    //memanggil class algoJeanmeeus
    private Algo_JeanMeeus jMeeus;

    //variable Time zone
    [Obsolete]
    TimeZone localzone;

    //variable koordinat
    double lt, bt;

    //variable text gameobject
    public Text t_tanggal, t_latitude, t_longitude;

    public Text t_dhuhur, t_ashar, t_magrib, t_isya, t_imsak, t_subuh, t_terbit, t_dhuha, t_rskiblat;

    //Variable String data Matahari
    private string s_tanggal, s_latitude, s_longitude;




    // Start is called before the first frame update
    [Obsolete]
    void Start()
    {
        // memanggil Class  Algo JeanMeeus
        jMeeus = gameObject.AddComponent<Algo_JeanMeeus>();

        // mendapatkan nilai koordinat tempat
        lt = StateNameController.stc_latitude;
        bt = StateNameController.stc_longitude;

        // set Text koordinat

        s_latitude = "Lintang Tempat : " + kederajat(lt);
        t_latitude.text = s_latitude;

        s_longitude = "Bujur Tempat : " + kederajat(bt);
        t_longitude.text = s_longitude;

        // mendapatkan nilai waktu
        DateTime sekarang = DateTime.Now;
        s_tanggal = sekarang.ToString("dddd, dd MMMM yyyy") ;
        // set Text waktu
        t_tanggal.text = s_tanggal;

        // get Date Now
        int tahun = DateTime.Now.Year;
        int bulan = DateTime.Now.Month;
        int tgl = DateTime.Now.Day;
        // get Time Now
        double jam = DateTime.Now.Hour;
        double mnt = DateTime.Now.Minute;
        //get TimeZone 
        localzone = TimeZone.CurrentTimeZone;
        DateTime currentDate = DateTime.Now;
        TimeSpan currentOffset = localzone.GetUtcOffset(currentDate);
        double tz = currentOffset.Hours;


        //mendapatkan nilai equation of time dan deklinasi matahari jam 12 siang
        //equation of time
        double equationOT = (jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, 12, 0, tz)[16]) / 60;
        double app_dec = jMeeus.Data_Algo_JeanMeeus(tahun, bulan, tgl, 12, 0, tz)[12];


        //mendapatkan JADWAL SHOLAT
        t_dhuhur.text = w_dhuhur(lt, bt, app_dec, equationOT, tz);
        t_ashar.text = w_ashar(lt, bt, app_dec, equationOT, tz);
        t_magrib.text = w_magrib(lt,bt,50,app_dec,equationOT,tz);
        t_isya.text = w_isya(lt, bt, 50, app_dec, equationOT, tz);
        t_imsak.text = w_imsak(lt, bt, 50, app_dec, equationOT, tz);
        t_subuh.text = w_shubuh(lt, bt, 50, app_dec, equationOT, tz);
        t_terbit.text = w_terbit(lt, bt, 50, app_dec, equationOT, tz);
        t_dhuha.text = w_duha(lt, bt, app_dec, equationOT, tz);
        t_rskiblat.text = rsQiblat(lt, bt, app_dec, equationOT, tz);
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    //fungsi perhitungan waktu dhuhur
    public String w_dhuhur(double lt, double bt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;

        //menghitung waktu dhuhur
        double dhuhur_WH = 12;
        double dhuhur_ws;
        dhuhur_ws = dhuhur_WH - eot + (BD - bt) / 15;

        // tambah ihtiyat 2 menit
        double dhuhur = dhuhur_ws + (0.0333333334);

        //merubah jadi bentuk jam
        String jam_dhuhur = bderajat_jam(dhuhur);

        return jam_dhuhur;
    }

    //fungsi perhitungan waktu ashar
    public String w_ashar(double lt, double bt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;

        // jarak zenit matahari
        double zm = deklinasi - lt;

        //ha ashar (tinggi matahari saat ashar)
        double tanzm = Math.Tan(Math.Abs(zm) * Math.PI / 180);
        double ha_ashar = (Math.Atan(1 / (tanzm + 1)))*(180/Math.PI);

        //to sudut waktu matahari ketika asahar
        double sinha = Math.Sin(ha_ashar * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru ashar
        double to_ashar = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //ashar + waktu hakiki
        double ashar_ws = (12 + Math.Abs(to_ashar)) - eot + (BD - bt) / 15;

        //awal waktu asar + ihtiyat 2 menit
        double waktu_ashar = ashar_ws + (0.0333333334);

        //merubah menjadi bentuk jam
        String jam_asahr = bderajat_jam(waktu_ashar);

        return jam_asahr;
    }

    //fungsi perhitungan waktu maghrib
    public String w_magrib(double lt, double bt, double alt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;


        //ha maghrib (tinggi matahari saat magrib)
        double DIP = 0.029333333334 * Math.Sqrt(alt);
        double refraction = 0.566666666667;
        double sd = 0.266666666667;
        double ha_maghrib = (DIP + refraction +sd) * -1;

        //to sudut waktu matahari ketika maghrib
        double sinha = Math.Sin(ha_maghrib * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180); 
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru maghrib
        double to_maghrib = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //ashar + waktu hakiki
        double maghrib_ws = (12 + Math.Abs(to_maghrib)) - eot + (BD - bt) / 15;

        //awal waktu asar + ihtiyat 2 menit
        double waktu_maghrib = maghrib_ws + (0.0333333334);

        //merubah menjadi bentuk jam
        String jam_maghrib = bderajat_jam(waktu_maghrib);

        return jam_maghrib;
    }

    //fungsi perhitungan waktu isya
    public String w_isya(double lt, double bt, double alt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;

        //ha maghrib (tinggi matahari saat magrib)
        double DIP = 0.029333333334 * Math.Sqrt(alt);
        double refraction= 0.566666666667;
        double sd = 0.266666666667;
        double ha_maghrib = (DIP + refraction +sd) * -1;

        //ha isya (tinggi matahari saat isya)
        double ha_isya = (-17) + (ha_maghrib);

        //to sudut waktu matahari ketika isya
        double sinha = Math.Sin(ha_isya * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru isya
        double to_isya = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //isya + waktu hakiki
        double isya_ws = (12 + Math.Abs(to_isya)) - eot + (BD - bt) / 15;

        //awal waktu asar + ihtiyat 2 menit
        double waktu_isya = isya_ws + (0.0333333334);

        //merubah menjadi bentuk jam
        String jam_isya = bderajat_jam(waktu_isya);

        return jam_isya;
    }

    //fungsi perhitungan waktu Shubuh
    public String w_shubuh(double lt, double bt, double alt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;

        //ha maghrib (tinggi matahari saat magrib)
        double DIP = 0.029333333334 * Math.Sqrt(alt);
        double refraction= 0.566666666667;
        double sd = 0.266666666667;
        double ha_maghrib = (DIP + refraction +sd) * -1;

        //ha shubuh (tinggi matahari saat shubuh)
        double ha_shubuh = (-19) + (ha_maghrib);

        //to sudut waktu matahari ketika subuh
        double sinha = Math.Sin(ha_shubuh * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru shubuh
        double to_shubuh = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //shubuh + waktu hakiki
        double shubuh_ws = (12 - Math.Abs(to_shubuh)) - eot + (BD - bt) / 15;

        //awal waktu shubuh + ihtiyat 2 menit
        double waktu_shubuh = (shubuh_ws + (0.0333333334));

        //merubah menjadi bentuk jam
        String jam_shubuh = bderajat_jam(waktu_shubuh);

        return jam_shubuh;
    }

    //fungsi perhitungan waktu imsak
    public String w_imsak(double lt, double bt, double alt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;

        //ha maghrib (tinggi matahari saat magrib)
        double DIP = 0.029333333334 * Math.Sqrt(alt);
        double refraction= 0.566666666667;
        double sd = 0.266666666667;
        double ha_maghrib = (DIP + refraction +sd) * -1;

        //ha shubuh (tinggi matahari saat shubuh)
        double ha_shubuh = (-19) + (ha_maghrib);

        //to sudut waktu matahari ketika subuh
        double sinha = Math.Sin(ha_shubuh * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru shubuh
        double to_shubuh = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //shubuh + waktu hakiki
        double shubuh_ws = (12 - Math.Abs(to_shubuh)) - eot + (BD - bt) / 15;

        //awal waktu imsak
        double waktu_imsak = shubuh_ws - 0.16666666667;

        //merubah menjadi bentuk jam
        String jam_imsak = bderajat_jam(waktu_imsak);

        return jam_imsak;
    }

    //fungsi perhitungan waktu terbit
    public String w_terbit(double lt, double bt, double alt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;


        //ha terbit (tinggi matahari saat terbit)
        double DIP = 0.029333333334 * Math.Sqrt(alt);
        double refraction= 0.566666666667;
        double sd = 0.266666666667;
        double ha_terbit = (DIP + refraction +sd) * -1;

        //to sudut waktu matahari ketika subuh
        double sinha = Math.Sin(ha_terbit * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru terbit
        double to_terbit = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //terbit + waktu hakiki
        double terbit_ws = (12 - Math.Abs(to_terbit)) - eot + (BD - bt) / 15;

        //awal waktu terbit
        double waktu_terbit = terbit_ws;

        //merubah menjadi bentuk jam
        String jam_terbit = bderajat_jam(waktu_terbit);

        return jam_terbit;
    }

    //fungsi perhitungan waktu dhuha
    public String w_duha(double lt, double bt, double deklinasi, double eot, double tz)
    {

        //menghitung BD
        double BD = tz * 15;


        //ha duha (tinggi matahari saat duha)
        double ha_duha = 4.5;

        //to sudut waktu matahari ketika duha
        double sinha = Math.Sin(ha_duha * Math.PI / 180);
        double coslt = Math.Cos(lt * Math.PI / 180);
        double cosdek = Math.Cos(deklinasi * Math.PI / 180);
        double tanlt = Math.Tan(lt * Math.PI / 180);
        double tandek = Math.Tan(deklinasi * Math.PI / 180);

        //rumus perhitungan to sudut wakru duha
        double to_duha = ((Math.Acos(sinha / coslt / cosdek - tanlt * tandek))*(180/Math.PI)) / 15;

        //duha + waktu hakiki
        double duha_ws = (12 - Math.Abs(to_duha)) - eot + (BD - bt) / 15;

        //awal waktu duha + ihtiyat 2 menit
        double waktu_duha = duha_ws;

        //merubah menjadi bentuk jam
        String jam_duha = bderajat_jam(waktu_duha);

        return jam_duha;
    }

    public double Az_qiblat(double ltx, double btx)
    {
        double lk = 21.42254722;//lintang ka'bah
        double bk = 39.82626667;//bujur ka'bah

        //mencari C (selisih bujur ka'bah dengan daerah)
        double c = 0;
        string arah = "tidak diketahui";
        if (btx >= 0 && btx > bk)
        {
            c = btx - bk;
            arah = "barat";
        }
        else if (btx >= 0 && btx < bk)
        {
            c = bk - btx;
            arah = "timur";
        }
        else if (btx < 0 && btx < -140.1722222)
        {
            c = Math.Abs(btx) + bk;
            arah = "timur";
        }
        else if (btx < 0 && btx > -140.172222)
        {
            c = 360 - Math.Abs(btx) - bk;
            arah = "barat";
        }

        double tanlk = Math.Tan(lk * Math.PI / 180);
        double coslt = Math.Cos(ltx * Math.PI / 180);
        double sinc = Math.Sin(c * Math.PI / 180);
        double sinlt = Math.Sin(ltx * Math.PI / 180);
        double tanc = Math.Tan(c * Math.PI / 180);

        //rumuskiblat
        double kiblat = 180 / Math.PI * (Math.Atan(1 / ((tanlk * coslt / sinc) - sinlt / tanc)));

        double azmkiblt = 0;
        //mencari azimut kiblat
        if (kiblat >= 0 && arah.Equals("timur"))
        {
            azmkiblt = kiblat;
        }
        else if (kiblat >= 0 && arah.Equals("barat"))
        {
            azmkiblt = 360 - kiblat;
        }
        else if (kiblat < 0 && arah.Equals("timur"))
        {
            azmkiblt = 180 - Math.Abs(kiblat);
        }
        else if (kiblat < 0 && arah.Equals("barat"))
        {
            azmkiblt = 180 + Math.Abs(kiblat);
        }

        return azmkiblt;
    }

    public string rsQiblat(double lt, double bt, double deklinasi, double eot, double tz)
    {

        double AQ = 360 - Az_qiblat(lt, bt);

        //rumus1
        double U = Math.Atan(1 / (Math.Tan(AQ * (Math.PI / 180)) * Math.Sin(lt * (Math.PI / 180)))) * (180 / Math.PI);
        //double A = Math.Atan(1/(Math.Sin(lt*(Math.PI / 180)) * Math.Atan(AQ * (Math.PI / 180))))*(180/Math.PI);

        //rumus2
        double t_U = Math.Acos(Math.Tan(deklinasi * (Math.PI / 180)) * Math.Cos(U * (Math.PI / 180)) / Math.Tan(lt * (Math.PI / 180))) * (180 / Math.PI);
        //double B = Math.Cos(1/(Math.Tan(deklinasi * (Math.PI / 180)) * Math.Atan(lt * (Math.PI / 180)) * Math.Cos(A * (Math.PI / 180))))*(180/Math.PI);

        if (U < 0)
        {
            t_U = Math.Abs(t_U);
        }
        else
        {
            t_U = Math.Abs(t_U) * -1;
        }

        //rumus3
        double t = (t_U + U) / 15 + 12 ;
        //double RQ = (A + B) / 15 + 12;

        //Waktu Daerah
        double WD = t - eot + ((tz * 15) - bt) / 15;

        //mengubah menjadi bentuk jam
        string rsqiblat = bderajat_jam(WD);

        return rsqiblat;
    }


    //merubah bilangan desimal ke derajat
    private string kederajat(double a)
    {
        double derajat = 0;
        double menit = 0;
        double detik = 0;
        string min_plus = " ";

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
            min_plus = "-";
        }

        if (a >= 0)
        {
            menit = (int)(Math.Floor((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Ceiling((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return min_plus + (int)Math.Abs(derajat) + "° " + (int)Math.Abs(menit) + "' " + Math.Abs(detik) + "''";
    }

    private String bderajat_jam(double a)
    {

        double derajat = 0;
        double menit = 0;
        double detik = 0;

        if (a >= 0)
        {
            derajat = (int)(Math.Floor(a));
        }
        else
        {
            derajat = (int)(Math.Ceiling(a));
        }

        if (a >= 0)
        {
            menit = (int)(Math.Round((a - derajat) * 60));
        }
        else
        {
            menit = (int)(Math.Round((a - derajat) * 60));
        }


        detik = Math.Round((((a - derajat) * 60) - (menit)) * 60);

        return derajat.ToString("00") + " : " + Math.Abs(menit).ToString("00");

    }
}
