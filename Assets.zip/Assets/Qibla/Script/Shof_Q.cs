﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shof_Q : MonoBehaviour
{

    private Qiblat qiblat;

    //variable azimuth qiblat
    float az_q;

    // Variable Koordinat
    double lt;
    double bt;

    // Start is called before the first frame update
    void Start()
    {
        //get value Koordinat
        lt = -7;
        bt = 110;

        //get azimuth qiblat from function Qiblat
        qiblat = gameObject.AddComponent<Qiblat>();
        double az_Q_d = qiblat.Az_qiblat(lt, bt);
        az_q = (float)az_Q_d + 90;

        //rotasi objek berdasarkan nilai azimuth dan altitude bulan
        transform.rotation = Quaternion.Euler(0, az_q, 0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
