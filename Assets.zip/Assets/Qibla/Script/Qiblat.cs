﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Qiblat : MonoBehaviour
{
  public double Az_qiblat(double ltx, double btx)
    {
        double lk = 21.42254722;//lintang ka'bah
        double bk = 39.82626667;//bujur ka'bah

        //mencari C (selisih bujur ka'bah dengan daerah)
        double c = 0;
        string arah = "tidak diketahui";
        if (btx >= 0 && btx > bk)
        {
            c = btx - bk;
            arah = "barat";
        }
        else if (btx >= 0 && btx < bk)
        {
            c = bk - btx;
            arah = "timur";
        }
        else if (btx < 0 && btx < -140.1722222)
        {
            c = Math.Abs(btx) + bk;
            arah = "timur";
        }
        else if (btx < 0 && btx > -140.172222)
        {
            c = 360 - Math.Abs(btx) - bk;
            arah = "barat";
        }

        double tanlk = Math.Tan(lk * Math.PI / 180);
        double coslt = Math.Cos(ltx * Math.PI / 180);
        double sinc = Math.Sin(c * Math.PI / 180);
        double sinlt = Math.Sin(ltx * Math.PI / 180);
        double tanc = Math.Tan(c * Math.PI / 180);

        //rumuskiblat
        double kiblat = 180/Math.PI*(Math.Atan(1 / ((tanlk * coslt / sinc) - sinlt / tanc)));

        double azmkiblt = 0;
        //mencari azimut kiblat
        if (kiblat >= 0 && arah.Equals("timur"))
        {
            azmkiblt = kiblat;
        }
        else if (kiblat >= 0 && arah.Equals("barat"))
        {
            azmkiblt = 360 - kiblat;
        }
        else if (kiblat < 0 && arah.Equals("timur"))
        {
            azmkiblt = 180 - Math.Abs(kiblat);
        }
        else if (kiblat < 0 && arah.Equals("barat"))
        {
            azmkiblt = 180 + Math.Abs(kiblat);
        }

        return azmkiblt;
    }
}
