﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PetunjukH : MonoBehaviour
{
    public Transform Kamera;
    public Transform PorosRotasi;

    public RectTransform kanan;
    public RectTransform kiri;
    
    // Start is called before the first frame update
    void Start()
    {
        kanan.gameObject.SetActive(false);
        kiri.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        // hide arrow when near target
        float kameray = (Mathf.Abs((Kamera.eulerAngles.y)-180))%360;
        float porosy = Mathf.Abs((PorosRotasi.eulerAngles.y)-90);
        float az = Mathf.Abs(kameray - porosy);

        float HideDistance = 5f;

        //Debug.Log("Kameray" + "=" + kameray);
        //Debug.Log("porosy" + "=" + porosy);

        if ((kameray < porosy) && (az > HideDistance))
        {
            kanan.gameObject.SetActive(true);
            kiri.gameObject.SetActive(false);
        }
        else if ((kameray > porosy) && (az > HideDistance))
        {
            kiri.gameObject.SetActive(true);
            kanan.gameObject.SetActive(false);
        }
        else if (az < HideDistance) 
        {
            kanan.gameObject.SetActive(false);
            kiri.gameObject.SetActive(false);
        }
    }
}
