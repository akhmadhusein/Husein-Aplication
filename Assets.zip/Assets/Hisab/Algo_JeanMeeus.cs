﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Algo_JeanMeeus : MonoBehaviour
{

  // fungsi intek
    static double intek(double angka)
    {
        double hasil;
        if (angka > 0)
        {
            hasil = System.Math.Floor(angka);
        }
        else
        {
            hasil = System.Math.Ceiling(angka);
        }
        return hasil;
    }

 // fungsi MOD
    static double MOD(double a1, double a2)
    {
        double hasiln1 = a1 / a2;
        double hasilint = System.Math.Floor(hasiln1);
        double hasiln2 = hasiln1 - hasilint;
        double hasil = hasiln2 * a2;
        return hasil;
    }

// perhitungan Posisi bulan dan Matahari
    public  double[] Data_Algo_JeanMeeus(int tahun, int bulan, int tgl, double jam, double mnt, double timezone)
    {

       
        int tahun1 = tahun;
        int bulan1 = bulan;
        int Tanggal1 = tgl;
        double jam1 = jam;
        double menit1 = mnt;
        double tz = timezone;

        // menghitung Waktu Lokal
        double sima2 = (jam1 + menit1 / 60 + 0 / 3600) - tz;


        // menghitung JD

        int year2;
        int month2;
        if (bulan1 <= 2){
            month2 = bulan1 + 12;
            year2 = tahun1 - 1;
        }
        else{
            month2 = bulan1;
            year2 = tahun1;
        }
     

    // koreksi kalender gregorian
        int A = 0;
        int B = 0;
        
        if (year2 > 1582)
        {
            A = (year2 / 100);
            B = 2 + (A / 4) - A;
        }

        double JD = 1720994.5 + (int)(365.25 * year2) + (int)(30.60001 * (bulan1 + 1)) + B + Tanggal1 + ((jam1 + menit1 / 60 + 0 / 3600) / 24) - (tz / 24);
        double JD_UT = (1720994.5 + (int)(365.25 * year2) + (int)(30.60001 * (bulan1 + 1)) + B + Tanggal1 + ((jam1 + menit1 / 60 + 0 / 3600) / 24) - (tz / 24));


        double date2 = Tanggal1;
        double waktu = sima2;

        //double jede = JD_UT;
        double jede = intek(365.25 * (year2 + 4716)) + intek(30.6001 * (month2 + 1)) + date2 + (2 - (intek(year2 / 100)) + intek((intek(year2 / 100) / 4))) + waktu / 24 - 1524.5;

        // menghitung deltaT
        double delta;
        if (year2 < -500)
        {
            delta = (-20 + 32 * System.Math.Pow((year2 / 100 - 18.2), 2)) / 3600 / 24;
        }
        else if (year2 >= -500 && year2 < 500)
        {
            delta = (10583.6 - 1014.41 * (year2 / 100) + 33.78311 * System.Math.Pow((year2 / 100), 2) - 5) / 3600 / 24;
        }
        else if (year2 >= 500 && year2 < 1600)
        {
            delta = (1574.2 - 556.01 * (year2 / 100 - 10) + 71.23472 * System.Math.Pow((year2 / 100 - 10), 2) + 0.319781 * System.Math.Pow((year2 / 100 - 10), 3) - 0.8503463 * System.Math.Pow((year2 / 100 - 10), 4) - 0.00505998 * System.Math.Pow((year2 / 100 - 10), 5) + 0.0083572073 * System.Math.Pow((year2 / 100 - 10), 6)) / 3600 / 24;
        }
        else if (year2 >= 1600 && year2 < 1700)
        {
            delta = (120 - 0.9808 * (year2 - 1600) - 0.01532 * System.Math.Pow((year2 - 1600), 2) + System.Math.Pow((year2 - 1600), 3) / 7129) / 3600 / 24;
        }
        else if (year2 >= 1700 && year2 < 1800)
        {
            delta = (8.83 + 0.1603 * (year2 - 1700) - 0.0059285 * System.Math.Pow((year2 - 1700), 2) + 0.00013336 * System.Math.Pow((year2 - 1700), 3) - System.Math.Pow((year2 - 1700), 4) / 1174000) / 3600 / 24;
        }
        else if (year2 >= 1800 && year2 < 1860)
        {
            delta = (13.72 - 0.332447 * (year2 - 1800) + 0.0068612 * System.Math.Pow((year2 - 1800), 2) + 0.0041116 * System.Math.Pow((year2 - 1800), 3) - 0.00037436 * System.Math.Pow((year2 - 1800), 4) + 0.0000121272 * System.Math.Pow((year2 - 1800), 5) - 0.0000001699 * System.Math.Pow((year2 - 1800), 6) + 0.000000000875 * System.Math.Pow((year2 - 1800), 7)) / 3600 / 24 / 3600 / 24;
        }
        else if (year2 >= 1860 && year2 < 1900)
        {
            delta = (7.62 + 0.5737 * (year2 - 1860) - 0.251754 * System.Math.Pow((year2 - 1860), 2) + 0.01680668 * System.Math.Pow((year2 - 1860), 3) - 0.0004473624 * System.Math.Pow((year2 - 1860), 4) + System.Math.Pow((year2 - 1850), 5) / 233174) / 3600 / 24;
        }
        else if (year2 >= 1900 && year2 < 1920)
        {
            delta = (-2.79 + 1.494119 * (year2 - 1900) - 0.0598939 * System.Math.Pow((year2 - 1900), 2) + 0.0061966 * System.Math.Pow((year2 - 1900), 3) - 0.000197 * System.Math.Pow((year2 - 1900), 4)) / 3600 / 24;
        }
        else if (year2 >= 1920 && year2 < 1941)
        {
            delta = (21.2 + 0.84493 * (year2 - 1920) - 0.0761 * System.Math.Pow((year2 - 1920), 2) + 0.0020936 * System.Math.Pow((year2 - 1920), 3)) / 3600 / 24;
        }
        else if (year2 >= 1941 && year2 < 1961)
        {
            delta = (29.07 + 0.407 * (year2 - 1950) - System.Math.Pow((year2 - 1950), 2) / 233 + System.Math.Pow((year2 - 1950), 3) / 2547) / 3600 / 24 / 3600 / 24;
        }
        else if (year2 >= 1961 && year2 < 1986)
        {
            delta = (45.45 + 1.067 * (year2 - 1975) - System.Math.Pow((year2 - 1975), 2) / 260 - System.Math.Pow((year2 - 1975), 3) / 718) / 3600 / 24;
        }
        else if (year2 >= 1986 && year2 < 2005)
        {
            delta = (63.86 + 0.3345 * (year2 - 2000) - 0.060374 * System.Math.Pow((year2 - 2000), 2) + 0.0017275 * System.Math.Pow((year2 - 2000), 3) + 0.000651814 * System.Math.Pow((year2 - 2000), 4) + 0.00002373599 * System.Math.Pow((year2 - 2000), 5)) / 3600 / 24;
        }
        else if (year2 >= 2005 && year2 < 2050)
        {
            delta = (62.92 + 0.32217 * ((year2 + month2 / 12 + date2 / 365.25 + waktu / 24 / 365.25) - 2000) + 0.005589 * System.Math.Pow(((year2 + month2 / 12 + date2 / 365.25 + waktu / 24 / 365.25) - 2000), 2)) / 3600 / 24;
        }
        else if (year2 >= 2050 && year2 < 2150)
        {
            delta = (-20 + 32 * System.Math.Pow(((year2 - 1820) / 100), 2) - 0.5628 * (2150 - year2)) / 3600 / 24;
        }
        else if (year2 >= 2150)
        {
            delta = (-20 + 32 * System.Math.Pow(((year2 - 1820) / 100), 2)) / 3600 / 24;
        }
        else
        {
            delta = 0.0000;
        };

        // JDE waktu TD Dynamical time
        double jde = jede + delta;
        double tete = (jde - 2451545) / 36525;
        double tautau = tete / 10;


        // Koreksi Tabel Appenndix
        double epsilon4 = 23.43929111;
        double epsilon33 = (46.815 / 3600 * tete);
        double epsilon22 = (0.00059 / 3600 * System.Math.Pow(tete, 2));
        double epsilon1 = (0.001813 / 3600 * System.Math.Pow(tete, 3));
        double epsilon = epsilon4 - epsilon33 - epsilon22 + epsilon1;

        double elo = MOD((280.46645 + 36000.76983 * tete + 0.0003032 * System.Math.Pow(tete, 2)), 360);

        double mbesar = MOD((357.5291 + 35999.0503 * tete - 0.0001559 * System.Math.Pow(tete, 2) - 0.00000048 * System.Math.Pow(tete, 3)), 360);
        double ekecil = MOD((0.016708617 - 0.000042037 * tete - 0.0000001236 * System.Math.Pow(tete, 2)), 360);
        double cbesar = MOD(((1.9146 - 0.004817 * tete - 0.000014 * System.Math.Pow(tete, 2)) * System.Math.Sin(System.Math.PI / 180 * (mbesar)) + (0.019993 - 0.000101 * tete) * System.Math.Sin(System.Math.PI / 180 * (2 * mbesar)) + 0.00029 * System.Math.Sin(System.Math.PI / 180 * (3 * mbesar))), 360);
        double pentol = MOD((elo + cbesar), 360);
        double vkecil = MOD((mbesar + cbesar), 360);

        double rbesar = (1.000001018 * (1 - System.Math.Pow(ekecil, 2))) / (1 + ekecil * System.Math.Cos(System.Math.PI / 180 * (vkecil)));
        double omega = MOD((125.04 - 1934.136 * tete), 360);
        double lambda = MOD((pentol - 0.00569 - 0.00478 * System.Math.Sin(System.Math.PI / 180 * (omega))), 360);
        double alpha = MOD((180 / System.Math.PI * (System.Math.Atan((System.Math.Cos(System.Math.PI / 180 * (epsilon)) * System.Math.Sin(System.Math.PI / 180 * (pentol))) / System.Math.Cos(System.Math.PI / 180 * (pentol))))), 360);
        double delta1 = 180 / System.Math.PI * (System.Math.Asin(System.Math.Sin(System.Math.PI / 180 * (epsilon)) * System.Math.Sin(System.Math.PI / 180 * (pentol))));
        double alphatampak = MOD((180 / System.Math.PI * (System.Math.Atan((System.Math.Cos(System.Math.PI / 180 * ((epsilon) + 0.00256 * System.Math.Cos(System.Math.PI / 180 * (omega)))) * System.Math.Sin(System.Math.PI / 180 * (lambda))) / System.Math.Cos(System.Math.PI / 180 * (lambda))))), 360);
        double delta1tampak = 180 / System.Math.PI * (System.Math.Asin(System.Math.Sin(System.Math.PI / 180 * ((epsilon) + 0.00256 * System.Math.Cos(System.Math.PI / 180 * (omega)))) * System.Math.Sin(System.Math.PI / 180 * (lambda))));


        //koreksi L0
        double kor1 = (175347046 * System.Math.Cos(0 + 0 * tautau));
        double kor2 = (3341656 * System.Math.Cos(4.6692568 + 6283.07585 * tautau));
        double kor3 = (34894 * System.Math.Cos(4.6261 + 12566.1517 * tautau));
        double kor4 = (3497 * System.Math.Cos(2.7441 + 5753.3849 * tautau));
        double kor5 = (3418 * System.Math.Cos(2.8289 + 3.5231 * tautau));
        double kor6 = (3136 * System.Math.Cos(3.6277 + 77713.7715 * tautau));
        double kor7 = (2676 * System.Math.Cos(4.4181 + 7860.4194 * tautau));
        double kor8 = (2343 * System.Math.Cos(6.1352 + 3930.2097 * tautau));
        double kor9 = (1324 * System.Math.Cos(0.7425 + 11506.7698 * tautau));
        double kor10 = (1273 * System.Math.Cos(2.0371 + 529.691 * tautau));
        double kor11 = (1199 * System.Math.Cos(1.1096 + 1577.3435 * tautau));
        double kor12 = (990 * System.Math.Cos(5.233 + 5884.927 * tautau));
        double kor13 = (902 * System.Math.Cos(2.045 + 26.298 * tautau));
        double kor14 = (857 * System.Math.Cos(3.508 + 398.149 * tautau));
        double kor15 = (780 * System.Math.Cos(1.179 + 5223.694 * tautau));
        double kor16 = (753 * System.Math.Cos(2.533 + 5507.553 * tautau));
        double kor17 = (505 * System.Math.Cos(4.583 + 18849.228 * tautau));
        double kor18 = (492 * System.Math.Cos(4.205 + 775.523 * tautau));
        double kor19 = (357 * System.Math.Cos(2.92 + 0.067 * tautau));
        double kor20 = (317 * System.Math.Cos(5.849 + 11790.629 * tautau));
        double kor21 = (284 * System.Math.Cos(1.899 + 796.298 * tautau));
        double kor22 = (271 * System.Math.Cos(0.315 + 10977.079 * tautau));
        double kor23 = (243 * System.Math.Cos(0.345 + 5486.778 * tautau));
        double kor24 = (206 * System.Math.Cos(4.806 + 2544.314 * tautau));
        double kor25 = (205 * System.Math.Cos(1.869 + 5573.143 * tautau));
        double kor26 = (202 * System.Math.Cos(2.458 + 6069.777 * tautau));
        double kor27 = (156 * System.Math.Cos(0.833 + 213.299 * tautau));
        double kor28 = (132 * System.Math.Cos(3.411 + 2942.463 * tautau));
        double kor29 = (126 * System.Math.Cos(1.083 + 20.775 * tautau));
        double kor30 = (115 * System.Math.Cos(0.645 + 0.98 * tautau));
        double kor31 = (103 * System.Math.Cos(0.636 + 4694.003 * tautau));
        double kor32 = (102 * System.Math.Cos(0.976 + 15720.839 * tautau));
        double kor33 = (102 * System.Math.Cos(4.267 + 7.114 * tautau));
        double kor34 = (99 * System.Math.Cos(6.21 + 2146.17 * tautau));
        double kor35 = (98 * System.Math.Cos(0.68 + 155.42 * tautau));
        double kor36 = (86 * System.Math.Cos(5.98 + 161000.69 * tautau));
        double kor37 = (85 * System.Math.Cos(1.3 + 6275.96 * tautau));
        double kor38 = (85 * System.Math.Cos(3.67 + 71430.7 * tautau));
        double kor39 = (80 * System.Math.Cos(1.81 + 17260.15 * tautau));
        double kor40 = (79 * System.Math.Cos(3.04 + 12036.46 * tautau));
        double kor41 = (75 * System.Math.Cos(1.76 + 5088.63 * tautau));
        double kor42 = (74 * System.Math.Cos(3.5 + 3154.69 * tautau));
        double kor43 = (74 * System.Math.Cos(4.68 + 801.82 * tautau));
        double kor44 = (70 * System.Math.Cos(0.83 + 9437.76 * tautau));
        double kor45 = (62 * System.Math.Cos(3.98 + 8827.39 * tautau));
        double kor46 = (61 * System.Math.Cos(1.82 + 7084.9 * tautau));
        double kor47 = (57 * System.Math.Cos(2.78 + 6286.6 * tautau));
        double kor48 = (56 * System.Math.Cos(4.39 + 14143.5 * tautau));
        double kor49 = (56 * System.Math.Cos(3.47 + 6279.55 * tautau));
        double kor50 = (52 * System.Math.Cos(0.19 + 12139.55 * tautau));
        double kor51 = (52 * System.Math.Cos(1.33 + 1748.02 * tautau));
        double kor52 = (51 * System.Math.Cos(0.28 + 5856.48 * tautau));
        double kor53 = (49 * System.Math.Cos(0.49 + 1194.45 * tautau));
        double kor54 = (41 * System.Math.Cos(5.37 + 8429.24 * tautau));
        double kor55 = (41 * System.Math.Cos(2.4 + 19651.05 * tautau));
        double kor56 = (39 * System.Math.Cos(6.17 + 10447.39 * tautau));
        double kor57 = (37 * System.Math.Cos(6.04 + 10213.29 * tautau));
        double kor58 = (37 * System.Math.Cos(2.57 + 1059.38 * tautau));
        double kor59 = (36 * System.Math.Cos(1.71 + 2352.87 * tautau));
        double kor60 = (36 * System.Math.Cos(1.78 + 6812.77 * tautau));
        double kor61 = (33 * System.Math.Cos(0.59 + 17789.85 * tautau));
        double kor62 = (30 * System.Math.Cos(0.44 + 83996.85 * tautau));
        double kor63 = (30 * System.Math.Cos(2.74 + 1349.87 * tautau));
        double kor64 = (25 * System.Math.Cos(3.16 + 4690.48 * tautau));
        double jumlahkor = kor1 + kor2 + kor3 + kor4 + kor5 + kor6 + kor7 + kor8 + kor9 + kor10 + kor11 + kor12 + kor13
                + kor14 + kor15 + kor16 + kor17 + kor18 + kor19 + kor20 + kor21 + kor22 + kor23 + kor24 + kor25 + kor26 + kor27 + kor28
                + kor29 + kor30 + kor31 + kor32 + kor33 + kor34 + kor35 + kor36 + kor37 + kor38 + kor39 + kor40 + kor41 + kor42 + kor43
                + kor44 + kor45 + kor46 + kor47 + kor48 + kor49 + kor50 + kor51 + kor52 + kor53 + kor54 + kor55 + kor56 + kor57 + kor58
                + kor59 + kor60 + kor61 + kor62 + kor63 + kor64;


        //koreksi bujur L1
        double korq1 = 628331966747L * System.Math.Cos(0 + 0 * tautau);
        double korq2 = 206059 * System.Math.Cos(2.678235 + 6283.07585 * tautau);
        double korq3 = 4303 * System.Math.Cos(2.6351 + 12566.1517 * tautau);
        double korq4 = 425 * System.Math.Cos(1.59 + 3.523 * tautau);
        double korq5 = 119 * System.Math.Cos(5.796 + 26.298 * tautau);
        double korq6 = 109 * System.Math.Cos(2.966 + 1577.344 * tautau);
        double korq7 = 93 * System.Math.Cos(2.59 + 18849.23 * tautau);
        double korq8 = 72 * System.Math.Cos(1.14 + 529.69 * tautau);
        double korq9 = 68 * System.Math.Cos(1.87 + 398.15 * tautau);
        double korq10 = 67 * System.Math.Cos(4.41 + 5507.55 * tautau);
        double korq11 = 59 * System.Math.Cos(2.89 + 5223.69 * tautau);
        double korq12 = 56 * System.Math.Cos(2.17 + 155.42 * tautau);
        double korq13 = 45 * System.Math.Cos(0.4 + 796.3 * tautau);
        double korq14 = 36 * System.Math.Cos(0.47 + 775.52 * tautau);
        double korq15 = 29 * System.Math.Cos(2.65 + 7.11 * tautau);
        double korq16 = 21 * System.Math.Cos(5.34 + 0.98 * tautau);
        double korq17 = 19 * System.Math.Cos(1.85 + 5486.78 * tautau);
        double korq18 = 19 * System.Math.Cos(4.97 + 213.3 * tautau);
        double korq19 = 17 * System.Math.Cos(2.99 + 6275.96 * tautau);
        double korq20 = 16 * System.Math.Cos(0.03 + 2544.31 * tautau);
        double korq21 = 16 * System.Math.Cos(1.43 + 2146.17 * tautau);
        double korq22 = 15 * System.Math.Cos(1.21 + 10977.08 * tautau);
        double korq23 = 12 * System.Math.Cos(2.83 + 1748.02 * tautau);
        double korq24 = 12 * System.Math.Cos(3.26 + 5088.63 * tautau);
        double korq25 = 12 * System.Math.Cos(5.27 + 1194.45 * tautau);
        double korq26 = 12 * System.Math.Cos(2.08 + 4694 * tautau);
        double korq27 = 11 * System.Math.Cos(0.77 + 553.57 * tautau);
        double korq28 = 10 * System.Math.Cos(1.3 + 6286.6 * tautau);
        double korq29 = 10 * System.Math.Cos(4.24 + 1349.87 * tautau);
        double korq30 = 9 * System.Math.Cos(2.7 + 242.73 * tautau);
        double korq31 = 9 * System.Math.Cos(5.64 + 951.72 * tautau);
        double korq32 = 8 * System.Math.Cos(5.3 + 2352.87 * tautau);
        double korq33 = 6 * System.Math.Cos(2.65 + 9437.76 * tautau);
        double korq34 = 6 * System.Math.Cos(4.67 + 4690.48 * tautau);
        double jumlahkorq = korq1 + korq2 + korq3 + korq4 + korq5 + korq6 + korq7 + korq8 + korq9 + korq10
                + korq11 + korq12 + korq13 + korq14 + korq15 + korq16 + korq17 + korq18 + korq19 + korq20
                + korq21 + korq22 + korq23 + korq24 + korq25 + korq26 + korq27 + korq28 + korq29 + korq30
                + korq31 + korq32 + korq33 + korq34;

        //koreksi bujur L2
        double korw1 = 52919 * System.Math.Cos(0 + 0 * tautau);
        double korw2 = 8720 * System.Math.Cos(1.0721 + 6283.0758 * tautau);
        double korw3 = 309 * System.Math.Cos(0.867 + 12566.152 * tautau);
        double korw4 = 27 * System.Math.Cos(0.05 + 3.52 * tautau);
        double korw5 = 16 * System.Math.Cos(5.19 + 26.3 * tautau);
        double korw6 = 16 * System.Math.Cos(3.68 + 155.42 * tautau);
        double korw7 = 10 * System.Math.Cos(0.76 + 18849.23 * tautau);
        double korw8 = 9 * System.Math.Cos(2.06 + 77713.77 * tautau);
        double korw9 = 7 * System.Math.Cos(0.83 + 775.52 * tautau);
        double korw10 = 5 * System.Math.Cos(4.66 + 1577.34 * tautau);
        double korw11 = 4 * System.Math.Cos(1.03 + 7.11 * tautau);
        double korw12 = 4 * System.Math.Cos(3.44 + 5573.14 * tautau);
        double korw13 = 3 * System.Math.Cos(5.14 + 796.3 * tautau);
        double korw14 = 3 * System.Math.Cos(6.05 + 5507.55 * tautau);
        double korw15 = 3 * System.Math.Cos(1.19 + 242.73 * tautau);
        double korw16 = 3 * System.Math.Cos(6.12 + 529.69 * tautau);
        double korw17 = 3 * System.Math.Cos(0.31 + 398.15 * tautau);
        double korw18 = 3 * System.Math.Cos(2.28 + 553.57 * tautau);
        double korw19 = 2 * System.Math.Cos(4.38 + 5223.69 * tautau);
        double korw20 = 2 * System.Math.Cos(3.75 + 0.98 * tautau);
        double jumlahkorw = korw1 + korw2 + korw3 + korw4 + korw5 + korw6 + korw7 + korw8 + korw9
                + korw10 + korw11 + korw12 + korw13 + korw14 + korw15 + korw16 + korw17 + korw18 + korw19 + korw20;

        //koreksi bujur L3
        double kore1 = 289 * System.Math.Cos(5.844 + 6283.076 * tautau);
        double kore2 = 35 * System.Math.Cos(0 + 0 * tautau);
        double kore3 = 17 * System.Math.Cos(5.49 + 12566.15 * tautau);
        double kore4 = 3 * System.Math.Cos(5.2 + 155.42 * tautau);
        double kore5 = 1 * System.Math.Cos(4.72 + 3.52 * tautau);
        double kore6 = 1 * System.Math.Cos(5.3 + 18849.23 * tautau);
        double kore7 = 1 * System.Math.Cos(5.97 + 242.73 * tautau);
        double jumlahkore = kore1 + kore2 + kore3 + kore4 + kore5 + kore6 + kore7;

        //koreksi bujur L4
        double korr1 = 114 * System.Math.Cos(3.142 + 0 * tautau);
        double korr2 = 8 * System.Math.Cos(4.13 + 6283.08 * tautau);
        double korr3 = 1 * System.Math.Cos(3.84 + 12566.15 * tautau);
        double jumlahkorr = korr1 + korr2 + korr3;

        //koreksi bujur L5
        double jumlahkort = 1 * System.Math.Cos(3.14 + 0 * tautau);

        double elbesar = MOD((180 / System.Math.PI * ((jumlahkor + jumlahkorq * tautau + jumlahkorw
                * System.Math.Pow(tautau, 2) + jumlahkore * System.Math.Pow(tautau, 3) + jumlahkorr
                * System.Math.Pow(tautau, 4) + jumlahkort * System.Math.Pow(tautau, 5)) / System.Math.Pow(10, 8))), 360);
        double pentol2 = MOD((elbesar + 180), 360);
        double iaksen = (pentol2 - 1.397 * tete - 0.00031 * System.Math.Pow(tete, 2)) - 0.09033 / 3600;
        double segitiga = -0.09033 / 3600;


        //koreksi bumi matahari R0
        double kory1 = 100013989 * System.Math.Cos(0 + 0 * tautau);
        double kory2 = 1670700 * System.Math.Cos(3.0984635 + 6283.07585 * tautau);
        double kory3 = 13956 * System.Math.Cos(3.05525 + 12566.1517 * tautau);
        double kory4 = 3084 * System.Math.Cos(5.1985 + 77713.7715 * tautau);
        double kory5 = 1628 * System.Math.Cos(1.1739 + 5753.3849 * tautau);
        double kory6 = 1576 * System.Math.Cos(2.8469 + 7860.4194 * tautau);
        double kory7 = 925 * System.Math.Cos(5.453 + 11506.77 * tautau);
        double kory8 = 542 * System.Math.Cos(4.564 + 3930.21 * tautau);
        double kory9 = 472 * System.Math.Cos(3.661 + 5884.927 * tautau);
        double kory10 = 346 * System.Math.Cos(0.964 + 5507.553 * tautau);
        double kory11 = 329 * System.Math.Cos(5.9 + 5223.694 * tautau);
        double kory12 = 307 * System.Math.Cos(0.299 + 5573.143 * tautau);
        double kory13 = 243 * System.Math.Cos(4.273 + 11790.629 * tautau);
        double kory14 = 212 * System.Math.Cos(5.847 + 1577.344 * tautau);
        double kory15 = 186 * System.Math.Cos(5.022 + 10977.079 * tautau);
        double kory16 = 175 * System.Math.Cos(3.012 + 18849.228 * tautau);
        double kory17 = 110 * System.Math.Cos(5.055 + 5486.778 * tautau);
        double kory18 = 98 * System.Math.Cos(0.89 + 6069.78 * tautau);
        double kory19 = 86 * System.Math.Cos(5.69 + 15720.84 * tautau);
        double kory20 = 86 * System.Math.Cos(1.27 + 161000.69 * tautau);
        double kory21 = 65 * System.Math.Cos(0.27 + 17260.15 * tautau);
        double kory22 = 63 * System.Math.Cos(0.92 + 529.69 * tautau);
        double kory23 = 57 * System.Math.Cos(2.01 + 83996.85 * tautau);
        double kory24 = 56 * System.Math.Cos(5.24 + 71430.7 * tautau);
        double kory25 = 49 * System.Math.Cos(3.25 + 2544.31 * tautau);
        double kory26 = 47 * System.Math.Cos(2.58 + 775.52 * tautau);
        double kory27 = 45 * System.Math.Cos(5.54 + 9437.76 * tautau);
        double kory28 = 43 * System.Math.Cos(6.01 + 6275.96 * tautau);
        double kory29 = 39 * System.Math.Cos(5.36 + 4694 * tautau);
        double kory30 = 38 * System.Math.Cos(2.39 + 8827.39 * tautau);
        double kory31 = 37 * System.Math.Cos(0.83 + 19651.05 * tautau);
        double kory32 = 37 * System.Math.Cos(4.9 + 12139.55 * tautau);
        double kory33 = 36 * System.Math.Cos(1.67 + 12036.46 * tautau);
        double kory34 = 35 * System.Math.Cos(1.84 + 2942.46 * tautau);
        double kory35 = 33 * System.Math.Cos(0.24 + 7084.9 * tautau);
        double kory36 = 32 * System.Math.Cos(0.18 + 5088.63 * tautau);
        double kory37 = 32 * System.Math.Cos(1.78 + 398.15 * tautau);
        double kory38 = 28 * System.Math.Cos(1.21 + 6286.6 * tautau);
        double kory39 = 28 * System.Math.Cos(1.9 + 6279.55 * tautau);
        double kory40 = 26 * System.Math.Cos(4.59 + 10447.39 * tautau);
        double jumlahkory = kory1 + kory2 + kory3 + kory4 + kory5 + kory6 + kory7 + kory8 + kory9
                + kory10 + kory11 + kory12 + kory13 + kory14 + kory15 + kory16 + kory17 + kory18 + kory19 + kory20
                + kory21 + kory22 + kory23 + kory24 + kory25 + kory26 + kory27 + kory28 + kory29 + kory30
                + kory31 + kory32 + kory33 + kory34 + kory35 + kory36 + kory37 + kory38 +kory39+ kory40;

        //koreksi bumi matahari R1
        double koru1 = 103019 * System.Math.Cos(1.10749 + 6283.07585 * tautau);
        double koru2 = 1721 * System.Math.Cos(1.0644 + 12566.1517 * tautau);
        double koru3 = 702 * System.Math.Cos(3.142 + 0 * tautau);
        double koru4 = 32 * System.Math.Cos(1.02 + 18849.23 * tautau);
        double koru5 = 31 * System.Math.Cos(2.84 + 5507.55 * tautau);
        double koru6 = 25 * System.Math.Cos(1.32 + 5223.69 * tautau);
        double koru7 = 18 * System.Math.Cos(1.42 + 1577.34 * tautau);
        double koru8 = 10 * System.Math.Cos(5.91 + 10977.08 * tautau);
        double koru9 = 9 * System.Math.Cos(1.42 + 6275.96 * tautau);
        double koru10 = 9 * System.Math.Cos(0.27 + 5486.78 * tautau);
        double jumlahkoru = koru1 + koru2 + koru3 + koru4 + koru5 + koru6 + koru7 + koru8 + koru9 + koru10;

        // koreksi bumi matahari R2
        double kori1 = 4359 * System.Math.Cos(5.7846 + 6283.0758 * tautau);
        double kori2 = 124 * System.Math.Cos(5.579 + 12566.152 * tautau);
        double kori3 = 12 * System.Math.Cos(3.14 + 0 * tautau);
        double kori4 = 9 * System.Math.Cos(3.63 + 77713.77 * tautau);
        double kori5 = 6 * System.Math.Cos(1.87 + 5573.14 * tautau);
        double kori6 = 3 * System.Math.Cos(5.47 + 18849.23 * tautau);
        double jumlahkori = kori1 + kori2 + kori3 + kori4 + kori5 + kori6;

        //koreksi bumi matahari R3
        double koro1 = 145 * System.Math.Cos(4.273 + 6283.076 * tautau);
        double koro2 = 7 * System.Math.Cos(3.92 + 12566.15 * tautau);
        double jumlahkoro = koro1 + koro2;

        //koreksi bumi matahari R4
        double jumlahkorp = 4 * System.Math.Cos(2.56 + 6283.08 * tautau);

        double erbesar = (jumlahkory + jumlahkoru * tete + jumlahkori * System.Math.Pow(tete, 2) + jumlahkoro * System.Math.Pow(tete, 3) + jumlahkorp * System.Math.Pow(tete, 4)) / System.Math.Pow(10, 8);
        double debesar = MOD((297.85036 + 445267.11148 * tete - 0.0019142 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 189474), 360);
        double embesar = MOD((357.52772 + 35999.05034 * tete - 0.0001603 * System.Math.Pow(tete, 2) - System.Math.Pow(tete, 3) / 300000), 360);
        double emaksen = MOD((134.96298 + 477198.867398 * tete + 0.0086972 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 56250), 360);
        double efbesar = MOD((93.27191 + 483202.017538 * tete - 0.0036825 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 327270), 360);
        double omega2 = MOD((125.04452 - 1934.136261 * tete + 0.0020708 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 450000), 360);
        double ubesar = tete / 100;
        double epsilon2 = 23.43929111 - (4680.93 * ubesar - 1.55 * System.Math.Pow(ubesar, 2) + 1999.25 * System.Math.Pow(ubesar, 3) - 51.38 * System.Math.Pow(ubesar, 4) - 249.67 * System.Math.Pow(ubesar, 5) - 39.05 * System.Math.Pow(ubesar, 6) + 7.12 * System.Math.Pow(ubesar, 7) + 27.87 * System.Math.Pow(ubesar, 8) + 5.79 * System.Math.Pow(ubesar, 9) + 2.45 * System.Math.Pow(ubesar, 10)) / 3600;

 // menghitung NUTASI------
        //koreksi asi
        double korn1 = (-171996 + -174.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn2 = (-13187 + -1.6 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn3 = (-2274 + -0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn4 = (2062 + 0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn5 = (1426 + -3.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn6 = (712 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn7 = (517 + 1.2 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn8 = (-386 + -0.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn9 = (217 + -0.5 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn10 = (129 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn11 = (63 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn12 = (-58 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn13 = (17 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn14 = (-16 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn15 = (-301 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn16 = (-158 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn17 = (123 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn18 = (63 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn19 = (-59 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn20 = (-51 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn21 = (48 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn22 = (46 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn23 = (-38 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn24 = (-31 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn25 = (29 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn26 = (29 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn27 = (26 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn28 = (-22 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn29 = (21 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn30 = (16 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn31 = (-15 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn32 = (-13 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn33 = (-12 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn34 = (11 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn35 = (-10 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn36 = (-8 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn37 = (7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn38 = (-7 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn39 = (-7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn40 = (-7 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn41 = (6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn42 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn43 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn44 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn45 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn46 = (5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn47 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn48 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn49 = (-5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn50 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn51 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn52 = (4 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn53 = (-4 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn54 = (-4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn55 = (-4 + 0 * tete) * System.Math.Sin(1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn56 = (3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn57 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn58 = (-3 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn59 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn60 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn61 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn62 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 3 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn63 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));

        double jumlahkorn = korn1 + korn2 + korn3 + korn4 + korn5 + korn6 + korn7 + korn8 + korn9 + korn10 + korn11 + korn12 + korn13 + korn14 + korn15 + korn16 + korn17 + korn18 + korn19 + korn20
                + korn21 + korn22 + korn23 + korn24 + korn25 + korn26 + korn27 + korn28 + korn29 + korn30
                + korn31 + korn32 + korn33 + korn34 + korn35 + korn36 + korn37 + korn38 + korn39 + korn40
                + korn41 + korn42 + korn43 + korn44 + korn45 + korn46 + korn47 + korn48 + korn49 + korn50
                + korn51 + korn52 + korn53 + korn54 + korn55 + korn56 + korn57 + korn58 + korn59 + korn60 + korn61 + korn62 + korn63;

        //lanjuTan
        double segpeg = jumlahkorn / 10000 / 3600;

    //koreksi delta epsilon
        double kord1 = (92025 + 8.9 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord2 = (5736 + -3.1 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord3 = (977 + -0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord4 = (-895 + 0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord5 = (54 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord6 = (224 + -0.6 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord7 = (129 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord8 = (-95 + 0.3 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord9 = (-7 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord10 = (200 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord11 = (-70 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord12 = (-53 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord13 = (-33 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord14 = (26 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord15 = (32 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord16 = (27 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord17 = (-24 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord18 = (16 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord19 = (13 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord20 = (-12 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord21 = (-10 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord22 = (-8 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord23 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord24 = (9 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord25 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord26 = (6 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord27 = (5 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord28 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord29 = (-3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord30 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord31 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord32 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord33 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord34 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord35 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord36 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord37 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord38 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double jumlahkord = kord1 + kord2 + kord3 + kord4 + kord5 + kord6 + kord7 + kord8 + kord9 + kord10
                + kord11 + kord12 + kord13 + kord14 + kord15 + kord16 + kord17 + kord18 + kord19 + kord20
                + kord21 + kord22 + kord23 + kord24 + kord25 + kord26 + kord27 + kord28 + kord29 + kord30
                + kord31 + kord32 + kord33 + kord34 + kord35 + kord36 + kord37 + kord38;

        //lanjuTan
        double segep = jumlahkord / 10000 / 3600;

        double koraberasi = -20.4898 / erbesar / 3600;
        double segdel = 3548.193 + 118.568 * System.Math.Sin(87.5287 + 359993.7286 * tautau) + 2.476
                * System.Math.Sin(85.0561 + 719987.4571 * tautau) + 1.376 * System.Math.Sin(27.8502 + 4452671.1152 * tautau)
                + 0.119 * System.Math.Sin(73.1375 + 450368.8564 * tautau) + 0.114
                * System.Math.Sin(337.2264 + 329644.6718 * tautau) + 0.086
                * System.Math.Sin(222.54 + 659289.3436 * tautau) + 0.078 * System.Math.Sin(162.8136 + 9224659.7915 * tautau)
                + 0.054 * System.Math.Sin(82.5823 + 1079981.1857 * tautau) + 0.052 * System.Math.Sin(171.5189 + 225184.4282 * tautau)
                + 0.034 * System.Math.Sin(30.3214 + 4092677.3866 * tautau) + 0.033 * System.Math.Sin(119.8105 + 337181.4711 * tautau)
                + 0.023 * System.Math.Sin(247.5418 + 299295.6151 * tautau) + 0.023 * System.Math.Sin(325.1526 + 315559.556 * tautau)
                + 0.021 * System.Math.Sin(155.1241 + 675553.2846 * tautau) + 7.311 * tautau
                * System.Math.Sin(333.4515 + 359993.7286 * tautau) + 0.305 * tautau * System.Math.Sin(330.9814 + 719987.4571 * tautau)
                + 0.01 * tautau * System.Math.Sin(328.517 + 1079981.1857 * tautau) + 0.309 * System.Math.Pow(tautau, 2)
                * System.Math.Sin(241.4518 + 359993.7286 * tautau) + 0.021 * System.Math.Pow(tautau, 2) * System.Math.Sin(205.0482 + 719987.4571 * tautau)
                + 0.004 * System.Math.Pow(tautau, 2) * System.Math.Sin(297.861 + 4452671.1152 * tautau) + 0.01 * System.Math.Pow(tautau, 3)
                * System.Math.Sin(154.7066 + 359993.7286 * tautau);
        double koraberasi2 = -0.005775518 * erbesar * segdel / 3600;
        double delta2 = MOD((pentol2 + segitiga + koraberasi2), 360);
        double epsilon3 = epsilon2 + segep;
        double segbet = 0.03916 * (System.Math.Cos(System.Math.PI / 180 * (iaksen / 3600)) - System.Math.Sin(System.Math.PI / 180 * (iaksen / 3600)));


        //koreksi B0
        double bnol1 = 280 * System.Math.Cos(3.199 + 84334.662 * tautau);
        double bnol2 = 102 * System.Math.Cos(5.422 + 5507.553 * tautau);
        double bnol3 = 80 * System.Math.Cos(3.88 + 5223.69 * tautau);
        double bnol4 = 44 * System.Math.Cos(3.7 + 2352.87 * tautau);
        double bnol5 = 32 * System.Math.Cos(4 + 1577.34 * tautau);
        double koreksibnol = bnol1 + bnol2 + bnol3 + bnol4 + bnol5;

        //koreksi B1
        double bsatu1 = 9 * System.Math.Cos(3.9 + 5507.55 * tautau);
        double bsatu2 = 6 * System.Math.Cos(1.73 + 5223.69 * tautau);
        double koreksibsatu = bsatu1 + bsatu2;

        //lanjuTan
        double bebesar = (180 / System.Math.PI * ((koreksibnol + koreksibsatu * tautau) / System.Math.Pow(10, 8))) * 3600 * -1;
        double beta = segbet + bebesar;
        double proalpha1 = System.Math.Sin(System.Math.PI / 180 * (delta2)) * System.Math.Cos(System.Math.PI / 180 * (epsilon3 + 0.00256
                * System.Math.Cos(System.Math.PI / 180 * (omega2)))) - System.Math.Tan(System.Math.PI / 180 * (beta / 3600)) * System.Math.Sin(System.Math.PI / 180 * (epsilon3
                + 0.00256 * System.Math.Cos(System.Math.PI / 180 * (omega2))));
        double proalpha2 = System.Math.Cos(System.Math.PI / 180 * (delta2));
        double alpha2 = MOD((180 / System.Math.PI * (System.Math.Atan2(proalpha1, proalpha2))), 360);
        double prodekm = System.Math.Sin(System.Math.PI / 180 * (beta / 3600)) * System.Math.Cos(System.Math.PI / 180 * (epsilon3))
                + System.Math.Cos(System.Math.PI / 180 * (beta / 3600)) * System.Math.Sin(System.Math.PI / 180 * (epsilon3)) * System.Math.Sin(System.Math.PI / 180 * (delta2));
        double dekm = 180 / System.Math.PI * (System.Math.Asin(prodekm));
        double elnol = MOD((280.4664567 + 360007.6982779 * tautau + 0.03032028
                * System.Math.Pow(tautau, 2) + System.Math.Pow(tautau, 3) / 49931 - System.Math.Pow(tautau, 4) / 15299
                - System.Math.Pow(tautau, 5) / 1988000), 360);
        double equation = (elnol - 0.0057183 - alpha2 + segpeg * System.Math.Cos(System.Math.PI / 180 * (segep))) * 4;
        double sdm = 959.63 / 60 / erbesar;


        //DATA BULAN-----
        double elbesarb = MOD((218.3164591 + 481267.88134236 * tete - 0.0013268
                * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 538841 - System.Math.Pow(tete, 4) / 65194000), 360);

        double debesarb = MOD((297.8502042 + 445267.1115168
                * tete - 0.00163 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 545868 - System.Math.Pow(tete, 4) / 113065000), 360);

        double embesarb = MOD((357.5291092 + 35999.0502909 * tete - 0.0001536
                * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 24490000), 360);

        double emaksenb = MOD((134.9634114 + 477198.8676313
                * tete + 0.008997 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 69699 - System.Math.Pow(tete, 4) / 14712000), 360);

        double efbesarb = MOD((93.2720993 + 483202.0175273 * tete - 0.0034029
                * System.Math.Pow(tete, 2) - System.Math.Pow(tete, 3) / 3526000 + System.Math.Pow(tete, 4) / 863310000), 360);

        double asatu = MOD((119.75 + 131.849 * tete), 360);
        double adua = MOD((53.09 + 479264.29 * tete), 360);
        double atiga = MOD((313.45 + 481266.484 * tete), 360);
        double ebesarb = 1 - 0.002516 * tete - 0.0000074 * System.Math.Pow(tete, 2);
        double addi1 = 3958 * System.Math.Sin(System.Math.PI / 180 * (asatu)) + 1962
                * System.Math.Sin(System.Math.PI / 180 * (elbesarb - efbesarb)) + 318 * System.Math.Sin(System.Math.PI / 180 * (adua));
        double addi2 = -2235 * System.Math.Sin(System.Math.PI / 180 * (elbesarb)) + 382 * System.Math.Sin(System.Math.PI / 180 * (atiga))
                + 175 * System.Math.Sin(System.Math.PI / 180 * (asatu - efbesarb)) + 175 * System.Math.Sin(System.Math.PI / 180 * (asatu + efbesarb)) + 127
                * System.Math.Sin(System.Math.PI / 180 * (elbesarb - emaksenb)) - 115 * System.Math.Sin(System.Math.PI / 180 * (elbesarb + emaksenb));


        //koreksiperiodikbujur
        double corb1 = 6288774 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb2 = 1274027 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb3 = 658314 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb4 = 213618 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb5 = -185116 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb6 = -114332 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double corb7 = 58793 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb8 = 57066 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb9 = 53322 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb10 = 45758 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb11 = -40923 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb12 = -34720 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb13 = -30383 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb14 = 15327 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb15 = -12528 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double corb16 = 10980 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb17 = 10675 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb18 = 10034 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb19 = 8548 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb20 = -7888 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb21 = -6766 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb22 = -5163 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb23 = 4987 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb24 = 4036 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb25 = 3994 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb26 = 3861 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb27 = 3665 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb28 = -2689 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb29 = -2602 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double corb30 = 2390 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb31 = -2348 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb32 = 2236 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb33 = -2120 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb34 = -2069 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb35 = 2048 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb36 = -1773 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb37 = -1595 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double corb38 = 1215 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb39 = -1110 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double corb40 = -892 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(3 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb41 = -810 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb42 = 759 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb43 = -713 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb44 = -700 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb45 = 691 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb46 = 596 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb47 = 549 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb48 = 537 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 4 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb49 = 520 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb50 = -487 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb51 = -399 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb52 = -381 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double corb53 = 351 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb54 = -340 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(3 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb55 = 330 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb56 = 327 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb57 = -323 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb58 = 299 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double corb59 = 294 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double jumlahcorb1 = corb1 + corb2 + corb3 + corb4 + corb5 + corb6 + corb7 + corb8 + corb9 + corb10
                + corb11 + corb12 + corb13 + corb14 + corb15 + corb16 + corb17 + corb18 + corb19 + corb20
                + corb21 + corb22 + corb23 + corb24 + corb25 + corb26 + corb27 + corb28 + corb29 + corb30
                + corb31 + corb32 + corb33 + corb34 + corb35 + corb36 + corb37 + corb38 + corb39 + corb40
                + corb41 + corb42 + corb43 + corb44 + corb45 + corb46 + corb47 + corb48 + corb49 + corb50
                + corb51 + corb52 + corb53 + corb54 + corb55 + corb56 + corb57 + corb58 + corb59;
        double esegsatu = (jumlahcorb1 + addi1) / 1000000;

        //koreksiperiodiklinTang
        double corc1 = 5128122 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc2 = 280602 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc3 = 277693 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc4 = 173237 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc5 = 55413 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc6 = 46271 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc7 = 32573 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc8 = 17198 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc9 = 9266 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc10 = 8822 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc11 = 8216 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc12 = 4324 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc13 = 4200 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc14 = -3359 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc15 = 2463 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc16 = 2211 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc17 = 2065 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc18 = -1870 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc19 = 1828 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc20 = -1794 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc21 = -1749 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 3 * System.Math.PI / 180 * (efbesarb));
        double corc22 = -1565 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc23 = -1491 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc24 = -1475 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc25 = -1410 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc26 = -1344 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc27 = -1335 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc28 = 1107 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 3 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc29 = 1021 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc30 = 833 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc31 = 777 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -3 * System.Math.PI / 180 * (efbesarb));
        double corc32 = 671 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc33 = 607 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -3 * System.Math.PI / 180 * (efbesarb));
        double corc34 = 596 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc35 = 491 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc36 = -451 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc37 = 439 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 3 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc38 = 422 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc39 = 421 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -3 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc40 = -366 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc41 = -351 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc42 = 331 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc43 = 315 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc44 = 302 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc45 = -283 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 3 * System.Math.PI / 180 * (efbesarb));
        double corc46 = -229 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc47 = 223 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc48 = 223 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc49 = -220 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc50 = -220 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc51 = -185 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc52 = 181 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc53 = -177 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Sin(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double corc54 = 176 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc55 = 166 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc56 = -164 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc57 = 132 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc58 = -119 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Sin(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc59 = 115 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Sin(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -1 * System.Math.PI / 180 * (efbesarb));
        double corc60 = 107 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Sin(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 1 * System.Math.PI / 180 * (efbesarb));
        double jumlahcorc1 = corc1 + corc2 + corc3 + corc4 + corc5 + corc6 + corc7 + corc8 + corc9 + corc10
                + corc11 + corc12 + corc13 + corc14 + corc15 + corc16 + corc17 + corc18 + corc19 + corc20
                + corc21 + corc22 + corc23 + corc24 + corc25 + corc26 + corc27 + corc28 + corc29 + corc30
                + corc31 + corc32 + corc33 + corc34 + corc35 + corc36 + corc37 + corc38 + corc39 + corc40
                + corc41 + corc42 + corc43 + corc44 + corc45 + corc46 + corc47 + corc48 + corc49 + corc50
                + corc51 + corc52 + corc53 + corc54 + corc55 + corc56 + corc57 + corc58 + corc59 + corc60;
        double esegb = (jumlahcorc1 + addi2) / 1000000;


        //koreksi periodikjarak
        double cord1 = -20905355 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord2 = -3699111 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord3 = -2955968 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord4 = -569925 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord5 = 246158 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord6 = -204586 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord7 = -170733 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord8 = -152138 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord9 = -129620 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord10 = 108743 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord11 = 104755 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord12 = 79661 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double cord13 = 48888 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord14 = -34782 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord15 = 30824 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord16 = 24208 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord17 = -23210 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord18 = -21636 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord19 = -16675 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(1 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord20 = 14403 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -3 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord21 = -12831 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord22 = -11650 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord23 = -10445 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord24 = 10321 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double cord25 = 10056 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord26 = -9884 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord27 = 8752 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double cord28 = -8379 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord29 = -7003 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord30 = 6322 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord31 = 5751 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord32 = -4950 * (System.Math.Pow(ebesarb, (System.Math.Abs(-2)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + -2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord34 = -4421 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 2 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double cord33 = 4130 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + -2 * System.Math.PI / 180 * (efbesarb));
        double cord35 = -3958 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord36 = 3258 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(3 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord37 = -3149 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 2 * System.Math.PI / 180 * (efbesarb));
        double cord38 = 2616 * (System.Math.Pow(ebesarb, (System.Math.Abs(1)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 1 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord39 = 2354 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Cos(2 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord40 = -2117 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + -1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord41 = -1897 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord42 = -1739 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(1 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + -2 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord43 = -1571 * (System.Math.Pow(ebesarb, (System.Math.Abs(-1)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + -1 * System.Math.PI / 180 * (embesarb) + 0 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord44 = -1423 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(4 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord45 = 1165 * (System.Math.Pow(ebesarb, (System.Math.Abs(2)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 2 * System.Math.PI / 180 * (embesarb) + 1 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double cord46 = -1117 * (System.Math.Pow(ebesarb, (System.Math.Abs(0)))) * System.Math.Cos(0 * System.Math.PI / 180 * (debesarb) + 0 * System.Math.PI / 180 * (embesarb) + 4 * System.Math.PI / 180 * (emaksenb) + 0 * System.Math.PI / 180 * (efbesarb));
        double jumlahcord1 = cord1 + cord2 + cord3 + cord4 + cord5 + cord6 + cord7 + cord8 + cord9 + cord10
                + cord11 + cord12 + cord13 + cord14 + cord15 + cord16 + cord17 + cord18 + cord19 + cord20
                + cord21 + cord22 + cord23 + cord24 + cord25 + cord26 + cord27 + cord28 + cord29 + cord30
                + cord31 + cord32 + cord33 + cord34 + cord35 + cord36 + cord37 + cord38 + cord39 + cord40
                + cord41 + cord42 + cord43 + cord44 + cord45 + cord46;
        double esegr = jumlahcord1 / 1000;

        double lambdab = MOD((elbesarb + esegsatu), 360);
        double betab = esegb;
        double segb = 385000.56 + esegr;
        double phib = 180 / System.Math.PI * (System.Math.Asin(6378.14 / segb));
        double lambdaaksen = MOD((lambdab + 0.00461), 360);
        double alphab = MOD((180 / System.Math.PI * (System.Math.Atan2((System.Math.Sin(System.Math.PI / 180 * (lambdaaksen)) * System.Math.Cos(System.Math.PI / 180 * (epsilon3)) - System.Math.Tan(System.Math.PI / 180 * (betab))
                * System.Math.Sin(System.Math.PI / 180 * (epsilon3))), (System.Math.Cos(System.Math.PI / 180 * (lambdaaksen)))))), 360);
        double deltab = 180 / System.Math.PI * (System.Math.Asin(System.Math.Sin(System.Math.PI / 180 * (betab)) * System.Math.Cos(System.Math.PI / 180 * (epsilon3))
                + System.Math.Cos(System.Math.PI / 180 * (betab)) * System.Math.Sin(System.Math.PI / 180 * (epsilon3)) * System.Math.Sin(System.Math.PI / 180 * (lambdaaksen))));
        double eskecil = 180 / System.Math.PI * (System.Math.Asin(0.272481 * System.Math.Sin(System.Math.PI / 180 * (phib)))) * 60;
        double piala = MOD((180 / System.Math.PI * (System.Math.Acos(System.Math.Sin(System.Math.PI / 180 * (dekm)) * System.Math.Sin(System.Math.PI / 180 * (deltab)) + System.Math.Cos(System.Math.PI / 180 * (dekm)) * System.Math.Cos(System.Math.PI / 180 * (deltab)) * System.Math.Cos(System.Math.PI / 180 * (alpha2 - alphab))))), 180);
        double ikecil = MOD((180 / System.Math.PI * (System.Math.Atan((erbesar * System.Math.Sin(System.Math.PI / 180 * (piala))) / (segb / 150000000 - erbesar * System.Math.Cos(System.Math.PI / 180 * (piala)))))), 180);
        double kkecil = (1 + System.Math.Cos(System.Math.PI / 180 * (ikecil))) / 2;
        double ckecil = MOD((180 / System.Math.PI * (System.Math.Atan2((System.Math.Cos(System.Math.PI / 180 * (dekm))
                * System.Math.Sin(System.Math.PI / 180 * (alpha2 - alphab))), (System.Math.Sin(System.Math.PI / 180 * (dekm)) * System.Math.Cos(System.Math.PI / 180 * (deltab))
                - System.Math.Cos(System.Math.PI / 180 * (dekm)) * System.Math.Sin(System.Math.PI / 180 * (deltab)) * System.Math.Cos(System.Math.PI / 180 * (alpha2 - alphab)))))), 360);



        // Variable data Bulan dan nomer urut arrays
        double bApp_Longitude = lambdaaksen; //1
        double bApp_Latitude = betab; //2
        double bApp_Right_Ascension = alphab; //3
        double bApp_Declination = deltab; //4
        double bHorizontal_Parallax = phib; //5
        double bSemi_Diameter = eskecil; //6
        double bAngle_Bright_Limb = ckecil; //7
        double bFraction_Illumination = 100 * kkecil; //8

        // Variable data Matahari dan nomer urut arrays
        double mEcliptic_Longitude = delta2; //9
        double mEcliptic_Latitude = beta; //10
        double mApp_Right_Ascension = alpha2; //11
        double mApp_Declination = dekm; //12
        double mTrue_Geocentric_DisTance = erbesar; //13
        double mSemi_Diameter = sdm; //14
        double mTrue_Obliquity = epsilon3; //15
        double mEquation_of_Time = equation; //16

        // mengembalikan Hasil Perhitungan dengan aryys
        return new double[]
        {
            0,bApp_Longitude,bApp_Latitude,bApp_Right_Ascension,bApp_Declination,bHorizontal_Parallax,bSemi_Diameter,bAngle_Bright_Limb,bFraction_Illumination,mEcliptic_Longitude,mEcliptic_Latitude,mApp_Right_Ascension,mApp_Declination,mTrue_Geocentric_DisTance,mSemi_Diameter,mTrue_Obliquity,mEquation_of_Time
        };

    }

    //-----------------MENGHITUNG ELONGASI BULAN-MATAHARI-------------------------------------------------------//

    public double[] elongasi_BlnMth(double LT, double BT, int thn, int bln, int tgl, double jam, double mnt, double tz)
    {
        //variable DATE
        int tanggal = tgl;
        int bulan = bln;
        int tahun = thn;
        double timezone = tz;

        // variable Time
        double jam1 = jam;
        double menit1 = mnt;

        // variable koordinat
        double lt = LT;
        double bt = BT;

        // Azimut dan Altitude Bulan
        double azB = (Az_AltBulan(lt, bt, tahun, bulan, tanggal, jam1, menit1, timezone)[1]) * (System.Math.PI / 180);
        double altB = (Az_AltBulan(lt, bt, tahun, bulan, tanggal, jam1, menit1, timezone)[2]) * (System.Math.PI / 180);

        //Azimuth dan Altitude Matahari
        double azM = (Az_AltMatahari(lt, bt, tahun, bulan, tanggal, jam1, menit1, timezone)[1]) * (System.Math.PI / 180);
        double altM = (Az_AltMatahari(lt, bt, tahun, bulan, tanggal, jam1, menit1, timezone)[2]) * (System.Math.PI / 180);

        //elongasi Bulan ke Matahari
        double Elong_COS = System.Math.Sin(altB) * System.Math.Sin(altM) + System.Math.Cos(altB) * System.Math.Cos(altM) * System.Math.Cos(azB - azM);
        double Elong = System.Math.Acos(Elong_COS) * (180 / System.Math.PI);

        return new double[] { 0, Elong, Elong_COS };
    }

    //------------------MENGHITUNG AZIMUTH DAN ALTITUDE MATAHARI------------------------------------------------//
    public double[] Az_AltMatahari(double LT, double BT, int thn, int bln, int tgl, double jam, double mnt, double tz){
		
		//variable DATE
        int tanggal = tgl;
        int bulan = bln;
        int tahun = thn;
        double timezone = tz;

        // variable Time
        double jam1 = jam;
        double menit1 = mnt;
        double detik1 = 0;
        double pukul_keJD = (jam1 * 3600 + (menit1 * 60) + detik1) / 86400;

        // Variable koordinat
        double lintangT = LT;
        double lintang_r = System.Math.PI / 180 * (LT);

        double bujur = BT;

        // waktu lokal ke UT
        int UT = (int)(jam1 - timezone);

        // hitung nilai julian
        if (bulan <= 2) { bulan += 12; tahun -= 1; }
        int A = 0;
        int B = 0;

        // koreksi kalender gregorian
        if (tahun > 1582)
        {
            A = (tahun / 100);
            B = 2 + (A / 4) - A;
        }
        double JD = 1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24);
        double JD_UT = (1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24));

        // menghitung DeltaT
        double waktu = (jam1 + menit1 / 60 + 0 / 3600) - timezone;
        double delta_T = 0;

        if (tahun < -500)
        {
            delta_T = (-20 + 32 * System.Math.Pow((tahun / 100 - 18.2), 2)) / 3600 / 24;
        }
        else if (tahun >= -500 && tahun < 500)
        {
            delta_T = (10583.6 - 1014.41 * (tahun / 100) + 33.78311 * System.Math.Pow((tahun / 100), 2) - 5) / 3600 / 24;
        }
        else if (tahun >= 500 && tahun < 1600)
        {
            delta_T = (1574.2 - 556.01 * (tahun / 100 - 10) + 71.23472 * System.Math.Pow((tahun / 100 - 10), 2) + 0.319781 * System.Math.Pow((tahun / 100 - 10), 3) - 0.8503463 * System.Math.Pow((tahun / 100 - 10), 4) - 0.00505998 * System.Math.Pow((tahun / 100 - 10), 5) + 0.0083572073 * System.Math.Pow((tahun / 100 - 10), 6)) / 3600 / 24;
        }
        else if (tahun >= 1600 && tahun < 1700)
        {
            delta_T = (120 - 0.9808 * (tahun - 1600) - 0.01532 * System.Math.Pow((tahun - 1600), 2) + System.Math.Pow((tahun - 1600), 3) / 7129) / 3600 / 24;
        }
        else if (tahun >= 1700 && tahun < 1800)
        {
            delta_T = (8.83 + 0.1603 * (tahun - 1700) - 0.0059285 * System.Math.Pow((tahun - 1700), 2) + 0.00013336 * System.Math.Pow((tahun - 1700), 3) - System.Math.Pow((tahun - 1700), 4) / 1174000) / 3600 / 24;
        }
        else if (tahun >= 1800 && tahun < 1860)
        {
            delta_T = (13.72 - 0.332447 * (tahun - 1800) + 0.0068612 * System.Math.Pow((tahun - 1800), 2) + 0.0041116 * System.Math.Pow((tahun - 1800), 3) - 0.00037436 * System.Math.Pow((tahun - 1800), 4) + 0.0000121272 * System.Math.Pow((tahun - 1800), 5) - 0.0000001699 * System.Math.Pow((tahun - 1800), 6) + 0.000000000875 * System.Math.Pow((tahun - 1800), 7)) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1860 && tahun < 1900)
        {
            delta_T = (7.62 + 0.5737 * (tahun - 1860) - 0.251754 * System.Math.Pow((tahun - 1860), 2) + 0.01680668 * System.Math.Pow((tahun - 1860), 3) - 0.0004473624 * System.Math.Pow((tahun - 1860), 4) + System.Math.Pow((tahun - 1850), 5) / 233174) / 3600 / 24;
        }
        else if (tahun >= 1900 && tahun < 1920)
        {
            delta_T = (-2.79 + 1.494119 * (tahun - 1900) - 0.0598939 * System.Math.Pow((tahun - 1900), 2) + 0.0061966 * System.Math.Pow((tahun - 1900), 3) - 0.000197 * System.Math.Pow((tahun - 1900), 4)) / 3600 / 24;
        }
        else if (tahun >= 1920 && tahun < 1941)
        {
            delta_T = (21.2 + 0.84493 * (tahun - 1920) - 0.0761 * System.Math.Pow((tahun - 1920), 2) + 0.0020936 * System.Math.Pow((tahun - 1920), 3)) / 3600 / 24;
        }
        else if (tahun >= 1941 && tahun < 1961)
        {
            delta_T = (29.07 + 0.407 * (tahun - 1950) - System.Math.Pow((tahun - 1950), 2) / 233 + System.Math.Pow((tahun - 1950), 3) / 2547) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1961 && tahun < 1986)
        {
            delta_T = (45.45 + 1.067 * (tahun - 1975) - System.Math.Pow((tahun - 1975), 2) / 260 - System.Math.Pow((tahun - 1975), 3) / 718) / 3600 / 24;
        }
        else if (tahun >= 1986 && tahun < 2005)
        {
            delta_T = (63.86 + 0.3345 * (tahun - 2000) - 0.060374 * System.Math.Pow((tahun - 2000), 2) + 0.0017275 * System.Math.Pow((tahun - 2000), 3) + 0.000651814 * System.Math.Pow((tahun - 2000), 4) + 0.00002373599 * System.Math.Pow((tahun - 2000), 5)) / 3600 / 24;
        }
        else if (tahun >= 2005 && tahun < 2050)
        {
            delta_T = (62.92 + 0.32217 * ((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000) + 0.005589 * System.Math.Pow(((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000), 2)) / 3600 / 24;
        }
        else if (tahun >= 2050 && tahun < 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2) - 0.5628 * (2150 - tahun)) / 3600 / 24;
        }
        else if (tahun >= 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2)) / 3600 / 24;
        }
        else
        {
            delta_T = 0.0000;
        };

        //JDE waktu TD(Dynamical time)
        double jde = JD_UT + delta_T;

        double T_UT = (JD_UT - 2451545) / 36525;
        double T_TD = (jde - 2451545) / 36525;
        double tau = T_TD / 10;

        // Greenwich sideral time
        double gst0 = 6.6973745583 + 2400.0513369072 * T_TD + 0.0000258622 * T_TD * T_TD;

        //fungsi MOD(?) kalou di Excel/LibreCalc
        if (gst0 < 0)
        {
            while (gst0 < 0)
            {
                gst0 += 24;
            }
        }
        else if (gst0 > 24)
        {
            while (gst0 > 24)
            {
                gst0 -= 24;
            }
        }

        double gstUT = gst0 + 1.0027379035 * UT;
        double gstLokal = ((gst0 + ((jam1 + (menit1 / 60) + (detik1 / 3600) - timezone)) * 1.00273790935)) % 24;
        if (gstUT >= 24) gstUT -= 24;
        gstLokal /= 15;

        //lokal sideral time
        double LST = 0;
        if (bujur > 0) LST = gstLokal + (bujur / 15);
        else LST = gstLokal - (bujur / 15);

        if (LST >= 24) LST -= 24;
        double gstpukul = (280.46061837 + 360.98564736629 * (JD_UT - 2451545) + 0.000387933 * T_UT * T_UT - T_UT * T_UT * T_UT / 38710000) % 360;
        if (gstpukul < 0) gstLokal += 360;
        gstpukul /= 15;

        //--- Menghitung DELTA PSI dan NUTASI ----------------
        double tete = T_TD;

        double debesar = MOD((297.85036 + 445267.11148 * tete - 0.0019142 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 189474), 360);
        double embesar = MOD((357.52772 + 35999.05034 * tete - 0.0001603 * System.Math.Pow(tete, 2) - System.Math.Pow(tete, 3) / 300000), 360);
        double emaksen = MOD((134.96298 + 477198.867398 * tete + 0.0086972 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 56250), 360);
        double efbesar = MOD((93.27191 + 483202.017538 * tete - 0.0036825 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 327270), 360);
        double omega2 = MOD((125.04452 - 1934.136261 * tete + 0.0020708 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 450000), 360);
        double u = tete / 100;
        double epsilonZero = 23.43929111 - (4680.93 * u - 1.55 * System.Math.Pow(u, 2) + 1999.25 * System.Math.Pow(u, 3) - 51.38 * System.Math.Pow(u, 4) - 249.67 * System.Math.Pow(u, 5) - 39.05 * System.Math.Pow(u, 6) + 7.12 * System.Math.Pow(u, 7) + 27.87 * System.Math.Pow(u, 8) + 5.79 * System.Math.Pow(u, 9) + 2.45 * System.Math.Pow(u, 10)) / 3600;


        //koreksi ASI
        double korn1 = (-171996 + -174.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn2 = (-13187 + -1.6 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn3 = (-2274 + -0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn4 = (2062 + 0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn5 = (1426 + -3.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn6 = (712 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn7 = (517 + 1.2 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn8 = (-386 + -0.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn9 = (217 + -0.5 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn10 = (129 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn11 = (63 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn12 = (-58 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn13 = (17 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn14 = (-16 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn15 = (-301 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn16 = (-158 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn17 = (123 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn18 = (63 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn19 = (-59 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn20 = (-51 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn21 = (48 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn22 = (46 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn23 = (-38 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn24 = (-31 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn25 = (29 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn26 = (29 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn27 = (26 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn28 = (-22 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn29 = (21 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn30 = (16 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn31 = (-15 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn32 = (-13 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn33 = (-12 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn34 = (11 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn35 = (-10 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn36 = (-8 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn37 = (7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn38 = (-7 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn39 = (-7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn40 = (-7 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn41 = (6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn42 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn43 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn44 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn45 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn46 = (5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn47 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn48 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn49 = (-5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn50 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn51 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn52 = (4 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn53 = (-4 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn54 = (-4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn55 = (-4 + 0 * tete) * System.Math.Sin(1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn56 = (3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn57 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn58 = (-3 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn59 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn60 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn61 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn62 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 3 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn63 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));

        double jumlahkorn = korn1 + korn2 + korn3 + korn4 + korn5 + korn6 + korn7 + korn8 + korn9 + korn10 + korn11 + korn12 + korn13 + korn14 + korn15 + korn16 + korn17 + korn18 + korn19 + korn20
                + korn21 + korn22 + korn23 + korn24 + korn25 + korn26 + korn27 + korn28 + korn29 + korn30
                + korn31 + korn32 + korn33 + korn34 + korn35 + korn36 + korn37 + korn38 + korn39 + korn40
                + korn41 + korn42 + korn43 + korn44 + korn45 + korn46 + korn47 + korn48 + korn49 + korn50
                + korn51 + korn52 + korn53 + korn54 + korn55 + korn56 + korn57 + korn58 + korn59 + korn60 + korn61 + korn62 + korn63;

        //lanjuTan koreksi ASI
        double segpeg = jumlahkorn / 10000 / 3600;
        double deltaPsi = segpeg;

        //koreksi delta epsilon
        double kord1 = (92025 + 8.9 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord2 = (5736 + -3.1 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord3 = (977 + -0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord4 = (-895 + 0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord5 = (54 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord6 = (224 + -0.6 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord7 = (129 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord8 = (-95 + 0.3 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord9 = (-7 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord10 = (200 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord11 = (-70 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord12 = (-53 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord13 = (-33 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord14 = (26 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord15 = (32 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord16 = (27 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord17 = (-24 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord18 = (16 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord19 = (13 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord20 = (-12 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord21 = (-10 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord22 = (-8 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord23 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord24 = (9 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord25 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord26 = (6 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord27 = (5 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord28 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord29 = (-3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord30 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord31 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord32 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord33 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord34 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord35 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord36 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord37 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord38 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double jumlahkord = kord1 + kord2 + kord3 + kord4 + kord5 + kord6 + kord7 + kord8 + kord9 + kord10
                + kord11 + kord12 + kord13 + kord14 + kord15 + kord16 + kord17 + kord18 + kord19 + kord20
                + kord21 + kord22 + kord23 + kord24 + kord25 + kord26 + kord27 + kord28 + kord29 + kord30
                + kord31 + kord32 + kord33 + kord34 + kord35 + kord36 + kord37 + kord38;

        //lanjuTan koreksi delta epsilon
        double segep = jumlahkord / 10000 / 3600;
        double epsilon = epsilonZero + segep;
        double epsilon_r = System.Math.PI / 180 * (epsilon);

        double gstnampak = gstpukul + deltaPsi * System.Math.Cos(epsilon_r) / 15;
        double lstnampak = (gstnampak + bujur / 15) % 24;
        if (lstnampak < 0) lstnampak += 24;

        // mencari nilai Deklinasi
        double deltaMatahari = Data_Algo_JeanMeeus(tahun, bulan, tanggal, System.Convert.ToInt32(jam1), System.Convert.ToInt32(menit1),System.Convert.ToInt32(timezone))[12];
		double deltaM_r = System.Math.PI / 180 * (deltaMatahari);
		
		// mencari nilai Right Ascensio
		double alphaMatahari = Data_Algo_JeanMeeus(tahun,bulan,tanggal, System.Convert.ToInt32(jam1), System.Convert.ToInt32(menit1), System.Convert.ToInt32(timezone))[11];
		
		// menghitung Sudut Waktu / Hour angel
		double hourAngleM=lstnampak*15-alphaMatahari;
        double hourAngleM_r=System.Math.PI / 180 *(hourAngleM);
		
		// menghitung Azimuth dan Altitude 
		double azimuthM_selAtan=180/System.Math.PI *(System.Math.Atan2(System.Math.Sin(hourAngleM_r),System.Math.Cos(hourAngleM_r)*System.Math.Sin(lintang_r)-System.Math.Tan(deltaM_r)*System.Math.Cos(lintang_r)));
        double azimuthMatahari=(azimuthM_selAtan+180)%360;

        double altitudeM=180/System.Math.PI *(System.Math.Asin(System.Math.Sin(lintang_r)*System.Math.Sin(deltaM_r)+System.Math.Cos(lintang_r)*System.Math.Cos(deltaM_r)*System.Math.Cos(hourAngleM_r)));
        
		//Variable hasil perhitungan dan nomer urut arrays
		double Azimuth = azimuthMatahari; //1
		double Altitude = altitudeM; //2
		
		// mengembalikan hasil perhitungan dengan bentuk arrays
		return new double[]{
			0, Azimuth,Altitude
		};
		
	}

    
    
    
    //------------------MENGHITUNG AZIMUTH DAN ALTITUDE BULAN------------------------------------------------//
    public double [] Az_AltBulan(double LT, double BT, int thn, int bln, int tgl, double jam, double mnt, double tz)
    {
        //variable DATE
        int tanggal = tgl;
        int bulan = bln;
        int tahun = thn;
        double timezone = tz;

        // variable Time
        double jam1 = jam;
        double menit1 = mnt;
        double detik1 = 0;
        double pukul_keJD = (jam1 * 3600 + (menit1 * 60) + detik1) / 86400;

        // Variable koordinat
        double lintangT = LT;
        double lintang_r = System.Math.PI / 180 * (LT);

        double bujur = BT;

        // waktu lokal ke UT
        int UT = (int)(jam1 - timezone);

        // hitung nilai julian
        if (bulan <= 2) { bulan += 12; tahun -= 1; }
        int A = 0;
        int B = 0;

        // koreksi kalender gregorian
        if (tahun > 1582)
        {
            A = (tahun / 100);
            B = 2 + (A / 4) - A;
        }
        double JD = 1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24);
        double JD_UT = (1720994.5 + (int)(365.25 * tahun) + (int)(30.60001 * (bulan + 1)) + B + tanggal + ((jam1 + menit1 / 60 + detik1 / 3600) / 24) - (timezone / 24));

        // menghitung DeltaT
        double waktu = (jam1 + menit1 / 60 + 0 / 3600) - timezone;
        double delta_T = 0;

        if (tahun < -500)
        {
            delta_T = (-20 + 32 * System.Math.Pow((tahun / 100 - 18.2), 2)) / 3600 / 24;
        }
        else if (tahun >= -500 && tahun < 500)
        {
            delta_T = (10583.6 - 1014.41 * (tahun / 100) + 33.78311 * System.Math.Pow((tahun / 100), 2) - 5) / 3600 / 24;
        }
        else if (tahun >= 500 && tahun < 1600)
        {
            delta_T = (1574.2 - 556.01 * (tahun / 100 - 10) + 71.23472 * System.Math.Pow((tahun / 100 - 10), 2) + 0.319781 * System.Math.Pow((tahun / 100 - 10), 3) - 0.8503463 * System.Math.Pow((tahun / 100 - 10), 4) - 0.00505998 * System.Math.Pow((tahun / 100 - 10), 5) + 0.0083572073 * System.Math.Pow((tahun / 100 - 10), 6)) / 3600 / 24;
        }
        else if (tahun >= 1600 && tahun < 1700)
        {
            delta_T = (120 - 0.9808 * (tahun - 1600) - 0.01532 * System.Math.Pow((tahun - 1600), 2) + System.Math.Pow((tahun - 1600), 3) / 7129) / 3600 / 24;
        }
        else if (tahun >= 1700 && tahun < 1800)
        {
            delta_T = (8.83 + 0.1603 * (tahun - 1700) - 0.0059285 * System.Math.Pow((tahun - 1700), 2) + 0.00013336 * System.Math.Pow((tahun - 1700), 3) - System.Math.Pow((tahun - 1700), 4) / 1174000) / 3600 / 24;
        }
        else if (tahun >= 1800 && tahun < 1860)
        {
            delta_T = (13.72 - 0.332447 * (tahun - 1800) + 0.0068612 * System.Math.Pow((tahun - 1800), 2) + 0.0041116 * System.Math.Pow((tahun - 1800), 3) - 0.00037436 * System.Math.Pow((tahun - 1800), 4) + 0.0000121272 * System.Math.Pow((tahun - 1800), 5) - 0.0000001699 * System.Math.Pow((tahun - 1800), 6) + 0.000000000875 * System.Math.Pow((tahun - 1800), 7)) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1860 && tahun < 1900)
        {
            delta_T = (7.62 + 0.5737 * (tahun - 1860) - 0.251754 * System.Math.Pow((tahun - 1860), 2) + 0.01680668 * System.Math.Pow((tahun - 1860), 3) - 0.0004473624 * System.Math.Pow((tahun - 1860), 4) + System.Math.Pow((tahun - 1850), 5) / 233174) / 3600 / 24;
        }
        else if (tahun >= 1900 && tahun < 1920)
        {
            delta_T = (-2.79 + 1.494119 * (tahun - 1900) - 0.0598939 * System.Math.Pow((tahun - 1900), 2) + 0.0061966 * System.Math.Pow((tahun - 1900), 3) - 0.000197 * System.Math.Pow((tahun - 1900), 4)) / 3600 / 24;
        }
        else if (tahun >= 1920 && tahun < 1941)
        {
            delta_T = (21.2 + 0.84493 * (tahun - 1920) - 0.0761 * System.Math.Pow((tahun - 1920), 2) + 0.0020936 * System.Math.Pow((tahun - 1920), 3)) / 3600 / 24;
        }
        else if (tahun >= 1941 && tahun < 1961)
        {
            delta_T = (29.07 + 0.407 * (tahun - 1950) - System.Math.Pow((tahun - 1950), 2) / 233 + System.Math.Pow((tahun - 1950), 3) / 2547) / 3600 / 24 / 3600 / 24;
        }
        else if (tahun >= 1961 && tahun < 1986)
        {
            delta_T = (45.45 + 1.067 * (tahun - 1975) - System.Math.Pow((tahun - 1975), 2) / 260 - System.Math.Pow((tahun - 1975), 3) / 718) / 3600 / 24;
        }
        else if (tahun >= 1986 && tahun < 2005)
        {
            delta_T = (63.86 + 0.3345 * (tahun - 2000) - 0.060374 * System.Math.Pow((tahun - 2000), 2) + 0.0017275 * System.Math.Pow((tahun - 2000), 3) + 0.000651814 * System.Math.Pow((tahun - 2000), 4) + 0.00002373599 * System.Math.Pow((tahun - 2000), 5)) / 3600 / 24;
        }
        else if (tahun >= 2005 && tahun < 2050)
        {
            delta_T = (62.92 + 0.32217 * ((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000) + 0.005589 * System.Math.Pow(((tahun + bulan / 12 + tanggal / 365.25 + waktu / 24 / 365.25) - 2000), 2)) / 3600 / 24;
        }
        else if (tahun >= 2050 && tahun < 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2) - 0.5628 * (2150 - tahun)) / 3600 / 24;
        }
        else if (tahun >= 2150)
        {
            delta_T = (-20 + 32 * System.Math.Pow(((tahun - 1820) / 100), 2)) / 3600 / 24;
        }
        else
        {
            delta_T = 0.0000;
        };

        //JDE waktu TD(Dynamical time)
        double jde = JD_UT + delta_T;

        double T_UT = (JD_UT - 2451545) / 36525;
        double T_TD = (jde - 2451545) / 36525;
        double tau = T_TD / 10;

        // Greenwich sideral time
        double gst0 = 6.6973745583 + 2400.0513369072 * T_TD + 0.0000258622 * T_TD * T_TD;

        //fungsi MOD(?) kalou di Excel/LibreCalc
        if (gst0 < 0)
        {
            while (gst0 < 0)
            {
                gst0 += 24;
            }
        }
        else if (gst0 > 24)
        {
            while (gst0 > 24)
            {
                gst0 -= 24;
            }
        }

        double gstUT = gst0 + 1.0027379035 * UT;
        double gstLokal = ((gst0 + ((jam1 + (menit1 / 60) + (detik1 / 3600) - timezone)) * 1.00273790935)) % 24;
        if (gstUT >= 24) gstUT -= 24;
        gstLokal /= 15;

        //lokal sideral time
        double LST = 0;
        if (bujur > 0) LST = gstLokal + (bujur / 15);
        else LST = gstLokal - (bujur / 15);

        if (LST >= 24) LST -= 24;
        double gstpukul = (280.46061837 + 360.98564736629 * (JD_UT - 2451545) + 0.000387933 * T_UT * T_UT - T_UT * T_UT * T_UT / 38710000) % 360;
        if (gstpukul < 0) gstLokal += 360;
        gstpukul /= 15;

        //--- Menghitung DELTA PSI dan NUTASI ----------------
        double tete = T_TD;

        double debesar = MOD((297.85036 + 445267.11148 * tete - 0.0019142 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 189474), 360);
        double embesar = MOD((357.52772 + 35999.05034 * tete - 0.0001603 * System.Math.Pow(tete, 2) - System.Math.Pow(tete, 3) / 300000), 360);
        double emaksen = MOD((134.96298 + 477198.867398 * tete + 0.0086972 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 56250), 360);
        double efbesar = MOD((93.27191 + 483202.017538 * tete - 0.0036825 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 327270), 360);
        double omega2 = MOD((125.04452 - 1934.136261 * tete + 0.0020708 * System.Math.Pow(tete, 2) + System.Math.Pow(tete, 3) / 450000), 360);
        double u = tete / 100;
        double epsilonZero = 23.43929111 - (4680.93 * u - 1.55 * System.Math.Pow(u, 2) + 1999.25 * System.Math.Pow(u, 3) - 51.38 * System.Math.Pow(u, 4) - 249.67 * System.Math.Pow(u, 5) - 39.05 * System.Math.Pow(u, 6) + 7.12 * System.Math.Pow(u, 7) + 27.87 * System.Math.Pow(u, 8) + 5.79 * System.Math.Pow(u, 9) + 2.45 * System.Math.Pow(u, 10)) / 3600;


        //koreksi ASI
        double korn1 = (-171996 + -174.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn2 = (-13187 + -1.6 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn3 = (-2274 + -0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn4 = (2062 + 0.2 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn5 = (1426 + -3.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn6 = (712 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn7 = (517 + 1.2 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn8 = (-386 + -0.4 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn9 = (217 + -0.5 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn10 = (129 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn11 = (63 + 0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn12 = (-58 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn13 = (17 + -0.1 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn14 = (-16 + 0.1 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn15 = (-301 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn16 = (-158 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn17 = (123 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn18 = (63 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn19 = (-59 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn20 = (-51 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn21 = (48 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn22 = (46 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn23 = (-38 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn24 = (-31 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn25 = (29 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn26 = (29 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn27 = (26 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn28 = (-22 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn29 = (21 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn30 = (16 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn31 = (-15 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn32 = (-13 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn33 = (-12 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn34 = (11 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn35 = (-10 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn36 = (-8 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn37 = (7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn38 = (-7 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn39 = (-7 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn40 = (-7 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn41 = (6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn42 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn43 = (6 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn44 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn45 = (-6 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn46 = (5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn47 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn48 = (-5 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn49 = (-5 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn50 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn51 = (4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double korn52 = (4 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + -2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn53 = (-4 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn54 = (-4 + 0 * tete) * System.Math.Sin(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn55 = (-4 + 0 * tete) * System.Math.Sin(1 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn56 = (3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn57 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn58 = (-3 + 0 * tete) * System.Math.Sin(-1 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn59 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double korn60 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn61 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn62 = (-3 + 0 * tete) * System.Math.Sin(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 3 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double korn63 = (-3 + 0 * tete) * System.Math.Sin(2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));

        double jumlahkorn = korn1 + korn2 + korn3 + korn4 + korn5 + korn6 + korn7 + korn8 + korn9 + korn10 + korn11 + korn12 + korn13 + korn14 + korn15 + korn16 + korn17 + korn18 + korn19 + korn20
                + korn21 + korn22 + korn23 + korn24 + korn25 + korn26 + korn27 + korn28 + korn29 + korn30
                + korn31 + korn32 + korn33 + korn34 + korn35 + korn36 + korn37 + korn38 + korn39 + korn40
                + korn41 + korn42 + korn43 + korn44 + korn45 + korn46 + korn47 + korn48 + korn49 + korn50
                + korn51 + korn52 + korn53 + korn54 + korn55 + korn56 + korn57 + korn58 + korn59 + korn60 + korn61 + korn62 + korn63;

        //lanjuTan koreksi ASI
        double segpeg = jumlahkorn / 10000 / 3600;
        double deltaPsi = segpeg;

        //koreksi delta epsilon
        double kord1 = (92025 + 8.9 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord2 = (5736 + -3.1 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord3 = (977 + -0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord4 = (-895 + 0.5 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord5 = (54 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord6 = (224 + -0.6 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord7 = (129 + -0.1 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord8 = (-95 + 0.3 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord9 = (-7 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 0 * System.Math.PI / 180 * (omega2));
        double kord10 = (200 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord11 = (-70 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord12 = (-53 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord13 = (-33 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord14 = (26 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord15 = (32 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord16 = (27 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord17 = (-24 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord18 = (16 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord19 = (13 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord20 = (-12 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord21 = (-10 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord22 = (-8 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord23 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 2 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord24 = (9 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord25 = (7 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord26 = (6 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord27 = (5 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord28 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord29 = (-3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord30 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord31 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord32 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 2 * System.Math.PI / 180 * (omega2));
        double kord33 = (-3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 1 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord34 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + -2 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord35 = (3 + 0 * tete) * System.Math.Cos(2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord36 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + -1 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord37 = (3 + 0 * tete) * System.Math.Cos(-2 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 0 * System.Math.PI / 180 * (emaksen) + 0 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double kord38 = (3 + 0 * tete) * System.Math.Cos(0 * System.Math.PI / 180 * (debesar) + 0 * System.Math.PI / 180 * (embesar) + 2 * System.Math.PI / 180 * (emaksen) + 2 * System.Math.PI / 180 * (efbesar) + 1 * System.Math.PI / 180 * (omega2));
        double jumlahkord = kord1 + kord2 + kord3 + kord4 + kord5 + kord6 + kord7 + kord8 + kord9 + kord10
                + kord11 + kord12 + kord13 + kord14 + kord15 + kord16 + kord17 + kord18 + kord19 + kord20
                + kord21 + kord22 + kord23 + kord24 + kord25 + kord26 + kord27 + kord28 + kord29 + kord30
                + kord31 + kord32 + kord33 + kord34 + kord35 + kord36 + kord37 + kord38;

        //lanjuTan koreksi delta epsilon
        double segep = jumlahkord / 10000 / 3600;
        double epsilon = epsilonZero + segep;
        double epsilon_r = System.Math.PI / 180 * (epsilon);

        double gstnampak = gstpukul + deltaPsi * System.Math.Cos(epsilon_r) / 15;
        double lstnampak = (gstnampak + bujur / 15) % 24;
        if (lstnampak < 0) lstnampak += 24;

        // mencari nilai Deklinasi
        double deltaBulan = Data_Algo_JeanMeeus(tahun, bulan, tanggal, System.Convert.ToInt32(jam1), System.Convert.ToInt32(menit1), System.Convert.ToInt32(timezone))[4];
        double deltaB_r = System.Math.PI / 180 * (deltaBulan);

        // mencari nilai Right Ascensio
        double alphaBulan = Data_Algo_JeanMeeus(tahun, bulan, tanggal, System.Convert.ToInt32(jam1), System.Convert.ToInt32(menit1), System.Convert.ToInt32(timezone))[3];

        // menghitung Sudut Waktu / Hour angel
        double hourAngleB = lstnampak * 15 - alphaBulan;
        double hourAngleB_r = System.Math.PI / 180 * (hourAngleB);

        // menghitung Azimuth dan Altitude 
        double azimuthB_selAtan = 180 / System.Math.PI * (System.Math.Atan2(System.Math.Sin(hourAngleB_r), System.Math.Cos(hourAngleB_r) * System.Math.Sin(lintang_r) - System.Math.Tan(deltaB_r) * System.Math.Cos(lintang_r)));
        double azimuthBulan = (azimuthB_selAtan + 180) % 360;

        double altitudeB = 180 / System.Math.PI * (System.Math.Asin(System.Math.Sin(lintang_r) * System.Math.Sin(deltaB_r) + System.Math.Cos(lintang_r) * System.Math.Cos(deltaB_r) * System.Math.Cos(hourAngleB_r)));

        //Variable hasil perhitungan dan nomer urut arrays
        double Azimuth = azimuthBulan; //1
        double Altitude = altitudeB; //2

        // mengembalikan hasil perhitungan dengan bentuk arrays
        return new double[]{
            0, Azimuth,Altitude
        };

    }

}
