﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PetunjukV : MonoBehaviour
{
    public Transform Kamera;
    public Transform PorosRotasi;

    public RectTransform atas;
    public RectTransform bawah;

    // Start is called before the first frame update
    void Start()
    {
        atas.gameObject.SetActive(false);
        bawah.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        //nilai altitude kamera
        float kamerax = (Mathf.Abs(Kamera.eulerAngles.x)) % 360;
        // Setting nilai heading menjadi 0-90
        if ((kamerax >= 1) && (kamerax <= 90))
        {
            kamerax = kamerax * -1;
        }
        else if ((kamerax >= 91) && (kamerax <= 180))
        {
            kamerax = (90 - (kamerax - 90)) * -1;
        }
        else if ((kamerax <= 359) && (kamerax >= 270))
        {
            kamerax = (90 - (kamerax - 270));
        }
        else if ((kamerax <= 271) && (kamerax >= 181))
        {
            kamerax = (90 + (kamerax - 180));
        }
        else kamerax += 0;

        //nilai altitude target
        float porosz = Mathf.Abs(PorosRotasi.eulerAngles.z) % 360;
        // Setting nilai heading menjadi 0-90
        if ((porosz >= 1) && (porosz <= 90))
        {
            porosz = Mathf.Abs(porosz * -1);
        }
        else if ((porosz >= 91) && (porosz <= 180))
        {
            porosz = Mathf.Abs((90 - (porosz - 90)) * -1);
        }
        else if ((porosz <= 359) && (porosz >= 270))
        {
            porosz = Mathf.Abs((90 - (porosz - 270)));
        }
        else if ((porosz <= 271) && (porosz >= 181))
        {
            porosz = Mathf.Abs(90 + (porosz - 180));
        }
        else Mathf.Abs(porosz += 0);

        float alt = Mathf.Abs(kamerax - porosz);

        // hide arrow when near target
        float HideDistance = 5f;

        //Debug.Log("Kamerax" + "=" + kamerax);
        //Debug.Log("porosz" + "=" + porosz);

        if ((kamerax < porosz) && (alt > HideDistance))
        {
            atas.gameObject.SetActive(true);
            bawah.gameObject.SetActive(false);
        }
        else if ((kamerax > porosz) && (alt > HideDistance))
        {
            bawah.gameObject.SetActive(true);
            atas.gameObject.SetActive(false);
        }
        else if (alt < HideDistance)
        {
            atas.gameObject.SetActive(false);
            bawah.gameObject.SetActive(false);
        }
    }
}
