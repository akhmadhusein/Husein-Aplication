﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Compass_H : MonoBehaviour
{
    public RawImage CompassImage;
    public Transform Player;
    public Text CompassDirectionText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

		//Get a handle on the Image's uvRect
		//CompassImage.uvRect = new Rect(Player.localEulerAngles.y / 360, 0, 1, 1);
        

        // Get a copy of your forward vector
        Vector3 forward = Player.transform.forward;

		// Zero out the y component of your forward vector to only get the direction in the X,Z plane
		forward.y = 0;

		//Clamp our angles to only 5 degree increments
		//float headingAngle = Quaternion.LookRotation(forward).eulerAngles.y;
        float headingAngle = Player.transform.rotation.eulerAngles.y;


        //set azimuth start from north
        if ((headingAngle >= 0) && (headingAngle < 180))
        {
            headingAngle += 180;
        }
        else headingAngle -= 180;

        //Get a handle on the Image's uvRect
        CompassImage.uvRect = new Rect(headingAngle / 360, 0, 1, 1);

        string headingA = keDerajat(headingAngle);
        //Set the text of Compass Degree Text to the clamped value, but change it to the letter if it is a True direction
        CompassDirectionText.text = headingA;

	}

	public string keDerajat(float a)
    {
        float derajat = 0;
        float menit = 0;
        float detik = 0;

        if (a >= 0)
        {
            derajat = (Mathf.FloorToInt(a));
        }
        else
        {
            derajat = (Mathf.CeilToInt(a));
        }

        if (a >= 0)
        {
            menit = (Mathf.FloorToInt((a - derajat) * 60));
        }
        else
        {
            menit = (Mathf.CeilToInt((a - derajat) * 60));
        }


        detik = Mathf.RoundToInt((((a - derajat) * 60) - (menit)) * 60);

        return derajat + "° " + Mathf.Abs(menit) + "' " + Mathf.Abs(detik) + "''";
    }
}
